// Action click -> make sure the panel is up -> get a stream id -> hand it to the
// panel, which owns the audio graph. getMediaStreamId requires the extension to have
// been invoked on the target tab, which the action click satisfies. Adding a second
// tab = click the action on it.

// Show the panel, reusing the existing one rather than stacking up duplicates.
// Querying by URL rather than remembering a tab id means there is no stale id to
// invalidate when the user closes it — single instance by construction.
//
// Note this is also the only reliable way to get an extension page open under
// automation: top-level navigation to chrome-extension:// is blocked, but an
// extension-initiated tabs.create is not.
async function openOrFocusPanel() {
  const url = chrome.runtime.getURL('panel.html');
  const [existing] = await chrome.tabs.query({ url });
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
    return existing;
  }
  return chrome.tabs.create({ url });
}

chrome.runtime.onInstalled.addListener(async () => {
  await openOrFocusPanel();
  // Declared content scripts only run on navigation, so inject into YouTube tabs
  // that were already open when the extension loaded.
  const tabs = await chrome.tabs.query({ url: '*://*.youtube.com/*' });
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] });
    } catch (e) {
      console.warn('[mixer] inject failed', t.id, e.message);
    }
  }
});

// Ping the panel until its listener is up. createTarget resolves before the page has
// run its scripts, and a stream id expires within seconds — so the panel must be ready
// BEFORE we take the id, not after.
async function panelReady(tries = 40) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await chrome.runtime.sendMessage({ target: 'panel', type: 'PING' });
      if (r && r.ready) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  return false;
}

chrome.action.onClicked.addListener(async (tab) => {
  try {
    // Panel first. It owns the audio graph now, so there is nowhere else to put a
    // capture, and the stream id would expire while the page was still loading.
    await openOrFocusPanel();
    const ready = await panelReady();
    if (!ready) throw new Error('mixer panel did not come up');

    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });

    const res = await chrome.runtime.sendMessage({
      target: 'panel',
      type: 'ADD_STREAM',
      streamId,
      tabId: tab.id,
      title: tab.title || String(tab.id),
    });
    console.log('[mixer] ADD_STREAM result', res);
  } catch (e) {
    console.error('[mixer] add channel failed', e);
    await openOrFocusPanel(); // the panel explains a failure better than a silent click
  }
});

globalThis.mixerOpenPanel = openOrFocusPanel;
