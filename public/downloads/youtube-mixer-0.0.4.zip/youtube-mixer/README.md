# YouTube Mixer — spike

## Load

1. `chrome://extensions` → Developer mode on → **Load unpacked** → this directory.
2. Open a YouTube tab, start playback.
3. Click the extension action. That grants invocation on the tab and adds it as a channel.

## Verify (steps 4–6)

Open the service worker devtools: `chrome://extensions` → YouTube Mixer → **service worker**.

```js
await mixerState()                 // channels, gains, context state, sample rate
await mixerGain(<tabId>, 0.25)     // fader — audible level change, no click
await mixerGain(<tabId>, 1)
await mixerDrop(<tabId>)           // stop and remove a channel
```

Checks:

- **No doubled audio.** Capturing a tab suppresses its own playback; the offscreen
  graph is what makes it audible again. If it sounds doubled, the tab is still playing
  locally and the capture is additive.
- **No feedback.** The offscreen document is a separate context from the captured tab,
  so its output is not part of the captured surface.
- **Second tab.** Open another audible tab, click the action there, re-run
  `mixerState()`. Both channels should be listed and both audible.

## Files

| File | Role |
|---|---|
| `manifest.json` | MV3, permissions, action |
| `service-worker.js` | action click → `getMediaStreamId` → hand to offscreen |
| `offscreen.html` / `offscreen.js` | the single `AudioContext`, per-channel gain, master |
