// Video mode: the performance layout.
//
// Same channels, same tape, same MIDI bindings — only the presentation changes.
//
// Two things drive the design. Four 16:9 videos in a 2x2 make a 16:9 frame, so the
// grid fits a stream exactly, but only if nothing takes its own row — hence controls
// overlay the picture rather than sitting beside it. And the controls stay visible
// rather than fading after idle: on a performance stream the faders moving ARE the
// show.
//
// Depends on globals from panel.js (setGain, setMute, setSolo, toContent, fmtDb,
// dragging) and audio.js (Mixer). Classic scripts, shared scope, loaded last.

const tiles = new Map(); // tabId -> { el, parts }
let videoOn = false;
let videoTimer = null;

function buildTile(tabId) {
  const el = document.createElement('div');
  el.className = 'tile';
  el.innerHTML = `
    <video class="tile__v" autoplay muted playsinline></video>
    <canvas class="tile__viz" width="480" height="120"></canvas>
    <div class="tile__chrome">
      <div class="tile__top">
        <span class="tile__title"></span>
        <span class="tile__rate"></span>
      </div>
      <div class="tile__bottom">
        <div class="tile__fader" data-help="Drag anywhere along this bar to set the channel level. The filled portion behind it is the live meter.">
          <div class="tile__meter"></div>
          <div class="tile__level"></div>
        </div>
        <button class="tile__btn tile__m" data-help="Mute this channel.">M</button>
        <button class="tile__btn tile__s" data-help="Solo this channel.">S</button>
      </div>
    </div>`;

  const q = (s) => el.querySelector(s);
  const parts = {
    v: q('.tile__v'), viz: q('.tile__viz'), title: q('.tile__title'),
    rate: q('.tile__rate'), fader: q('.tile__fader'), meter: q('.tile__meter'),
    level: q('.tile__level'), m: q('.tile__m'), s: q('.tile__s'),
    vizCtx: q('.tile__viz').getContext('2d'),
    crop: null, streamAttached: false,
  };

  // The fader is a bar, not a range input: it has to be thin enough to overlay video
  // and double as its own meter. Pointer capture so a drag that leaves the tile still
  // tracks, which matters when tiles are small.
  const setFromPointer = (e) => {
    const r = parts.fader.getBoundingClientRect();
    const frac = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    const level = frac * 1.5;
    parts.level.style.width = (frac * 100) + '%';
    setGain(tabId, level);
  };
  parts.fader.addEventListener('pointerdown', (e) => {
    parts.fader.setPointerCapture(e.pointerId);
    dragging = parts.fader;
    setFromPointer(e);
  });
  parts.fader.addEventListener('pointermove', (e) => {
    if (dragging === parts.fader) setFromPointer(e);
  });
  const release = () => { if (dragging === parts.fader) dragging = null; };
  parts.fader.addEventListener('pointerup', release);
  parts.fader.addEventListener('pointercancel', release);

  parts.m.addEventListener('click', () => setMute(tabId));
  parts.s.addEventListener('click', (e) => setSolo(tabId, undefined, !e.shiftKey));

  tiles.set(tabId, { el, parts });
  document.getElementById('video-grid').appendChild(el);
  return tiles.get(tabId);
}

// Crop the captured tab down to the player. The <video> shows the whole tab, so blow
// it up by 1/w and slide it so the player's top-left lands at the tile's.
function applyCrop(parts, crop) {
  const v = parts.v;
  if (!crop || crop.w <= 0.05 || crop.h <= 0.05) {
    v.style.width = '100%'; v.style.height = '100%';
    v.style.left = '0'; v.style.top = '0';
    return;
  }
  v.style.width = (100 / crop.w) + '%';
  v.style.height = (100 / crop.h) + '%';
  v.style.left = -(crop.x * 100 / crop.w) + '%';
  v.style.top = -(crop.y * 100 / crop.h) + '%';
}

function drawViz(parts, points) {
  const g = parts.vizCtx;
  const { width: w, height: h } = parts.viz;
  g.clearRect(0, 0, w, h);
  if (!points || !points.length) return;
  g.fillStyle = '#c9a227';
  const bw = w / points.length;
  for (let i = 0; i < points.length; i++) {
    const bh = Math.max(1, points[i] * h);
    g.fillRect(i * bw, (h - bh) / 2, Math.max(1, bw - 1), bh);
  }
}

async function renderVideo() {
  if (!videoOn) return;
  const st = Mixer.state();
  const channels = (st && st.channels) || [];
  const lv = Mixer.levels();
  const levelBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.db]));

  for (const [tabId, t] of tiles) {
    if (!channels.some((c) => c.tabId === tabId)) { t.el.remove(); tiles.delete(tabId); }
  }

  const grid = document.getElementById('video-grid');
  grid.dataset.count = String(Math.min(channels.length, 6));

  for (const ch of channels) {
    const t = tiles.get(ch.tabId) || buildTile(ch.tabId);
    const p = t.parts;

    p.title.textContent = ch.title || 'tab ' + ch.tabId;

    // Attach the stream once; re-attaching restarts decoding and flickers.
    const stream = Mixer.getStream(ch.tabId);
    const hasVideo = !!(stream && stream.getVideoTracks && stream.getVideoTracks().length);
    if (hasVideo && !p.streamAttached) {
      p.v.srcObject = stream;
      p.v.play().catch(() => {});
      p.streamAttached = true;
    }
    t.el.classList.toggle('tile--audio', !hasVideo);

    // Level: filled bar, and the meter behind it.
    if (dragging !== p.fader) p.level.style.width = ((ch.level / 1.5) * 100) + '%';
    const db = levelBy.get(ch.tabId);
    const meterFrac = db === null || db === undefined ? 0 : Math.max(0, Math.min(1, (db + 60) / 60));
    p.meter.style.width = (meterFrac * 100) + '%';

    p.m.setAttribute('aria-pressed', String(!!ch.muted));
    p.s.setAttribute('aria-pressed', String(!!ch.soloed));

    if (hasVideo) {
      const info = await toContent(ch.tabId, { type: 'INFO' });
      if (info && info.ok) {
        p.rate.textContent = Number(info.playbackRate).toFixed(2) + '×';
        if (info.crop) { p.crop = info.crop; applyCrop(p, info.crop); }
      } else {
        p.rate.textContent = '';
      }
    } else {
      drawViz(p, Mixer.waveform(ch.tabId, 96));
      p.rate.textContent = '';
    }
  }

  document.getElementById('video-empty').style.display = channels.length ? 'none' : '';
}

function setVideoMode(on) {
  videoOn = !!on;
  localStorage.setItem('ym-video', videoOn ? '1' : '0');
  document.body.classList.toggle('video-mode', videoOn);
  document.getElementById('video-switch').setAttribute('aria-pressed', String(videoOn));

  // Frames are only delivered while wanted, so audio mode costs nothing extra.
  Mixer.setVideoEnabled(videoOn);

  if (videoOn) {
    renderVideo();
    if (!videoTimer) videoTimer = setInterval(renderVideo, 250);
  } else {
    clearInterval(videoTimer);
    videoTimer = null;
    for (const [, t] of tiles) { t.parts.v.srcObject = null; t.parts.streamAttached = false; }
  }
}

function initVideo() {
  document.getElementById('video-switch')
    .addEventListener('click', () => setVideoMode(!videoOn));

  document.getElementById('video-full').addEventListener('click', () => {
    const el = document.getElementById('video');
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen().catch(() => {});
  });

  // Pure footage for a moment, without leaving video mode.
  const clean = document.getElementById('video-clean');
  clean.addEventListener('click', () => {
    const on = clean.getAttribute('aria-pressed') !== 'true';
    clean.setAttribute('aria-pressed', String(on));
    document.body.classList.toggle('video-clean', on);
  });

  setVideoMode(localStorage.getItem('ym-video') === '1');
}

initVideo();

Object.assign(window, {
  videoMode: setVideoMode,
  videoTiles: () => tiles.size,
  videoIsOn: () => videoOn,
  videoCropOf: (tabId) => {
    const t = tiles.get(tabId);
    return t ? t.parts.crop : null;
  },
  videoStyleOf: (tabId) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    const s = t.parts.v.style;
    return { width: s.width, height: s.height, left: s.left, top: s.top };
  },
  videoReady: true,
});
