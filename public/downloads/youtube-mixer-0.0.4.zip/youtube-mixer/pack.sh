#!/usr/bin/env bash
# Build the distributable zip.
#
# Exists because `git archive` silently archives whatever repo you happen to be
# standing in, and running it from the a-u.supply worktree (the output directory)
# produced a 27MB zip of the website twice. This script refuses to run anywhere but
# the extension repo, and checks what it built.
#
#   ./pack.sh /path/to/a-u.supply/public/downloads
set -euo pipefail

cd "$(dirname "$0")"

if [ ! -f manifest.json ] || ! grep -q '"YouTube Mixer"' manifest.json; then
  echo "refusing: not in the youtube-mixer repo" >&2
  exit 1
fi

OUT_DIR="${1:?usage: ./pack.sh <output-dir>}"
[ -d "$OUT_DIR" ] || { echo "no such directory: $OUT_DIR" >&2; exit 1; }

VERSION=$(node -p "require('./manifest.json').version")
ZIP="$OUT_DIR/youtube-mixer-$VERSION.zip"

if [ -n "$(git status --porcelain)" ]; then
  echo "warning: working tree is dirty — the zip is built from HEAD, not your edits" >&2
fi

# Tracked files only. This is what keeps .extension-key.pem (gitignored) out of a
# public download; zipping the folder would sweep it in.
git archive --format=zip --prefix=youtube-mixer/ -o "$ZIP" HEAD

# Verify rather than trust.
LIST=$(unzip -l "$ZIP")
echo "$LIST" | grep -q 'youtube-mixer/manifest.json' || { echo "FAIL: no manifest in zip" >&2; exit 1; }
if echo "$LIST" | grep -qiE '\.pem|extension-id'; then
  echo "FAIL: signing key or id leaked into the zip" >&2
  rm -f "$ZIP"
  exit 1
fi
COUNT=$(echo "$LIST" | tail -1 | awk '{print $2}')
if [ "$COUNT" -gt 40 ]; then
  echo "FAIL: $COUNT files — that is not the extension, check which repo you are in" >&2
  rm -f "$ZIP"
  exit 1
fi

echo "built $ZIP"
echo "  version $VERSION from $(git log --oneline -1)"
echo "  $COUNT files, no signing key"
