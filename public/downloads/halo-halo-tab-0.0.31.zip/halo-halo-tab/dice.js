// dice.js — the fun button.
//
// Tube, after five minutes with 0.0.30: "could be a fun button (... [press] -> out comes
// a random 5 second loop made from all of your channels and randomized fx)". And, more
// to the point, the reason it is worth building: "anything on the computer I have to
// automate or I lose interest in it immediately. I would most likely use this more with
// the automation/shuffle stuff."
//
// THE DESIGN CLAIM, and the thing that keeps this from being a black box: every value a
// roll produces is written into a control you can see. Nothing here reaches past the UI
// into the audio graph. So a roll is legible — you can read what it did, keep the one
// part you liked, and turn the rest by hand — and `u` puts it back. A randomiser whose
// output you cannot see or grab is a slot machine, and you would stop pressing it.
//
// This file is an IIFE that exports by name at the bottom. The panel's scripts are
// CLASSIC scripts sharing one global scope, so a top-level `const` that a sibling
// already uses is a SyntaxError that kills this entire file while the panel goes on
// rendering perfectly — every seam below silently undefined.
(function () {
  'use strict';

  // SETS, not continuous ranges. A uniform draw over [0.25, 8] mostly returns lengths
  // with no relation to anything playing; a set of musical divisions returns loops that
  // sit against a bar more often than not. Same reasoning for the speeds — octaves,
  // fifths and fourths, plus the reverses, rather than 1.037.
  const LOOP_SECONDS = [0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 6, 8];
  const RATES = [-1, -0.75, -0.5, 0.5, 0.75, 1, 1, 1.25, 1.5, 2];
  const PANS = [-0.9, -0.6, -0.3, 0, 0, 0.3, 0.6, 0.9];
  const LEVELS = [0.5, 0.75, 1, 1, 1.2];

  // How often a channel is dropped from the roll. Never all of them — a roll that
  // returns silence is indistinguishable from a broken button, and it is the one
  // outcome that would make somebody stop pressing it.
  const DROP_CHANCE = 0.28;

  // Injected so a suite can drive this. There is no assertion to make about
  // Math.random, and a randomiser nobody can pin down is a randomiser nobody can test —
  // the same reason midiSimulate() and recSetWriter() exist.
  let rnd = Math.random;

  // One level, deliberately. Two would need a stack and an answer for what happens when
  // you turn a control by hand between rolls; one is the move people actually make —
  // "no, the one before".
  let prev = null;
  let last = null;

  const pick = (a) => a[Math.min(a.length - 1, Math.floor(rnd() * a.length))];
  const deckEls = () => Array.from(document.querySelectorAll('#decks .deck'));

  // Write to a range the way a drag does. Setting .value alone moves the thumb and the
  // number and NOTHING else — every listener in this panel is on `input`.
  function setRange(el, v) {
    if (!el) return;
    el.value = String(v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function isMuted(deck) {
    const b = deck.querySelector('.mute');
    return !!b && b.getAttribute('aria-pressed') === 'true';
  }

  function setMuted(deck, want) {
    const b = deck.querySelector('.mute');
    if (b && isMuted(deck) !== !!want) b.click();
  }

  // Read the mix off the CONTROLS rather than off mixerState(). Undo has to put the
  // controls back, so the controls are what must be remembered; going through the graph
  // would restore the sound and leave the panel showing the roll.
  function readState() {
    const rate = document.getElementById('t-rate');
    return {
      rate: rate ? Number(rate.value) : 1,
      channels: deckEls().map((d) => ({
        level: Number((d.querySelector('.level') || {}).value || 1),
        pan: Number((d.querySelector('.pan') || {}).value || 0),
        muted: isMuted(d),
      })),
    };
  }

  function writeState(s) {
    if (!s) return;
    setRange(document.getElementById('t-rate'), s.rate);
    const ds = deckEls();
    s.channels.forEach((c, i) => {
      const d = ds[i];
      if (!d) return;
      setRange(d.querySelector('.level'), c.level);
      setRange(d.querySelector('.pan'), c.pan);
      setMuted(d, c.muted);
    });
  }

  function roll() {
    const ds = deckEls();
    // Remember BEFORE anything moves, and only when there is something to remember.
    prev = readState();

    const loopSec = pick(LOOP_SECONDS);
    const rate = pick(RATES);

    const channels = ds.map(() => ({
      level: pick(LEVELS), pan: pick(PANS), muted: rnd() < DROP_CHANCE,
    }));
    // Never everything at once. If the dice muted the lot, un-mute one at random —
    // biased, and correctly so: silence is not one of the outcomes worth having.
    if (channels.length && channels.every((c) => c.muted)) {
      channels[Math.floor(rnd() * channels.length)].muted = false;
    }

    channels.forEach((c, i) => {
      const d = ds[i];
      if (!d) return;
      setRange(d.querySelector('.level'), c.level);
      setRange(d.querySelector('.pan'), c.pan);
      setMuted(d, c.muted);
    });

    // The tape last, and the loop last of all. Arming a loop COPIES the region out of
    // the ring, so the channel levels have to be where the roll wants them before the
    // copy is taken — set them afterwards and you would hear the old balance looping
    // under the new faders.
    setRange(document.getElementById('t-rate'), rate);
    if (typeof tapeCmd === 'function') tapeCmd('loopSecondsBack', loopSec);

    last = { loopSec, rate, channels };
    paint();
    return last;
  }

  function undo() {
    if (!prev) return null;
    const back = prev;
    writeState(back);
    // The loop goes off rather than back. A loop cannot be restored — re-arming the
    // same LENGTH takes a fresh copy of whatever is on the tape now, which is the
    // identical trap snapshot restore still has. Off is the honest answer, and it is
    // also what "undo the roll" means to a hand reaching for it.
    if (typeof tapeSet === 'function') tapeSet({ loopEnabled: false });
    prev = null;
    last = null;
    paint();
    return back;
  }

  // Undo only exists once there is something to undo — the same rule as `save take…`,
  // which is hidden until a take is actually stranded.
  function paint() {
    const u = document.getElementById('dice-undo');
    if (u) u.hidden = !prev;
  }

  function init() {
    const r = document.getElementById('dice-roll');
    const u = document.getElementById('dice-undo');
    if (r) r.addEventListener('click', () => { roll(); r.blur(); });
    if (u) u.addEventListener('click', () => { undo(); u.blur(); });
    paint();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  Object.assign(window, {
    diceRoll: roll,
    diceUndo: undo,
    diceLast: () => last,
    diceCanUndo: () => !!prev,
    // Takes a function returning [0,1). Pass nothing to go back to Math.random.
    diceSetRandom: (fn) => { rnd = typeof fn === 'function' ? fn : Math.random; return true; },
    diceReady: true,
  });
})();
