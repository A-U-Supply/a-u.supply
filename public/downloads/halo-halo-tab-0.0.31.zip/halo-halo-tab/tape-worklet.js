// Tape: a rolling stereo ring buffer sitting between the channel sum and output.
//
// It is always recording. `thru` mode passes input straight out (zero latency) while
// still filling the ring, so engaging the tape is seamless. `tape` mode plays from a
// read head that runs at `rate` — continuous, signed, so 0.5 is half speed, -1 is
// reverse, 0 is a full stop.
//
// Positions are absolute sample counts (safe to 2^53) and mapped into the ring by
// modulo, which keeps loop points and scrubbing simple.

// Buckets per second of waveform. 100 gives a 10ms resolution — finer than a screen
// pixel at any window this panel will draw, and 6000 numbers for the whole sixty
// seconds, which is nothing to hold or to draw from.
const SCOPE_HZ = 100;
const SCOPE_SEND_MS = 50;

class TapeProcessor extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [
      // a-rate so varispeed and scrub move smoothly rather than in block steps.
      { name: 'rate', defaultValue: 1, minValue: -4, maxValue: 4, automationRate: 'a-rate' },
    ];
  }

  constructor(options) {
    super();
    const opts = options.processorOptions || {};
    const seconds = opts.seconds || 60;
    this.len = Math.floor(sampleRate * seconds);
    this.ring = [new Float32Array(this.len), new Float32Array(this.len)];

    this.writePos = 0; // absolute samples written
    this.readPos = 0; // absolute, fractional

    // ---- SCRATCHING ----------------------------------------------------------------
    //
    // A hand on a record is a POSITION, not a speed. The panel could watch the pointer
    // and set `rate` from how fast it moved, but pointer events arrive irregularly and
    // the panel only learns where the head is twenty times a second — so the sound would
    // drift away from the finger with nothing to pull it back. Instead the panel says
    // where the head SHOULD be and this solves for the rate that gets it there inside
    // one 128-sample block, which is 2.7ms. The pitch then falls out of the arithmetic,
    // the way it does on a turntable: move your hand twice as fast and you hear twice
    // the speed, because that is literally the rate being integrated.
    //
    // The target is a DELTA from where the scratch began, never an absolute position.
    // The panel's idea of `readPos` is up to 50ms old, and engaging the tape moves the
    // head before the first drag arrives — an absolute target would carry both errors.
    this.scrubbing = false;
    this.scrubAnchor = 0;   // readPos when the hand went down
    this.scrubTarget = 0;
    // HOW LONG THE MOVE HAS TO LAST, in samples, and it is the whole difference between
    // a scratch and a stutter. See the note in process().
    this.scrubSpan = 0;
    this.scrubLastAt = null;   // the panel's clock at the last update
    this.scrubRate = 0;        // smoothed, see process()
    this.scrubVel = 0;         // the hand's velocity, carried between updates
    // How many taps the gap is currently integrating over. See sampleSpan().
    this.gapTaps = 1;
    this.mode = 'thru'; // 'thru' | 'tape'
    this.latency = Math.floor(sampleRate * (opts.latencySec || 0.25));

    this.loopEnabled = false;
    this.loopStart = 0;
    this.loopEnd = 0;
    this.loopArming = false;  // `in` marked, `out` not yet
    this.loopBuf = null;      // the loop's own copy; see at()
    this.loopSource = null;   // 'seconds' | 'tap' | 'stutter' — which control owns it
    this.loopSeconds = 0;     // for 'seconds', so only THAT button lights

    // ---- the scope -------------------------------------------------------------
    //
    // The tape already holds sixty seconds of stereo. Drawing it needs no second
    // buffer, only a cheaper summary: peak magnitude over short buckets, which is
    // what a waveform is. Kept at a fixed rate in TIME rather than in pixels, so the
    // panel can draw any window onto it — twelve seconds now, the whole minute when
    // scrubbing wants it, without asking for anything different.
    //
    // Pushed rather than polled, and only the buckets that are new since the last
    // push, so the traffic is a handful of numbers every 50ms instead of a redraw's
    // worth of array every frame.
    this.bucketLen = Math.max(1, Math.round(sampleRate / SCOPE_HZ));
    this.bucketPeak = 0;
    this.bucketFill = 0;
    this.pending = [];      // completed buckets not yet sent
    this.scopeOn = false;
    this.sinceSend = 0;
    this.lastRate = 1;
    this.interp = opts.interp || 'linear'; // 'linear' | 'cubic'
    this.stutterPrev = null; // loop state saved for the duration of a stutter

    // A stopped transport must make no sound. Holding the read head still returns the
    // same sample forever, which is a DC offset that buzzes; and once the buffer is
    // full the oldest-clamp starts dragging the head one jump per block, which is a
    // ~375Hz staircase of unrelated samples. Both were audible as "dissonant
    // crackling that won't stop". Fading out near zero rate fixes both, and is what a
    // real tape does anyway.
    this.stopGain = 1;
    // ~20ms ramp, so it reads as a stop rather than a click.
    this.fadeCoeff = 1 - Math.exp(-1 / (0.02 * sampleRate));

    this.port.onmessage = (e) => this.onMessage(e.data || {});
  }

  onMessage(m) {
    switch (m.type) {
      case 'set':
        if (m.mode !== undefined && m.mode !== this.mode) {
          // Entering tape: drop the read head to the standing latency behind live so
          // there is rope to scrub backwards into.
          if (m.mode === 'tape') this.readPos = this.writePos - this.latency;
          this.mode = m.mode;
        }
        if (m.latencySec !== undefined) {
          this.latency = Math.floor(sampleRate * m.latencySec);
        }
        if (m.loopEnabled !== undefined) {
          this.loopEnabled = !!m.loopEnabled;
          // Switching a loop off drops the copy and lands you back on the ring, which
          // never stopped recording — so `off` still carries on from where the tape is.
          if (!this.loopEnabled) {
            this.loopBuf = null; this.loopArming = false;
            this.loopSource = null; this.loopSeconds = 0;
          }
        }
        if (m.interp === 'linear' || m.interp === 'cubic') this.interp = m.interp;
        break;

      // Loop points are marked live, relative to the read head.
      // Tapped in and out, live. `in` only marks — nothing changes about what you are
      // hearing until `out` closes the loop, which is what makes it usable while
      // something is playing: you can mark, listen, and mark again.
      case 'loopIn':
        this.markIn();
        break;

      // ONE BUTTON, THREE STATES. The worklet decides which, rather than the panel
      // counting presses: a counter in the UI drifts the moment anything else touches
      // the loop — `off`, a stutter, a seconds-back button — and then the button is
      // lying about a state it no longer owns. Asking the thing that holds the state
      // cannot drift.
      case 'loopTap':
        if (this.loopEnabled) {
          // Third press: drop this loop and immediately mark the start of the next, so
          // loops can be chained without a trip to `off` in between.
          this.loopEnabled = false;
          this.loopBuf = null;
          this.markIn();
        } else if (this.loopArming) {
          this.closeLoop();
        } else {
          this.markIn();
        }
        break;
      case 'loopOut':
        this.closeLoop();
        break;
      // Momentary: grab the last `seconds` and loop it, then put the previous loop
      // state back. Held, it repeats; released, it stops pretending it never
      // happened — by default it snaps back to live, since stuttering spends time.
      case 'stutter': {
        if (m.on) {
          if (!this.stutterPrev) {
            // The BUFFER goes in the snapshot too. Without it, releasing a stutter
            // taken over a running loop restored that loop's boundaries onto a null
            // copy — so at() would silently fall through to the ring and the loop
            // would come back as whatever is there now instead of what it held.
            this.stutterPrev = {
              enabled: this.loopEnabled, start: this.loopStart, end: this.loopEnd,
              buf: this.loopBuf, arming: this.loopArming,
            };
          }
          const end = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
          const len = Math.max(64, Math.floor(sampleRate * (m.seconds || 0.125)));
          this.loopStart = end - len;
          this.loopEnd = end;
          this.loopSource = 'stutter';
          this.armLoop();
        } else if (this.stutterPrev) {
          this.loopEnabled = this.stutterPrev.enabled;
          this.loopStart = this.stutterPrev.start;
          this.loopEnd = this.stutterPrev.end;
          this.loopBuf = this.stutterPrev.buf;
          this.loopArming = this.stutterPrev.arming;
          this.stutterPrev = null;
          if (m.catchUp !== false) this.readPos = this.writePos - this.latency;
        }
        break;
      }

      // Jump the read head without changing rate — used to return to live.
      // The hand goes down. Anchor here; every target from now is measured from it.
      case 'scrubStart':
        this.scrubbing = true;
        this.scrubAnchor = this.readPos;
        this.scrubTarget = this.readPos;
        this.scrubSpan = Math.round(sampleRate * 0.016);   // a frame, until we know better
        this.scrubLastAt = null;
        this.scrubRate = 0;
        this.scrubVel = 0;
        break;

      case 'scrubTo':
        if (this.scrubbing && typeof m.delta === 'number' && m.delta === m.delta) {
          const prevTarget = this.scrubTarget;
          this.scrubTarget = this.scrubAnchor + m.delta;
          // THE HAND'S VELOCITY, which is what has to be carried between updates — and
          // it has to be SMOOTHED, because the raw figure is mostly quantisation noise.
          //
          // A mouse reports whole pixels. At this mapping a second of tape is about 71
          // pixels, so playing speed is 1.18 pixels per frame, and a real hand can only
          // ever deliver 1 or 2 of them: -15% or +70% of the speed, every frame, before
          // the hand has wobbled at all. MEASURED with a whole-pixel hand: the average
          // pitch right, and a spread of 35% against 5% for playback. Three semitones of
          // wobble, which is exactly why Brendan could not make it sound legible.
          //
          // This is the inertia a platter has. A record does not change speed the
          // instant your hand does; its mass averages the tremor out, and that is what
          // makes holding a steady speed possible for a person rather than a servo. Over
          // about three frames — long enough to swallow the quantisation, short enough
          // that a deliberate move still arrives at once.
          if (this.scrubSpan > 0) {
            const inst = (this.scrubTarget - prevTarget) / this.scrubSpan;
            this.scrubVel += (inst - this.scrubVel) * SCRUB_VEL_SMOOTH;
          }
          // LEARN THE CADENCE THE PANEL IS SENDING AT. The move has to last until the
          // next one arrives, so how far apart they are IS the duration to spread it
          // over. Smoothed, because one late frame should not stretch the next move.
          // The PANEL's clock, not this one. Port messages are delivered at block
          // boundaries, so two sent 16ms apart can arrive in the same block and read as
          // no time at all — which pulled the learned cadence down to 8ms against a hand
          // moving every 19ms, and the servo then asked for a rate it had to clamp.
          // MEASURED: a median rate pinned at 16 for a gesture doing 6.5.
          const at = typeof m.at === 'number' ? m.at : null;
          if (at !== null && this.scrubLastAt !== null) {
            const dtMs = at - this.scrubLastAt;
            if (dtMs > 1) {
              const span = Math.max(sampleRate * 0.006, Math.min(sampleRate * 0.05, (dtMs / 1000) * sampleRate));
              this.scrubSpan = this.scrubSpan ? this.scrubSpan * 0.7 + span * 0.3 : span;
            }
          }
          if (at !== null) this.scrubLastAt = at;
        }
        break;

      // The hand comes off and the tape plays on from wherever it was left, at whatever
      // `rate` says — which is the honest tape behaviour: you moved it, it plays from
      // there. It also means you are now further behind live, which the status line
      // already says in amber and `to live` already undoes.
      case 'scrubEnd':
        this.scrubbing = false;
        break;

      case 'toLive':
        this.readPos = this.writePos - this.latency;
        break;

      case 'scope':
        // Off by default and off whenever nothing is drawing it: a push nobody reads
        // is work the audio thread does for no one.
        this.scopeOn = !!m.on;
        this.pending.length = 0;
        break;

      case 'loopSecondsBack': {
        const end = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
        this.loopStart = end - Math.floor(sampleRate * (m.seconds || 2));
        this.loopEnd = end;
        this.loopArming = false;
        this.loopSource = 'seconds';
        this.loopSeconds = m.seconds || 2;
        this.armLoop();
        break;
      }
      case 'query':
        this.port.postMessage({
          type: 'state',
          mode: this.mode,
          rate: this.lastRate,
          interp: this.interp,
          sampleRate,
          bufferSeconds: this.len / sampleRate,
          latencySec: this.latency / sampleRate,
          loopEnabled: this.loopEnabled,
          loopArming: this.loopArming,
          loopSource: this.loopSource,
          loopSeconds: this.loopSeconds,
          loopLenSec: (this.loopEnd - this.loopStart) / sampleRate,
          behindLiveSec: (this.writePos - this.readPos) / sampleRate,
          secondsRecorded: Math.min(this.writePos, this.len) / sampleRate,
        });
        break;
    }
  }

  // A LOOP READS FROM ITS OWN COPY, not from the ring it was taken out of.
  //
  // The ring keeps recording underneath — it has to, or there would be nothing to
  // return to when the loop is switched off. But that means a loop left running is
  // overwritten by live audio once the write head laps it, so after sixty seconds it
  // stops being the thing you captured and slowly becomes the present. Invisible for
  // the 1s/2s/4s/8s buttons, because nobody holds one for a minute; fatal for a loop
  // you tap in and out and then leave alone, which is the whole point of tapping it.
  //
  // So arming a loop copies the region out. Stable for as long as you like, and off
  // still drops you back onto a ring that never stopped recording.
  at(chan, i) {
    if (this.loopEnabled && this.loopBuf) {
      const n = this.loopBuf[chan].length;
      const j = i - this.loopStart;
      return this.loopBuf[chan][((j % n) + n) % n];
    }
    const len = this.len;
    return this.ring[chan][((i % len) + len) % len];
  }

  head() {
    return this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
  }

  markIn() {
    this.loopStart = this.head();
    this.loopArming = true;
    this.loopEnabled = false;
    this.loopBuf = null;
    this.loopSource = 'tap';
    this.loopSeconds = 0;
  }

  closeLoop() {
    const end = this.head();
    // Marking `out` before `in` is a reasonable thing to do by accident, and the
    // reasonable answer is the region between them either way.
    if (end < this.loopStart) { this.loopEnd = this.loopStart; this.loopStart = end; }
    else this.loopEnd = end;
    this.loopArming = false;
    this.loopSource = 'tap';
    this.armLoop();
  }

  // Copy [loopStart, loopEnd) out of the ring. Clamped to what the ring still holds:
  // a loop cannot be made out of audio that has already been overwritten.
  armLoop() {
    // FLOOR FIRST. In tape mode the loop bounds come from readPos, which is a FLOAT the
    // moment the rate is anything but exactly 1 — and every rate change is a ramp, so
    // one press of reverse leaves it fractional for ever. Using it as an array index
    // read `ring[3.7]`, which is `undefined`, which a Float32Array stores as NaN. The
    // whole loop buffer became NaN, the tape output NaN, and the DC-blocking biquad
    // downstream took NaN into its state and never came back: silent for good, while
    // still recording and still drawing its waveform. Brendan found it in ten minutes.
    this.loopStart = Math.floor(this.loopStart);
    this.loopEnd = Math.floor(this.loopEnd);
    const oldest = this.writePos - this.len + 2;
    if (this.loopStart < oldest) this.loopStart = oldest;
    const n = Math.floor(this.loopEnd - this.loopStart);
    if (n < 2) { this.loopBuf = null; this.loopEnabled = false; return false; }
    const buf = [new Float32Array(n), new Float32Array(n)];
    for (let c = 0; c < 2; c++) {
      const src = this.ring[c];
      const dst = buf[c];
      for (let i = 0; i < n; i++) {
        const k = this.loopStart + i;
        dst[i] = src[((k % this.len) + this.len) % this.len];
      }
    }
    this.loopBuf = buf;
    this.loopEnabled = true;
    // AND PLAY IT. In thru the process loop returns early and copies the input straight
    // through, so a loop armed from thru is enabled, lit, and completely inaudible —
    // the head sails past it. The seconds-back buttons had always engaged the tape from
    // the panel; the tap button did not, and Brendan hit it within a minute. Doing it
    // HERE covers every route into a loop, including the console and anything mapped to
    // MIDI, rather than each caller having to remember.
    this.mode = 'tape';
    return true;
  }

  // THE GAP INTEGRATES WHAT PASSES UNDER IT — which is also, exactly, the anti-aliasing
  // this needs. One idea, arrived at from both ends.
  //
  // THE DIGITAL PROBLEM: reading the ring at four times speed is decimation by four, and
  // everything in the source above an eighth of the sample rate folds down into the
  // audible band as inharmonic junk. That fold is the sound of a computer.
  //
  // AND IT CANNOT BE FILTERED AFTERWARDS. Once the junk is in the output it sits at the
  // same frequencies as real content; a filter on the output can only remove both. The
  // first version of this did precisely that and was wrong: anti-aliasing has to happen
  // in the SOURCE, before the samples are thrown away.
  //
  // THE TAPE ANSWER: a head does not read a point, it reads a gap, and what comes out is
  // the flux over the whole gap at once. Sweep the tape past it faster and each moment
  // of output covers more tape — so the head averages more, and the very short
  // wavelengths average themselves away instead of folding. That is not an emulation of
  // an analogue artefact, it is the same integral a real head performs, and it happens
  // to be a moving-average lowpass in the source domain with a cutoff that falls exactly
  // as the speed rises.
  //
  // Below about 1.2x it is one tap and this is untouched playback. At the clamp it is
  // sixteen, which is the most work a gesture can ask for and only while it lasts.
  sampleSpan(chan, pos, rate) {
    const taps = this.gapTaps;
    if (taps <= 1) return this.sample(chan, pos);
    const step = rate / taps;
    let sum = 0;
    for (let k = 0; k < taps; k++) sum += this.sample(chan, pos + step * k);
    return sum / taps;
  }

  sample(chan, pos) {
    const i0 = Math.floor(pos);
    const t = pos - i0;

    // CUBIC WHENEVER A HAND IS ON IT, whatever the tape's own setting says.
    //
    // The interp button is a character choice for ordinary playback, where the rate is 1
    // and linear costs nothing because every read lands on a real sample. A scratch is
    // the opposite case by definition — the position is fractional at every speed but
    // one — and there linear "alternates exact samples with midpoints", which is the
    // grit. Four taps instead of two, on a gesture that lasts a second or two, is not a
    // cost worth protecting.
    if (this.interp === 'cubic' || this.scrubbing) {
      // Catmull-Rom. Four taps instead of two; markedly less imaging at non-unity
      // rates, where linear alternates exact samples with midpoints and leaves a
      // strong image at the source frequency.
      const y0 = this.at(chan, i0 - 1);
      const y1 = this.at(chan, i0);
      const y2 = this.at(chan, i0 + 1);
      const y3 = this.at(chan, i0 + 2);
      const a = -0.5 * y0 + 1.5 * y1 - 1.5 * y2 + 0.5 * y3;
      const b = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3;
      const c = -0.5 * y0 + 0.5 * y2;
      return ((a * t + b) * t + c) * t + y1;
    }

    const a = this.at(chan, i0);
    const b = this.at(chan, i0 + 1);
    return a + (b - a) * t;
  }

  process(inputs, outputs, params) {
    const input = inputs[0];
    const output = outputs[0];
    const n = output[0].length;

    // Always record.
    for (let c = 0; c < 2; c++) {
      const src = (input && (input[c] || input[0])) || null;
      const ring = this.ring[c];
      for (let i = 0; i < n; i++) {
        ring[(this.writePos + i) % this.len] = src ? src[i] : 0;
      }
    }

    // The scope rides along with the write head, so what it draws is what was
    // recorded — not what is being played, which may be somewhere else entirely.
    if (this.scopeOn) {
      const l = (input && input[0]) || null;
      const r = (input && (input[1] || input[0])) || null;
      for (let i = 0; i < n; i++) {
        const a = l ? (l[i] < 0 ? -l[i] : l[i]) : 0;
        const b = r ? (r[i] < 0 ? -r[i] : r[i]) : 0;
        const v = a > b ? a : b;
        if (v > this.bucketPeak) this.bucketPeak = v;
        if (++this.bucketFill >= this.bucketLen) {
          this.pending.push(this.bucketPeak);
          this.bucketPeak = 0;
          this.bucketFill = 0;
        }
      }
    }

    if (this.mode === 'thru') {
      for (let c = 0; c < output.length; c++) {
        const src = (input && (input[c] || input[0])) || null;
        if (src) output[c].set(src);
        else output[c].fill(0);
      }
      this.writePos += n;
      this.readPos = this.writePos - this.latency;
      // thru returns early, so the scope has to be pushed from here as well — and thru
      // is the mode the mixer normally sits in, so forgetting it means a waveform that
      // only appears once you engage the tape.
      this.sendScope(n);
      return true;
    }

    const rateArr = params.rate;
    const newest = this.writePos + n - 1;
    const oldest = newest - this.len + 2;

    // ONE RATE FOR THE BLOCK WHILE A HAND IS ON IT. Solving per sample would chase the
    // target with an ever-shrinking rate and arrive sounding like a fade rather than a
    // move; solving once per block gives a constant rate that lands exactly on the
    // target at the end of the block, which is a speed you can hear.
    let scrubRate = 0;
    if (this.scrubbing) {
      // SPREAD THE MOVE ACROSS THE GAP BETWEEN UPDATES, not across one block.
      //
      // Dividing by `n` — arriving inside a single 128-sample block — is what the first
      // version did, and it is wrong twice over. Pointer updates arrive about every
      // 16ms; closing the whole gap in the first 2.7ms of that means 2.7ms of very fast
      // audio followed by 13ms of a stopped record, over and over. Brendan's report was
      // "I can barely hear it", and the take he sent shows it: a duty cycle, not a
      // scratch. It also made the PITCH wrong — a 16x blip instead of the steady 2x the
      // hand was actually doing, because rate is distance over TIME and the time was
      // whatever the block happened to be.
      //
      // Divided by the interval instead, the rate is the hand's real velocity: the
      // distance your fingers moved over the time they took to move it. Which is what a
      // record does.
      // VELOCITY FIRST, POSITION AS A CORRECTION.
      //
      // Chasing the target position alone leaves the tape moving in ripples. Updates
      // arrive on animation frames, about every 17ms; the audio thread runs every 2.7ms.
      // So for six blocks out of seven the target is a STALE, STATIONARY point, and a
      // servo aimed at it decelerates into it and then leaps when the next one lands.
      // That is a 60Hz wobble in the playback speed, which is 60Hz FM on everything you
      // are listening to. MEASURED with a perfectly regular hand: the average pitch
      // right to 2%, and a spread of 20% against 5% for ordinary playback. Brendan heard
      // it before it was measured: "garbled and unrecognisable".
      //
      // Carrying the hand's velocity fixes the ripple at its source. Between updates the
      // tape keeps moving at the speed the hand was last seen moving, which is what a
      // record does; the position term then only has to mop up the difference, gently,
      // instead of being the whole signal.
      const span = this.scrubSpan > 0 ? this.scrubSpan : n;
      const correction = (this.scrubTarget - this.readPos) / (sampleRate * SCRUB_CORRECT_SEC);
      const want = this.scrubVel + correction;
      // A hand cannot move a record at fifty times speed, and something that tries to
      // is a bad number rather than a gesture. Clamped so a wild value costs a moment
      // of fast audio instead of tearing through the whole ring.
      const capped = Math.max(-SCRUB_MAX_RATE, Math.min(SCRUB_MAX_RATE, want === want ? want : 0));

      // SMOOTHED, BECAUSE THE PITCH IS THE PRODUCT AND JITTER IN IT IS AUDIBLE.
      //
      // Solving the position exactly every block means every wobble in when a frame
      // lands becomes a wobble in speed, and speed is what you HEAR. Measured on a
      // steady hand at 0.6x: the average pitch was right to within 2%, and the spread
      // between the 10th and 90th percentile was 42% — which is not a wrong speed, it is
      // wow and flutter, and it is what Brendan meant by "garbled and unrecognisable".
      //
      // A one-pole on the RATE fixes it without lying about the position: the head still
      // chases the same target, so the average speed stays exact and the error stays
      // bounded; only the changes in speed are made gradual. The time constant is short
      // enough (~20ms) that a fast scratch still arrives, and long enough to swallow a
      // frame landing late.
      scrubRate = capped;
    }

    for (let i = 0; i < n; i++) {
      let rate;
      if (this.scrubbing) {
        // SMOOTHED PER SAMPLE, NOT PER BLOCK — which is the whole difference between
        // this and the varispeed slider Brendan says already sounds close to right.
        //
        // That slider sets the `rate` AudioParam through setTargetAtTime, and an
        // AudioParam glides at audio rate: every sample gets its own value. This used to
        // compute one rate per 128-sample block and hold it flat across all of them,
        // which is a staircase 370 steps a second — inaudible as pitch, audible as
        // roughness, and exactly the "stepped" he described. Running the same one-pole
        // inside the loop costs one multiply-add a sample and makes the speed a
        // continuous curve, like the slider's.
        this.scrubRate += (scrubRate - this.scrubRate) * SCRUB_SMOOTH;
        rate = this.scrubRate;
      } else {
        rate = rateArr.length > 1 ? rateArr[i] : rateArr[0];
      }
      this.lastRate = rate;

      // A LOOP DOES NOT WRAP UNDER YOUR HAND. Inside a loop the head is normally folded
      // back at the boundary, which would fight a target on the other side of it and
      // make the record feel like it was tearing out of your fingers. While scrubbing
      // the ring's own limits are the only ones.
      if (!this.scrubbing && this.loopEnabled && this.loopEnd > this.loopStart) {
        const loopLen = this.loopEnd - this.loopStart;
        if (this.readPos >= this.loopEnd) this.readPos -= loopLen;
        else if (this.readPos < this.loopStart) this.readPos += loopLen;
      } else {
        // Never read ahead of what has been written, or off the back of the ring.
        const wanted = this.readPos;
        if (this.readPos > newest - 1) this.readPos = newest - 1;
        if (this.readPos < oldest) this.readPos = oldest;

        // RE-ANCHOR WHEN THE EDGE STOPS YOU, or the hand and the tape come apart.
        //
        // Forward of live there is no tape. Without this, a drag that runs into the live
        // edge leaves the target somewhere the head can never reach, the error never
        // closes, and the servo sits at the clamp — MEASURED: a still hand reporting a
        // rate of 16, screaming, because it was still trying to get somewhere that does
        // not exist. Worse, dragging back then does nothing until the target has
        // travelled all the way back through the distance it overshot, which is the
        // opposite of how a hand on a record behaves.
        //
        // Moving the anchor by however much the clamp took keeps the mapping one-to-one
        // with the finger: you are always holding the piece of tape you are touching.
        const corr = this.readPos - wanted;
        if (corr && this.scrubbing) { this.scrubAnchor += corr; this.scrubTarget += corr; }
      }

      // Full level from |rate| = RATE_FADE upwards, so genuine slow speeds (0.25 and
      // below are still well clear of it) are untouched.
      const RATE_FADE = 0.02;
      const target = Math.min(1, Math.abs(rate) / RATE_FADE);
      this.stopGain += (target - this.stopGain) * this.fadeCoeff;

      // How wide the gap is, in source samples, follows the speed. Recomputed once a
      // block; the rate is smoothed over 10ms and cannot move far inside 2.7ms.
      if (i === 0) {
        const ar = Math.abs(rate);
        this.gapTaps = ar > 1.2 ? Math.min(16, Math.round(ar)) : 1;
      }

      for (let c = 0; c < output.length; c++) {
        // THE GUARD. Flooring above fixes the bug that produced NaN; this makes the
        // whole class survivable. A single NaN leaving here enters a biquad whose state
        // never recovers, so the cost is not a glitch but permanent silence — far too
        // much to pay for an arithmetic slip. One comparison a sample is nothing beside
        // that.
        const v = this.sampleSpan(c, this.readPos, rate) * this.stopGain;
        output[c][i] = v === v ? v : 0;
      }
      this.readPos += rate;
    }

    this.writePos += n;
    this.sendScope(n);
    return true;
  }

  // One message every SCOPE_SEND_MS carrying whatever buckets completed since the
  // last, plus the positions the panel needs to place a play head, a live edge and a
  // loop region against them. Everything travels together on purpose: a waveform drawn
  // against a head read a frame later lines up wrongly, and the error looks like drift.
  sendScope(n) {
    if (!this.scopeOn) return;
    this.sinceSend += n;
    if (this.sinceSend < (sampleRate * SCOPE_SEND_MS) / 1000) return;
    this.sinceSend = 0;
    const buckets = this.pending.length ? Float32Array.from(this.pending) : EMPTY;
    this.pending.length = 0;
    this.port.postMessage({
      type: 'scope',
      buckets,
      hz: SCOPE_HZ,
      sampleRate,
      // The context's own sample clock, so a channel's waveform and the tape's can be
      // placed on one timeline. writePos counts what THIS node has written, which is
      // not the same number and differs by however long the context ran before it.
      frame: currentFrame,
      writePos: this.writePos,
      readPos: this.readPos,
      latency: this.latency,
      mode: this.mode,
      scrubbing: this.scrubbing,
      // How long the servo thinks each move has to last, in samples. Without this the
      // only symptom of a wrong cadence is a rate pinned at the clamp, which looks
      // identical to a hand moving very fast.
      scrubSpan: this.scrubSpan,
      scrubErr: this.scrubbing ? this.scrubTarget - this.readPos : 0,
      lastRate: this.lastRate,
      loopEnabled: this.loopEnabled,
      loopArming: this.loopArming,
      loopSource: this.loopSource,
      loopSeconds: this.loopSeconds,
      loopStart: this.loopStart,
      loopEnd: this.loopEnd,
      len: this.len,
    }, buckets.byteLength ? [buckets.buffer] : []);
  }
}

// Faster than any hand, slow enough that a wild target cannot cross the ring in a
// block. Sixteen times speed is already an unusable screech; this is a guard, not a
// musical limit.
const SCRUB_MAX_RATE = 16;

// One pole on the scrub rate, at roughly a 20ms time constant for a 128-sample block.
// Slower than this and a flick feels rubbery; faster and frame jitter is audible as
// flutter.
// PER SAMPLE, so this is a time constant rather than a per-block fraction. Ten
// milliseconds: fast enough that a flick arrives, slow enough that neither a block
// boundary nor a frame landing late can be heard as a step.
const SCRUB_SMOOTH = 1 - Math.exp(-1 / (0.010 * sampleRate));

// How gently the position error is worked off once velocity is doing the work. Long
// enough not to reintroduce the ripple it was brought in to remove; short enough that the
// tape stays under your finger rather than drifting away from it.
// LONG, DELIBERATELY. The target arrives quantised to whole pixels, and one pixel here
// is 14ms of tape — so a correction that closes the error in 80ms turns every single
// pixel of hand movement into a 17% kick in the speed, which measured as the whole of
// the remaining wobble. Velocity is what tracks the hand; this only has to stop slow
// drift, so it can afford to be gentle. The cost is a few milliseconds of position lag,
// which nobody can hear, against pitch jitter, which everybody can.
const SCRUB_CORRECT_SEC = 0.25;

// How much of each update's velocity estimate to believe. The rest is the previous
// estimate — the platter's mass.
const SCRUB_VEL_SMOOTH = 0.25;

const EMPTY = new Float32Array(0);

registerProcessor('tape', TapeProcessor);
