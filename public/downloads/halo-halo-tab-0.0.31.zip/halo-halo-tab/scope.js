// The tape's waveform.
//
// The tape worklet already holds sixty seconds of stereo, so nothing here buffers audio
// — it keeps a cheap summary of it: one peak per 10ms, pushed from the worklet as the
// buckets complete. Sixty seconds of that is 6000 numbers, which is why the whole
// minute is kept even though only twelve seconds are drawn. A different window, or
// scrubbing back through the buffer, then costs nothing but arithmetic.
//
// WHAT THE LOOP LINES ARE FOR. The 1s/2s/4s/8s buttons grab the last N seconds, so they
// reach BACKWARDS from the moment you press — which makes choosing the start of a loop
// a matter of guessing where you were N seconds ago. The lines mark exactly where each
// button's loop would begin, so a phrase arriving at the pink line is a phrase the 8s
// button will start on. The buttons carry the same colours.
//
// SCOPED, like snapshot.js and record.js: these are classic scripts sharing one global
// scope, and a repeated top-level name is a SyntaxError that silently kills the file.
(() => {

// THE PLAY HEAD IS ANCHORED, and the tape moves past it — which is what a tape does.
// Past to its left, future to its right.
//
// There IS a future whenever you are behind live: the channels keep recording forwards
// while the head sits in the past, so the seconds between the head and the live edge
// are already on the tape and can be drawn. At live there is nothing there yet, and an
// empty right-hand side is the correct answer rather than a gap to apologise for — it
// is also the plainest possible statement that you are at the present.
//
// The room is reserved whether or not it is occupied, because later features live there
// too: loop points tapped ahead of the head, and scrubbing.
const PAST_SEC = 10;
const FUTURE_SEC = 4;
const WINDOW_SEC = PAST_SEC + FUTURE_SEC;
const HEAD_FRAC = PAST_SEC / WINDOW_SEC;
const RING_SEC = 60;     // how much is kept — the tape's whole buffer
const LOOPS = [1, 2, 4, 8];

let hz = 100;
let ring = new Float32Array(RING_SEC * hz);
let written = 0;         // absolute bucket count, so the ring can be read backwards
let last = null;         // the most recent scope message
let canvas = null;
let ctx = null;
let raf = 0;
let on = false;
// Scratch for one column of the picture per pixel, reused by every canvas. The first
// path version computed each column TWICE — once tracing the top edge, once tracing the
// bottom — which cancelled out most of what batching the fill had saved.
let scratch = new Float32Array(0);
function scratchFor(w) {
  if (scratch.length < w) scratch = new Float32Array(w);
  return scratch;
}

// A SECOND one, because a source strip draws two shapes and the future's columns are
// computed while the past's are still on the page. Sharing the one buffer happened to
// work only because the past is filled before the future is computed — a fact no
// comment stated and any reordering would have quietly broken.
let scratchB = new Float32Array(0);
function scratchForB(w) {
  if (scratchB.length < w) scratchB = new Float32Array(w);
  return scratchB;
}

// Trace a filled envelope from precomputed column heights. NaN means "nothing recorded
// for this column", which is a gap in the shape rather than a zero.
function fillEnvelope(g, vals, w, mid, room) {
  g.beginPath();
  let start = -1;
  for (let x = 0; x <= w; x++) {
    const v = x < w ? vals[x] : NaN;
    if (v === v) { if (start < 0) { start = x; g.moveTo(x, mid - Math.max(0.5, v * room)); }
      else g.lineTo(x, mid - Math.max(0.5, v * room)); continue; }
    if (start >= 0) {
      for (let b = x - 1; b >= start; b--) g.lineTo(b, mid + Math.max(0.5, vals[b] * room));
      g.closePath();
      start = -1;
    }
  }
  g.fill();
}
// Whether it SHOULD be running, as distinct from whether it is. The retry below exists
// because the tape does not exist until a channel does — but without this it also
// undid every deliberate stop within a second, which meant the scope could not be
// turned off at all. A test caught it; nothing else would have.
let wanted = true;

function sizeCanvas() {
  if (!canvas) return;
  const r = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const w = Math.max(1, Math.round(r.width * dpr));
  const h = Math.max(1, Math.round(r.height * dpr));
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w;
    canvas.height = h;
  }
}

function onScope(msg) {
  if (msg.hz && msg.hz !== hz) {
    hz = msg.hz;
    ring = new Float32Array(RING_SEC * hz);
    written = 0;
  }
  const b = msg.buckets;
  for (let i = 0; i < b.length; i++) ring[(written + i) % ring.length] = b[i];
  written += b.length;
  last = msg;
  // The tape's own controls repaint from this, twenty times a second, so a button
  // reflects the loop within a frame of the press rather than within half a second of
  // the next poll.
  if (typeof tapeLoopPaint === 'function') tapeLoopPaint(msg);
}

// Absolute sample position -> x, measured from the PLAY HEAD rather than from the edge
// of the picture. The head never moves and everything slides past it, so the live edge
// appears where it actually is — which makes how far behind live you are a distance you
// can see rather than a number you have to read.
function xOf(pos, w, m) {
  const secs = (pos - m.readPos) / m.sampleRate;
  return w * HEAD_FRAC + (secs / WINDOW_SEC) * w;
}

function draw() {
  if (!on || !canvas || !ctx) return;
  sizeCanvas();
  const w = canvas.width;
  const h = canvas.height;
  const dpr = window.devicePixelRatio || 1;
  const css = getComputedStyle(document.documentElement);
  const tape = css.getPropertyValue('--tape').trim() || '#58c26a';

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#0b0b0b';
  ctx.fillRect(0, 0, w, h);

  const m = last;
  if (!m) { schedule(); return; }

  const mid = h / 2;

  // The waveform. Each column asks the ring what was recorded at the moment that column
  // stands for; columns past the live edge get no answer and are left empty, which is
  // how "there is no future yet" draws itself.
  // ONE PATH, not a rectangle per column, and each column computed ONCE. Measured: a
  // rectangle per column cost 10.7% of a core for the tape and four sources.
  const samplesPerBucket = m.sampleRate / hz;
  const vals = scratchFor(w);
  const base = m.readPos - (w * HEAD_FRAC / w) * WINDOW_SEC * m.sampleRate;
  const perPx = (WINDOW_SEC * m.sampleRate) / w;
  for (let x = 0; x < w; x++) {
    const idx = Math.floor((base + x * perPx) / samplesPerBucket);
    vals[x] = (idx < 0 || idx >= written || idx < written - ring.length)
      ? NaN : ring[idx % ring.length];
  }
  ctx.fillStyle = tape;
  fillEnvelope(ctx, vals, w, mid, mid - 2);

  // A running loop is shown by DIMMING EVERYTHING ELSE rather than by tinting the
  // region — a pale wash over a bright waveform is close to invisible, which is what
  // the first version did. Darkening the rest makes the loop the lit part of the
  // picture, which is what it is.
  if (m.loopEnabled && m.loopEnd > m.loopStart) {
    const x0 = xOf(m.loopStart, w, m);
    const x1 = xOf(m.loopEnd, w, m);
    const a = Math.min(x0, x1);
    const b = Math.max(x0, x1);
    ctx.fillStyle = 'rgba(0,0,0,.62)';
    if (a > 0) ctx.fillRect(0, 0, a, h);
    if (b < w) ctx.fillRect(b, 0, w - b, h);
    ctx.fillStyle = 'rgba(255,255,255,.55)';
    if (a >= 0) ctx.fillRect(a, 0, Math.max(1, dpr), h);
    if (b <= w) ctx.fillRect(b - dpr, 0, Math.max(1, dpr), h);
    // A loop can be longer than the window or scrolled off the back of it — which will
    // be the normal case once loops can be tapped in and out at any length. Say so at
    // the edge rather than drawing nothing and letting it read as no loop at all.
    if (a < 0) {
      ctx.fillStyle = 'rgba(255,255,255,.7)';
      ctx.font = `${Math.round(9 * dpr)}px ui-monospace, monospace`;
      ctx.fillText('◀ loop', 4 * dpr, h - 5 * dpr);
    }
  }

  // Where each loop button would START its loop, measured from the same place the
  // worklet measures it: the read head in tape mode, the delayed write head in thru.
  const end = m.mode === 'tape' ? m.readPos : m.writePos - m.latency;
  ctx.font = `${Math.round(9 * dpr)}px ui-monospace, monospace`;
  for (const s of LOOPS) {
    const x = xOf(end - s * m.sampleRate, w, m);
    if (x < 0 || x > w) continue;
    const col = css.getPropertyValue('--loop' + s).trim() || '#888';
    ctx.fillStyle = col;
    ctx.fillRect(x, 0, Math.max(1, dpr), h);
    ctx.fillText(s + 's', x + 3 * dpr, 10 * dpr);
  }

  // The live edge — where recording has actually reached. In thru it sits a quarter of
  // a second right of the head; after a reverse pass it can be most of the window away,
  // and everything between the two is future you can still play forwards into.
  const xl = xOf(m.writePos, w, m);
  if (xl >= 0 && xl <= w) {
    ctx.fillStyle = 'rgba(255,255,255,.3)';
    ctx.fillRect(xl - dpr, 0, Math.max(1, dpr), h);
    ctx.fillStyle = 'rgba(255,255,255,.45)';
    ctx.font = `${Math.round(9 * dpr)}px ui-monospace, monospace`;
    ctx.fillText('live', xl + 4 * dpr, 10 * dpr);
  }

  // The play head. It never moves; the tape moves past it.
  const xr = w * HEAD_FRAC;
  ctx.fillStyle = '#fff';
  ctx.fillRect(xr - dpr / 2, 0, Math.max(1, dpr), h);

  drawSources();
  schedule();
}

// THIRTY FRAMES, not sixty. A waveform scrolling past at a steady speed is smooth to
// the eye well below sixty — film manages at twenty-four — and drawing it is the most
// expensive thing this panel does: measured at 6.9% of a core for the tape and four
// sources, against 0.7% for every meter in the mixer. Halving it is free to look at and
// halves the bill.
//
// The METERS still run at the display's rate, because they are cheap and because
// smoothness is the whole point of them.
const DRAW_MS = 33;
let lastDraw = 0;

function schedule() {
  if (!on || raf) return;
  raf = requestAnimationFrame((t) => {
    raf = 0;
    if (t - lastDraw < DRAW_MS) { schedule(); return; }
    lastDraw = t;
    draw();
  });
}

// The same facts the hint row carried. refreshTape owns #t-state and remains its only
// writer — this is here as a seam, so a test can read what the scope believes without
// going through the element and finding out only that SOMETHING wrote to it.
function statusText() {
  if (!last) return '';
  const behind = Math.max(0, (last.writePos - last.readPos) / last.sampleRate);
  const held = Math.min(RING_SEC, last.writePos / last.sampleRate);
  return `${last.mode} · ${behind.toFixed(2)}s behind live · ${held.toFixed(0)}/${RING_SEC}s`;
}

// ---------------------------------------------------------------- per source
//
// One ring per channel, on the SAME absolute timeline as the tape. Every worklet here
// reports `currentFrame`, the context's own sample clock, so a source's picture and the
// tape's line up without correlating two clocks — and scrubbing the tape shows what each
// source was doing at that moment rather than what it is doing now.
const srcRings = new Map();   // tabId -> { ring, written, hz, frame }

// WHAT A SOURCE IS ABOUT TO PLAY.
//
// A capture can only ever give audio already heard. But a tab streaming over MSE has
// been handed twenty to thirty seconds of it before it is due, and the page hook reduces
// that to an envelope on the MEDIA clock. Placing it needs one correspondence: at the
// frame the reply arrived, the media clock read `mediaNow`. Everything else is
// arithmetic, and `rate` is in the reply because halo-halo tab changes playback speed itself.
const srcAhead = new Map();   // tabId -> { env, hz, endMedia, mediaNow, rate, paused, atFrame }
let aheadTimer = 0;
// How many times we have made a tab re-initialise because no header ever showed up.
// Bounded, because each one is an audible interruption and a tab that will never
// produce a header should be left alone rather than jogged every few seconds forever.
const reinitTried = new Map();

function aheadDecode(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function pollAhead() {
  if (!on || !last) return;
  const st = Mixer.state();
  for (const ch of st.channels || []) {
    if (ch.synthetic) continue;
    let r = null;
    try { r = await toContent(ch.tabId, { type: 'AHEAD' }); } catch {}
    // A SECOND NET UNDER THE ARMING, for the case the capture-time one cannot see: a
    // tab that NAVIGATES gets a brand new page and a brand new hook, unarmed, while the
    // panel still has it down as a tab it has already dealt with. Asking is nearly free
    // and the hook ignores a second arm, so the cheapest fix is to arm anything that
    // says it is not.
    // ARMED, PLAINLY APPENDING, AND STILL NO HEADER. Nothing can be decoded and nothing
    // ever will be: without an init segment the audio buffer never identifies itself.
    // The usual source of one is the quality change at capture, and the way that fails
    // is silent — setting a quality the player already has changes nothing. This is the
    // guard under that: if the header has not turned up by the time a tab has appended
    // this much, make it re-initialise outright.
    if (r && r.ok && r.armed === true && !r.sawInit && (r.appends || 0) > 30) {
      const n = (reinitTried.get(ch.tabId) || 0) + 1;
      if (n <= 2) {
        reinitTried.set(ch.tabId, n);
        try { videoForceReinit(ch.tabId); } catch {}
      }
      srcAhead.delete(ch.tabId);
      continue;
    }
    if (r && r.ok && r.armed === false) {
      try { await toContent(ch.tabId, { type: 'AHEAD_ARM' }); } catch {}
      srcAhead.delete(ch.tabId);
      continue;
    }
    if (!r || !r.ok || !r.ready || !r.env) { srcAhead.delete(ch.tabId); continue; }
    srcAhead.set(ch.tabId, {
      env: aheadDecode(r.env), hz: r.hz, endMedia: r.endMedia,
      mediaNow: r.mediaNow, rate: r.rate || 1, paused: !!r.paused,
      // The scope pushes at 20Hz, so this is at most 50ms stale — sub-pixel on a
      // fourteen-second window, and far cheaper than asking for the frame separately.
      atFrame: last.frame,
    });
  }
}

// The hook decodes on its own three-second clock, so asking oftener than that returns
// the same block again.
function startAhead() { if (!aheadTimer) aheadTimer = setInterval(pollAhead, 2500); }
function stopAhead() { clearInterval(aheadTimer); aheadTimer = 0; srcAhead.clear(); reinitTried.clear(); }

// 'tape'  — every strip shares the tape's timeline and its anchored head, so reading
//           down the column tells you what each source was contributing AT THE MOMENT
//           you are hearing. When the tape is behind live the right-hand side fills
//           with real future, because the sources kept recording while the head sat in
//           the past.
// 'live'  — each strip's right edge is this instant, independent of the tape.
//
// Kept as a switch because the difference only shows when the tape is behind live, and
// that is a thing to feel rather than to be told: with the head 7.76s back, the same x
// means two different moments in the two schemes, and 'live' invites a comparison down
// the column that is simply wrong.
let srcMode = 'tape';

function onSource(msg) {
  let e = srcRings.get(msg.tabId);
  if (!e || e.hz !== msg.hz) {
    e = { ring: new Float32Array(RING_SEC * msg.hz), written: 0, hz: msg.hz, frame: 0 };
    srcRings.set(msg.tabId, e);
  }
  const b = msg.buckets;
  for (let i = 0; i < b.length; i++) e.ring[(e.written + i) % e.ring.length] = b[i];
  e.written += b.length;
  e.frame = msg.frame;
  // Buckets are placed by the frame they END at, so the ring can be read by time
  // rather than by how many happen to have arrived.
  e.endFrame = msg.frame;
}

// The tape's read head, in the context's absolute frames. readPos and writePos are both
// counted by the tape NODE, so their difference is meaningful while neither is directly
// comparable to a channel's clock; `frame` is what bridges them.
function headFrame(m) {
  return m.frame - (m.writePos - m.readPos);
}

// Draw one source's envelope onto the same window the tape is drawn on. Returns false
// when there is nothing to draw yet, so a caller can leave the strip blank rather than
// painting an empty box that looks like silence.
function drawSource(canvas, tabId) {
  const e = srcRings.get(tabId);
  const m = last;
  if (!canvas) return false;
  const ctx2 = canvas.getContext('2d');
  const r = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  const w = Math.max(1, Math.round(r.width * dpr));
  const h = Math.max(1, Math.round(r.height * dpr));
  if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  ctx2.clearRect(0, 0, w, h);
  if (!e || !m || !e.written) return false;

  const head = srcMode === 'live' ? m.frame : headFrame(m);
  const frac = srcMode === 'live' ? 1 : HEAD_FRAC;
  const perBucket = e.hz;                      // buckets per second
  const mid = h / 2;
  const css = getComputedStyle(canvas);
  // One path, each column computed once — the reason the tape's is.
  const vals = scratchFor(w);
  const startFrame = head - frac * WINDOW_SEC * m.sampleRate;
  const perPx = (WINDOW_SEC * m.sampleRate) / w;
  for (let x = 0; x < w; x++) {
    const back = Math.round(((e.endFrame - (startFrame + x * perPx)) / m.sampleRate) * perBucket);
    const idx = e.written - 1 - back;
    vals[x] = (idx < 0 || idx >= e.written || idx < e.written - e.ring.length)
      ? NaN : e.ring[idx % e.ring.length];
  }
  ctx2.fillStyle = css.getPropertyValue('--ch').trim() || '#7ec87e';
  fillEnvelope(ctx2, vals, w, mid, mid - 1);

  // The future, where there is one. Drawn separately and dimmer: it has not been played
  // yet, and a picture that made it look identical to what has would be claiming more
  // than it knows — this is what the tab has DOWNLOADED, not what came out of the mixer.
  const ah = srcAhead.get(tabId);
  // A PAUSED SOURCE HAS NO FUTURE TO DRAW. Its block is downloaded and real, but it is
  // not approaching the head: nothing will arrive at any of these x positions until
  // somebody presses play, so every placement of it on this axis is a false claim about
  // time. Held still would be just as false — it would sit there as a wall of one
  // value. The entry is kept rather than dropped so the poll can report it and a check
  // can see it; only the drawing stops.
  if (ah && ah.env.length && !ah.paused) {
    const fut = scratchForB(w);
    let any = false;
    for (let x = 0; x < w; x++) {
      fut[x] = NaN;
      const secs = ((x - w * frac) / w) * WINDOW_SEC;
      const frame = head + secs * m.sampleRate;
      // THE LIVE EDGE IS `m.frame`. Everything on this side of the arithmetic is in the
      // context's clock — `head` is built from it — and `m.writePos` is not: it counts
      // what the tape NODE has written, from zero, and the two agree only because the
      // node happens to be built a few milliseconds after the context. MEASURED at 128
      // samples apart, so the wrong one was wrong by 2.7ms rather than by anything you
      // could see. Left as a note rather than a war story: this is the right clock, and
      // the next thing to move the tape's construction is what would have found out.
      if (frame <= m.frame) continue;             // the past is the capture's to draw
      const mediaT = ah.mediaNow + ((frame - ah.atFrame) / m.sampleRate) * ah.rate;
      const idx = ah.env.length - 1 - Math.round((ah.endMedia - mediaT) * ah.hz);
      if (idx < 0 || idx >= ah.env.length) continue;
      fut[x] = ah.env[idx] / 255;
      any = true;
    }
    if (any) {
      ctx2.globalAlpha = 0.42;
      fillEnvelope(ctx2, fut, w, mid, mid - 1);
      ctx2.globalAlpha = 1;
    }
  }

  // The same anchored head the tape draws, so the strips read as one picture.
  ctx2.fillStyle = 'rgba(255,255,255,.75)';
  ctx2.fillRect(w * frac - dpr / 2, 0, Math.max(1, dpr), h);
  return true;
}

// Registered strips. One animation loop draws the tape and every source together, so
// they cannot fall out of step with each other — and a strip whose element has left the
// document prunes itself rather than being something a caller has to remember to remove.
const sourceViews = new Set();

function attachSource(canvas, tabId) {
  if (!canvas) return false;
  attachScrub(canvas);
  for (const v of sourceViews) if (v.canvas === canvas) { v.tabId = tabId; return true; }
  sourceViews.add({ canvas, tabId });
  return true;
}

function drawSources() {
  for (const v of [...sourceViews]) {
    if (!v.canvas.isConnected) { sourceViews.delete(v); continue; }
    drawSource(v.canvas, v.tabId);
  }
}

function startSources() {
  const r = Mixer.channelScope(true, onSource);
  return r || { ok: false };
}

function stopSources() {
  srcRings.clear();
  return Mixer.channelScope(false);
}

// ---- SCRATCHING ------------------------------------------------------------------
//
// Grab the waveform and the tape moves with your hand. The mapping is the same one the
// drawing uses, run backwards: the picture is WINDOW_SEC wide, so a drag of `dx` across
// a canvas of width `w` is `(dx / w) * WINDOW_SEC` of tape.
//
// DRAGGING LEFT GOES FORWARD, which is worth saying out loud because either answer
// sounds defensible until you try it. Later audio sits to the RIGHT of the head, so
// pulling the picture leftward is what brings it under the head — the same direction
// your hand moves a record to play it early. Reversed, it feels like the picture is
// scrolling rather than the tape being handled.
const scrubbed = new WeakSet();
let scrub = null;      // { pointerId, startX, width, delta, sent, frame }

function scrubMove(e) {
  if (!scrub || e.pointerId !== scrub.pointerId) return;
  const dx = e.clientX - scrub.startX;
  const secs = -(dx / scrub.width) * WINDOW_SEC;
  scrub.delta = secs * (last ? last.sampleRate : 48000);
}

// ONE UPDATE PER FRAME, EVERY FRAME, FOR AS LONG AS THE HAND IS DOWN — a pump, not an
// echo of the pointer.
//
// Sending only when a pointer event arrives sounds thriftier and is worse, because the
// worklet has to spread each move over the time until the next one and pointer events do
// not arrive on a regular beat. Two moves inside one frame become a single message
// carrying twice the distance in one frame's time, which is a rate spike; a frame with no
// move at all sends nothing, so the head arrives early and sits still. MEASURED: a median
// rate pinned at the clamp for a gesture doing five or six times speed, with the average
// perfectly correct.
//
// Pumped every frame, each message carries exactly one frame of hand movement over
// exactly one frame of time, which is the definition of the hand's velocity. A still hand
// re-sends the same target, the error goes to zero, and the tape stops — which is right.
// Stamped with the panel's clock because port messages reach the audio thread in bursts
// at block boundaries, so arrival times say nothing about when they were sent.
function scrubPump() {
  if (!scrub) return;
  scrub.sent++;
  try { Mixer.tapeCmd({ cmd: 'scrubTo', delta: scrub.delta, at: performance.now() }); } catch {}
  scrub.frame = requestAnimationFrame(scrubPump);
}

function scrubEnd(e) {
  if (!scrub || (e && e.pointerId !== scrub.pointerId)) return;
  if (scrub.frame) cancelAnimationFrame(scrub.frame);
  const el = scrub.el;
  scrub = null;
  try { Mixer.tapeCmd({ cmd: 'scrubEnd' }); } catch {}
  try { el.releasePointerCapture(e.pointerId); } catch {}
  el.classList.remove('scrubbing');
}

function scrubStart(el, e) {
  if (scrub) return;
  // ENGAGING IS PART OF THE GESTURE. In thru there is no rope to pull — the head sits
  // at the live edge by definition — so grabbing the waveform drops onto the tape, the
  // way putting a hand on a deck is how you start using it. The worklet's own mode
  // change leaves the head at the standing latency, which is the rope.
  if (!last || last.mode !== 'tape') { try { Mixer.tapeSet({ mode: 'tape' }); } catch {} }
  const rect = el.getBoundingClientRect();
  scrub = { pointerId: e.pointerId, startX: e.clientX, width: rect.width || 1,
            delta: 0, sent: 0, frame: 0, el };
  // setPointerCapture throws on synthetic pointer ids, which is how every test drives it.
  try { el.setPointerCapture(e.pointerId); } catch {}
  el.classList.add('scrubbing');
  try { Mixer.tapeCmd({ cmd: 'scrubStart' }); } catch {}
  scrub.frame = requestAnimationFrame(scrubPump);
  // So a drag on a channel's strip cannot also reach whatever is under it.
  e.preventDefault();
}

// Both surfaces: the tape's own waveform, and every channel's — they are all on the
// tape's timeline, so dragging any of them is a hand on the same tape.
function attachScrub(el) {
  if (!el || scrubbed.has(el)) return false;
  scrubbed.add(el);
  el.style.touchAction = 'none';    // or a touch drag scrolls the panel instead
  el.style.cursor = 'grab';
  el.addEventListener('pointerdown', (e) => scrubStart(el, e));
  el.addEventListener('pointermove', scrubMove);
  el.addEventListener('pointerup', scrubEnd);
  el.addEventListener('pointercancel', scrubEnd);
  return true;
}

function startScope() {
  wanted = true;
  canvas = document.getElementById('scope');
  if (!canvas) return { ok: false, reason: 'no canvas' };
  ctx = canvas.getContext('2d');
  attachScrub(canvas);
  const r = Mixer.tapeScope(true, onScope);
  if (!r || !r.ok) return r || { ok: false, reason: 'tape not ready' };
  // The sources are part of the same picture, so they come up with it rather than
  // needing a second thing switched on.
  startSources();
  startAhead();
  on = true;
  schedule();
  return { ok: true };
}

function stopScope() {
  wanted = false;
  on = false;
  stopSources();
  stopAhead();
  if (raf) cancelAnimationFrame(raf);
  raf = 0;
  try { Mixer.tapeScope(false); } catch {}
  return { ok: true };
}

// The tape does not exist until a channel does, so the scope keeps asking. Cheap, and
// it means the waveform appears the moment there is anything to draw rather than only
// if you happened to add a channel before the panel finished loading.
setInterval(() => { if (wanted && !on) startScope(); }, 1000);

Object.assign(window, {
  scopeStart: startScope,
  scopeSources: startSources,
  scopeSourcesOff: stopSources,
  scopeDrawSource: drawSource,
  scopeAttachSource: attachSource,
  scopeViewCount: () => sourceViews.size,
  scopeSourceCount: () => srcRings.size,
  // What the drawing actually has, per source — so a check measures the rings the
  // picture is made from rather than a second subscription of its own. There is only
  // ever ONE subscriber to Mixer.channelScope, so a test that subscribes separately
  // silently replaces this one and then measures something that stopped updating.
  // Raw ring access, for comparing drawing schemes without a second copy of the data.
  scopeSourceMode: (m) => { if (m === 'tape' || m === 'live') srcMode = m; return srcMode; },
  scopeAhead: () => [...srcAhead].map(([tabId, a]) =>
    ({ tabId, buckets: a.env.length, hz: a.hz, endMedia: a.endMedia,
       mediaNow: a.mediaNow, rate: a.rate, paused: !!a.paused,
       secondsAhead: +(a.endMedia - a.mediaNow).toFixed(2) })),
  scopePollAhead: pollAhead,
  // What a check needs to see: whether a hand is down, and what has been sent.
  scopeScrub: () => (scrub ? { down: true, delta: scrub.delta, sent: scrub.sent } : { down: false }),
  scopeAttachScrub: attachScrub,
  scopeReinitTried: () => [...reinitTried],
  // Put a known block of future in without a tab, a capture or a network. What a check
  // most needs to say about the lookahead is WHERE ON THE PICTURE it lands, and that is
  // arithmetic against a real tape — so the tape stays real and only the block is made
  // up. `atFrame` defaults to now, which is what a reply that just arrived would carry.
  //
  // NOTE FOR ANYONE WRITING ONE: do not also fake `last`. The live-edge test compares
  // the context clock against the tape node's own sample count, and those two are equal
  // only in a fake — which is precisely how a wrong comparison passes.
  scopeSetAhead: (tabId, a) => {
    if (!a) { srcAhead.delete(tabId); return srcAhead.size; }
    srcAhead.set(tabId, {
      env: a.env instanceof Uint8Array ? a.env : Uint8Array.from(a.env),
      hz: a.hz || 100, endMedia: a.endMedia, mediaNow: a.mediaNow, rate: a.rate || 1,
      atFrame: a.atFrame == null ? (last ? last.frame : 0) : a.atFrame,
      paused: !!a.paused,
    });
    return srcAhead.size;
  },
  scopeAheadDecode: aheadDecode,
  scopeRawRing: (tabId) => { const e = srcRings.get(tabId); if (!e) return null;
    return (idx) => (idx < 0 || idx >= e.written || idx < e.written - e.ring.length)
      ? null : e.ring[idx % e.ring.length]; },
  scopeSourceInfo: () => [...srcRings].map(([tabId, e]) =>
    ({ tabId, buckets: e.written, frame: e.frame, hz: e.hz })),
  scopeHeadFrame: () => (last ? headFrame(last) : null),
  scopeStop: stopScope,
  scopeOn: () => on,
  scopeWanted: () => wanted,
  scopeLast: () => last,
  scopeWindowSec: () => WINDOW_SEC,
  scopePastSec: () => PAST_SEC,
  scopeFutureSec: () => FUTURE_SEC,
  scopeHeadFrac: () => HEAD_FRAC,
  scopeRingSec: () => RING_SEC,
  scopeBuckets: () => written,
  scopeLoopMarks: () => LOOPS.slice(),
  scopeStatus: statusText,
});

})();
