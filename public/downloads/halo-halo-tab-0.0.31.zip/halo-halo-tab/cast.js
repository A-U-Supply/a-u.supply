// Casting: what Chrome will do, what an extension cannot, and the one useful thing
// left in between.
//
// THE HONEST BOUNDARY, first, because it is the whole design. An extension cannot
// initiate casting. There is no `chrome.cast` extension API; the Presentation API
// wants an https URL a receiver can fetch, which a `chrome-extension://` page is not;
// and Remote Playback refuses a MediaStream source, which is the only kind this mixer
// has. Every route ends in the same place: **the browser's own Cast menu, driven by a
// human**. Nothing shipped here changes that, and a button claiming otherwise would be
// a lie with a nice icon on it.
//
// WHAT MAKES IT WORK ANYWAY: the finished mix leaves through `ctx.destination` in THIS
// page, so it is the panel tab's audio. Chrome's "Cast tab" carries a tab's audio and
// its picture. So casting the PANEL sends the mix and the video grid together — the
// source tabs keep playing in the background, unmirrored and unheard directly. That is
// a real answer to the request, it just is not one an extension performs.
//
// So what this builds is the part that IS ours: putting the panel into the state worth
// mirroring, and saying plainly which menu does the rest. Per Brendan's own rule about
// explicit affordances — a labelled button and the steps written out, not an icon and
// the assumption you already know.
//
// SCOPED, like snapshot.js and record.js: classic scripts, one global scope, and a
// repeated top-level name is a SyntaxError that kills the whole file.
(() => {

// Reported, never promised. These say what this Chrome exposes — not that a device is
// present, not that casting will work. Anything stronger would be guessing on the
// user's behalf about hardware we cannot see.
function castSupport() {
  return {
    presentation: typeof window.PresentationRequest === 'function',
    remotePlayback: !!(window.HTMLMediaElement && 'remote' in HTMLMediaElement.prototype),
    // The one that actually matters, and the only one we can be sure of: the mix is
    // this tab's audio, so a tab cast carries it.
    tabAudioIsTheMix: true,
  };
}

// Put the panel into the state worth mirroring: the grid, full screen, no overlays,
// and full capture quality — a cast to a television is the one time HQ is worth what
// it costs. Fullscreen needs a live user gesture, which the button click supplies.
async function prepareForCast() {
  const press = (id) => {
    const b = document.getElementById(id);
    if (b && b.getAttribute('aria-pressed') !== 'true') b.click();
  };

  if (typeof setVideoMode === 'function') setVideoMode(true);
  await new Promise((r) => setTimeout(r, 250)); // let the grid lay out before measuring it

  press('video-hq');
  press('video-clean');

  let full = false;
  try {
    await document.getElementById('video').requestFullscreen();
    full = true;
  } catch { /* denied, or the gesture went stale — the rest still helps */ }

  setCastStatus(
    full
      ? 'Ready. Now open Chrome’s ⋮ menu → Cast → choose your device → set Sources to “Cast tab”.'
      : 'Ready — but Chrome refused fullscreen, so press the fullscreen button yourself. Then ⋮ → Cast → your device → Sources: “Cast tab”.',
  );
  return { ok: true, fullscreen: full };
}

function setCastStatus(text) {
  const el = document.getElementById('cast-status');
  if (el) el.textContent = text || '';
}

function initCast() {
  const b = document.getElementById('cast-prep');
  if (b) b.addEventListener('click', () => prepareForCast());
}

Object.assign(window, {
  castPrepare: prepareForCast,
  castSupport,
});

initCast();
})();
