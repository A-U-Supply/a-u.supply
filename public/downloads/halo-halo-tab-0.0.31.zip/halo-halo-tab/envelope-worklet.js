// A waveform's worth of a single channel.
//
// The tape keeps its own summary because it already holds the audio; a channel holds
// nothing, so this rides alongside one and keeps the same shape of summary: the peak
// over each 10ms, pushed as the buckets complete. Deliberately NOT samples — a
// waveform needs an outline, and sending PCM for every channel would be a hundred
// times the traffic for a picture that could not show the difference.
//
// It reports `currentFrame`, the AudioContext's OWN sample clock, not a count of how
// much this node has seen. Those are different by however long the context had been
// running when the node was made — measured at 1.25 SECONDS on a first run, which is
// exactly the error that would have made a tape-aligned display quietly wrong. Every
// worklet here reports currentFrame for the same reason, so two pictures can be drawn
// against one timeline without correlating two clocks after the fact.
const HZ = 100;
const SEND_MS = 50;

class EnvelopeProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const opts = (options && options.processorOptions) || {};
    this.tabId = opts.tabId ?? null;
    this.bucketLen = Math.max(1, Math.round(sampleRate / HZ));
    this.peak = 0;
    this.fill = 0;
    this.pending = [];
    this.sinceSend = 0;
    this.on = true;
    this.port.onmessage = (e) => { if (e.data && e.data.type === 'on') this.on = !!e.data.value; };
  }

  process(inputs) {
    const input = inputs[0];
    const l = (input && input[0]) || null;
    const r = (input && (input[1] || input[0])) || null;
    const n = l ? l.length : 128;

    if (this.on) {
      for (let i = 0; i < n; i++) {
        const a = l ? (l[i] < 0 ? -l[i] : l[i]) : 0;
        const b = r ? (r[i] < 0 ? -r[i] : r[i]) : 0;
        const v = a > b ? a : b;
        if (v > this.peak) this.peak = v;
        if (++this.fill >= this.bucketLen) {
          this.pending.push(this.peak);
          this.peak = 0;
          this.fill = 0;
        }
      }
      this.sinceSend += n;
      if (this.sinceSend >= (sampleRate * SEND_MS) / 1000) {
        this.sinceSend = 0;
        const buckets = this.pending.length ? Float32Array.from(this.pending) : EMPTY;
        this.pending.length = 0;
        this.port.postMessage(
          { tabId: this.tabId, buckets, hz: HZ, sampleRate, frame: currentFrame + n },
          buckets.byteLength ? [buckets.buffer] : [],
        );
      }
    }

    // A channel that has been dropped takes its node with it, so there is nothing to
    // keep alive for — but while it exists it must keep being pulled, and returning
    // false would end it for good.
    return true;
  }
}

const EMPTY = new Float32Array(0);
registerProcessor('envelope', EnvelopeProcessor);
