// The PCM tap for a lossless take.
//
// MediaRecorder cannot make a WAV, so the WAV path needs the samples themselves. This
// processor sits on the same node the Opus path taps and hands the panel raw frames.
//
// It buffers before it posts. At a 128-frame render quantum a naive processor would
// postMessage 375 times a second; batching to 4096 frames makes that about twelve. Each
// flush copies out only the frames actually held and TRANSFERS that copy, so the audio
// thread never pays for a structured clone and its own two buffers are reused for ever.
//
// Stereo is not negotiable here — the whole point of the mixer is per-channel pan, and a
// take that downmixed would throw away the thing you spent the performance setting. When
// a source is mono the graph has already upmixed it by this point; `input[1] || input[0]`
// is the belt to that braces.
class CaptureProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const opts = (options && options.processorOptions) || {};
    this.size = opts.frames || 4096;
    this.left = new Float32Array(this.size);
    this.right = new Float32Array(this.size);
    this.n = 0;
    this.closed = false;
    this.port.onmessage = (e) => {
      // A take does not end on a block boundary. Flush whatever is held so the last
      // fraction of a second is in the file rather than in this object.
      if (e.data && e.data.type === 'flush') {
        this.flush(true);
        this.closed = true;
      }
    };
  }

  flush(final) {
    if (!this.n && !final) return;
    const l = this.left.buffer.slice(0, this.n * 4);
    const r = this.right.buffer.slice(0, this.n * 4);
    this.port.postMessage({ left: l, right: r, frames: this.n, final: !!final }, [l, r]);
    this.n = 0;
  }

  process(inputs) {
    if (this.closed) return true;
    const input = inputs[0];
    const l = (input && input[0]) || null;
    const r = (input && (input[1] || input[0])) || null;
    const n = l ? l.length : 128;
    for (let i = 0; i < n; i++) {
      this.left[this.n] = l ? l[i] : 0;
      this.right[this.n] = r ? r[i] : 0;
      this.n++;
      if (this.n === this.size) this.flush(false);
    }
    return true;
  }
}

registerProcessor('capture', CaptureProcessor);
