// The recorder: a take of the finished mix.
//
// It taps the LAST node before the speakers, after the tape and after the DC blocker,
// so what lands in the file is exactly what you heard — a reverse pass, a stutter, a
// speed ride, all baked in. Brendan chose that over the raw pre-tape blend: the
// recording is the performance, not the ingredients.
//
// TWO FORMATS, and the reason there are two is that the old trade turned out to be
// false. This used to be Opus only, on the grounds that Chrome encodes it itself so a
// long take costs no memory, where "WAV would have to be held whole in memory and
// written at the end" — buying Logic a drag-and-drop in exchange for a hard twenty
// minute ceiling. It does not have to be held at all: `showSaveFilePicker` hands back a
// WRITABLE STREAM, so a WAV is written to disk as it records and its header patched
// with the real sizes at the end. Lossless AND uncapped. Opus stays for the sessions
// where an eighth of the size matters more than opening the file without converting it.
//
// Both formats stream to the same writer for the same reason. Concatenated WebM chunks
// ARE the file, so there is nothing to be gained by holding them.
//
// THE PICKER GOES FIRST, before a single await, and that is a reversal worth stating.
// It used to save at the END and plain-download, because a cancelled dialog would have
// thrown away a take that had already been performed. Asking first inverts that: cancel
// now costs nothing, because nothing has been recorded yet. It also means the file lands
// where you put it instead of in ~/Downloads, and that the disk space is committed
// before an hour of WAV rather than after.
//
// Nothing here touches the audible path. The recorder is a second destination hung off
// the same node, so starting and stopping a take is inaudible — which is the whole
// point of being able to hit record in the middle of something good.
//
// SCOPED, for the reason snapshot.js is: these are classic scripts sharing one global
// scope, and a repeated top-level name is a SyntaxError that silently kills the file.
(() => {

// The named-option table, the shape audio.js already uses for video quality. The
// extension comes from HERE and not from a literal: the old code hardcoded '.webm'
// while the mime was chosen from a list, so the ogg fallback would have written a file
// named for a container it was not in.
const FORMATS = {
  wav: {
    label: 'lossless WAV',
    ext: '.wav',
    type: { description: 'WAV audio', accept: { 'audio/wav': ['.wav'] } },
    blurb: 'plays anywhere, drops straight into Logic',
  },
  opus: {
    label: 'small Opus',
    ext: '.webm',
    type: { description: 'WebM audio', accept: { 'audio/webm': ['.webm'] } },
    blurb: 'about an eighth the size; Logic wants it converted first',
  },
};

const OPUS_MIME = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/ogg;codecs=opus',
].find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m)) || '';

// What a minute of each format actually costs, DERIVED rather than written down.
// The hint said 11.5 MB — the 48 kHz figure — while Brendan's machine records at 44.1,
// where it is 10.1. A real 3.9-minute take is what caught it. The rate is the device's,
// so the only honest version of this number is one computed from the context in use.
const MB = 1024 * 1024;
function mbPerMin(key) {
  if (key === 'opus') return (192000 / 8) * 60 / MB;
  const ctx = Mixer.context && Mixer.context();
  const rate = (ctx && ctx.sampleRate) || 48000; // until the graph exists
  return rate * 2 * (BITS / 8) * 60 / MB;
}

const FMT_KEY = 'ym-recfmt';
const BITS = 16;          // per sample, for the WAV path
const HEADER = 44;        // bytes of RIFF before the first sample
const BATCH = 4096;       // frames the worklet holds before posting

let format = 'wav';

// The live take, whichever kind. One object rather than five loose variables, so the
// identity check below has something to check identity against.
//   { kind, name, writer, startedAt, bytes, clipped, queue,
//     recorder, dest,                    // opus
//     node, sink, channels, sampleRate } // wav
let take = null;
let lastTake = null; // { name, bytes, seconds, format, clipped }
// A take that exists on disk but has not been placed anywhere yet.
let pending = null;

// True between asking a take to stop and its ending arriving. MediaRecorder.stop()
// flips state to 'inactive' SYNCHRONOUSLY but delivers onstop a turn or more later, so
// without this flag `recording()` reads false in the gap and a second click starts a
// SECOND take on top of the one still finishing. The WAV path has the same gap while
// its last blocks are still being written.
let stopping = false;
// The in-flight stop, shared. Two callers asking the same take to stop must get the
// SAME promise: the second call used to re-arm `onstop`, which overwrote the first
// caller's handler and left that promise unable to ever settle. One take, one stop,
// one answer for everyone who asked.
let stopPromise = null;
// The addModule promise, kept so a second WAV take does not re-fetch the worklet — and
// keyed to the CONTEXT it was added to, because a processor is registered per
// AudioContext. A cached promise from a previous context would resolve instantly and
// then `new AudioWorkletNode(ctx, 'capture')` would throw on a name that context has
// never heard of.
let captureCtx = null;
let capturePromise = null;

const recording = () => !!take && !stopping;

const fmtDur = (s) => {
  const t = Math.max(0, Math.floor(s));
  const m = Math.floor(t / 60);
  return `${m}:${String(t % 60).padStart(2, '0')}`;
};

const fmtBytes = (b) =>
  b > 1024 * 1024 ? (b / 1024 / 1024).toFixed(1) + ' MB' : Math.round(b / 1024) + ' kB';

function takeName(ext) {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `halo-halo-take-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${ext}`;
}

// ---------------------------------------------------------------- format

function setFormat(next) {
  if (!FORMATS[next]) return { ok: false, reason: 'unknown format ' + next };
  if (recording()) return { ok: false, reason: 'not while a take is running' };
  format = next;
  try { localStorage.setItem(FMT_KEY, next); } catch {}
  paintFormat();
  return { ok: true, format };
}

// ---------------------------------------------------------------- writing

// TWO STAGES, and the split is the whole design.
//
// While recording, the take goes to a PRIVATE file on disk — the Origin Private File
// System, which needs no dialog and no permission prompt. Nothing interrupts the
// performance, and nothing is held in memory, so there is still no length limit.
// Measured in this panel: 10.7 GB of quota, and 60 MB written in 438 ms against the
// 176 kB/s a stereo WAV actually needs.
//
// The save dialog comes at the END, which is what Brendan asked for: being asked where
// to put a file is a fine thing to do after a performance and a terrible thing to do in
// the middle of one.
//
// That ordering used to be the dangerous one, because a cancelled dialog threw away a
// take that had already been played. It is not dangerous any more: the take is a real
// file that already exists, so cancelling KEEPS it and offers it back. The same
// mechanism recovers a take from a panel that was reloaded or crashed mid-recording,
// which every previous version simply lost.
const TAKE_DIR = 'takes';

async function takesDir() {
  const root = await navigator.storage.getDirectory();
  return root.getDirectoryHandle(TAKE_DIR, { create: true });
}

// Where a take is written WHILE it records.
let openTake = async (name) => {
  const dir = await takesDir();
  const fh = await dir.getFileHandle(name, { create: true });
  const w = await fh.createWritable();
  return {
    name,
    kind: 'opfs',
    write: (d) => w.write(d),
    writeAt: (pos, d) => w.write({ type: 'write', position: pos, data: d }),
    close: () => w.close(),
    file: () => fh.getFile(),
    discard: async () => { try { await (await takesDir()).removeEntry(name); } catch {} },
  };
};

// No OPFS. Holds the take in memory instead — which is where the twenty-minute ceiling
// went, so this path says so out loud rather than dying at minute twenty-one.
function memoryTake(name, mime) {
  const parts = [];
  return {
    name,
    kind: 'memory',
    capped: true,
    async write(d) { parts.push(d); },
    async writeAt(pos, d) { if (pos === 0 && parts.length) parts[0] = d; },
    async close() {},
    async file() { return new Blob(parts, { type: mime }); },
    async discard() { parts.length = 0; },
  };
}

// Where a finished take is DELIVERED. Returns a destination, or null for "cancelled",
// which here means kept rather than lost.
function fileWriter(w, name) {
  return { name, where: 'picked', write: (d) => w.write(d), close: () => w.close() };
}

let openWriter = async (name) => {
  const f = FORMATS[format];
  if (window.showSaveFilePicker) {
    try {
      const handle = await showSaveFilePicker({ suggestedName: name, types: [f.type] });
      return fileWriter(await handle.createWritable(), handle.name || name);
    } catch (e) {
      // Cancelled means kept, not lost. Anything else — a refused permission, an odd
      // filesystem — falls through to the download rather than stranding the take.
      if (e && e.name === 'AbortError') return null;
    }
  }
  return {
    name,
    where: 'downloads',
    async write(d) { this._blob = d; },
    async close() { download(this._blob, name); },
  };
};

// Writes are serialised through the take. At 192 kB/s the disk is never the bottleneck,
// but two overlapping writes to one stream are an error, and an interleaved pair would
// put the samples in the wrong order — which decodes perfectly and sounds like noise.
function enqueue(t, data) {
  t.queue = t.queue.then(() => t.writer.write(data)).catch((e) => { t.writeError = e; });
}

// ---------------------------------------------------------------- wav

function wavHeader(dataBytes, channels, rate) {
  const b = new ArrayBuffer(HEADER);
  const v = new DataView(b);
  const put = (off, s) => { for (let i = 0; i < s.length; i++) v.setUint8(off + i, s.charCodeAt(i)); };
  const bytesPerFrame = channels * (BITS / 8);
  put(0, 'RIFF');
  v.setUint32(4, 36 + dataBytes, true);
  put(8, 'WAVE');
  put(12, 'fmt ');
  v.setUint32(16, 16, true);            // fmt chunk length
  v.setUint16(20, 1, true);             // PCM, uncompressed
  v.setUint16(22, channels, true);
  v.setUint32(24, rate, true);
  v.setUint32(28, rate * bytesPerFrame, true);
  v.setUint16(32, bytesPerFrame, true);
  v.setUint16(34, BITS, true);
  put(36, 'data');
  v.setUint32(40, dataBytes, true);
  return new Uint8Array(b);
}

// Float32 in, interleaved signed 16-bit out.
//
// The clip count is not decoration. The graph is float and tolerates a sum above 1.0
// without complaint; sixteen-bit integers do not, and the mixer adds channels at unity
// gain. Making WAV the default therefore introduces a way to destroy a take silently,
// so the take counts what it had to clamp and says so at the end.
function onPcm(t, m) {
  if (m.frames) {
    const n = m.frames;
    const l = new Float32Array(m.left);
    const r = new Float32Array(m.right);
    const pcm = new Int16Array(n * 2);
    let clipped = 0;
    for (let i = 0; i < n; i++) {
      let a = l[i];
      let b = r[i];
      if (a > 1) { a = 1; clipped++; } else if (a < -1) { a = -1; clipped++; }
      if (b > 1) { b = 1; clipped++; } else if (b < -1) { b = -1; clipped++; }
      pcm[i * 2] = Math.round(a * 32767);
      pcm[i * 2 + 1] = Math.round(b * 32767);
    }
    t.clipped += clipped;
    t.bytes += pcm.byteLength;
    enqueue(t, new Uint8Array(pcm.buffer));
  }
  if (m.final && t.onFinal) t.onFinal();
}

async function startWav(ctx, out, t) {
  if (captureCtx !== ctx) {
    captureCtx = ctx;
    capturePromise = ctx.audioWorklet.addModule(chrome.runtime.getURL('record-worklet.js'));
  }
  await capturePromise;
  if (take !== t) return; // stopped while the module was loading

  t.channels = 2;
  t.sampleRate = ctx.sampleRate;
  t.bytes = HEADER;
  enqueue(t, wavHeader(0, t.channels, t.sampleRate));

  t.node = new AudioWorkletNode(ctx, 'capture', {
    numberOfInputs: 1,
    numberOfOutputs: 1,
    outputChannelCount: [1],
    channelCount: 2,
    channelCountMode: 'explicit',
    channelInterpretation: 'speakers',
    processorOptions: { frames: BATCH },
  });
  t.node.port.onmessage = (e) => { if (take === t) onPcm(t, e.data); };

  // A node whose output goes nowhere is not reachable from the destination, and an
  // unreachable node is never pulled — process() would simply not run and the take
  // would be an empty file with a perfectly good header. A silent sink puts the tap in
  // the graph without putting it in the sound.
  t.sink = ctx.createGain();
  t.sink.gain.value = 0;
  out.connect(t.node);
  t.node.connect(t.sink);
  t.sink.connect(ctx.destination);
}

async function finishWav(t) {
  // A take does not end on a block boundary, so ask the worklet for what it is holding
  // before pulling it out of the graph. If it never answers, half a second is a cheaper
  // loss than a stop that hangs.
  await new Promise((resolve) => {
    let done = false;
    const finish = () => { if (!done) { done = true; resolve(); } };
    const timer = setTimeout(finish, 500);
    t.onFinal = () => { clearTimeout(timer); finish(); };
    try { t.node.port.postMessage({ type: 'flush' }); } catch { clearTimeout(timer); finish(); }
  });

  try { Mixer.outputNode()?.disconnect(t.node); } catch {}
  try { t.node.disconnect(); } catch {}
  try { t.sink.disconnect(); } catch {}

  await t.queue;
  const dataBytes = Math.max(0, t.bytes - HEADER);
  try {
    await t.writer.writeAt(0, wavHeader(dataBytes, t.channels, t.sampleRate));
    await t.writer.close();
  } catch (e) {
    t.writeError = e;
  }
  return t;
}

// ---------------------------------------------------------------- opus

function startOpus(ctx, out, t) {
  t.dest = ctx.createMediaStreamDestination();
  // Stereo said out loud rather than inherited. It is the default, and the suite proves
  // the take really is two channels, but the whole feature is per-channel pan and a
  // silent downmix somewhere upstream would be the one bug nobody would think to look
  // for in a file that plays perfectly.
  t.dest.channelCount = 2;
  t.dest.channelCountMode = 'explicit';
  t.dest.channelInterpretation = 'speakers';
  out.connect(t.dest); // a tap; the speakers keep their own connection

  t.recorder = new MediaRecorder(t.dest.stream, { mimeType: OPUS_MIME, audioBitsPerSecond: 192000 });
  t.recorder.ondataavailable = (e) => {
    if (!e.data || !e.data.size || take !== t) return;
    t.bytes += e.data.size;
    enqueue(t, e.data);
  };
  // Without this an encoder failure leaves a recorder that is neither recording nor
  // ever going to call onstop — the exact shape of "the button still says stop".
  t.recorder.onerror = (e) => {
    const why = (e && e.error && e.error.name) || 'unknown error';
    teardown(t);
    setStatus(`Recording stopped — ${why}. Anything already captured was not saved.`, 'stopped');
  };
  // A timeslice rather than one blob at the end: the recorder hands over a chunk a
  // second, so the elapsed size on screen is real and a crashed tab loses a second
  // rather than the take.
  t.recorder.start(1000);
}

function finishOpus(t) {
  return new Promise((resolve) => {
    t.recorder.onstop = async () => {
      await t.queue;
      try { await t.writer.close(); } catch (e) { t.writeError = e; }
      resolve(t);
    };
    // stop() throws InvalidStateError on a recorder that is already inactive, and an
    // uncaught throw inside a Promise executor means the promise NEVER SETTLES and
    // onstop never comes — a stop button that stays a stop button for good.
    try {
      t.recorder.stop();
    } catch (e) {
      t.aborted = String((e && e.message) || e);
      // Close the file even though there is nothing worth putting in it. A writable
      // left open is a handle nobody will ever close and, when the person picked a
      // real location, an empty file sitting where they expected a take.
      t.writer.close().catch(() => {}).then(() => resolve(t));
    }
  });
}

// ---------------------------------------------------------------- transport

async function startRecording() {
  if (take) return { ok: false, reason: stopping ? 'still finishing the last take' : 'already recording' };
  const f = FORMATS[format];
  if (!f) return fail('unknown record format ' + format);
  if (format === 'opus' && !OPUS_MIME)
    return fail('this Chrome cannot record compressed audio — switch to lossless WAV');

  // Ask about CHANNELS, not about the graph. The first version of this guard tested
  // `Mixer.outputNode()` — but ensureAudio() builds the whole chain whether or not
  // anything is feeding it, so an empty mixer passed the check and recorded a
  // beautifully encoded ten minutes of silence. Finding that out at the end of a take
  // is the worst possible moment to find it out.
  //
  // It also has to run BEFORE the save dialog: opening a file picker only to refuse is
  // a worse way to say "there is nothing to record" than simply saying it.
  const st = Mixer.state();
  if (!st.channels || !st.channels.length)
    return fail('nothing to record yet — add a channel first', 'no channels');
  if (!Mixer.context() || !Mixer.outputNode())
    return fail('the audio graph is not running');

  // No dialog here, deliberately. Recording begins the instant you ask for it.
  const name = takeName(f.ext);
  const mime = Object.keys(f.type.accept)[0];
  let writer;
  try {
    writer = await openTake(name);
  } catch (e) {
    writer = memoryTake(name, mime);
    setStatus('No private storage available — this take is held in memory, so keep it short.',
      'in memory');
  }

  await Mixer.ensureAudio().catch(() => {});
  const ctx = Mixer.context();
  const out = Mixer.outputNode();
  if (!ctx || !out) {
    try { await writer.close(); } catch {}
    return fail('the audio graph is not running');
  }

  const t = {
    kind: format,
    name: writer.name || name,
    writer,
    startedAt: Date.now(),
    bytes: 0,
    clipped: 0,
    queue: Promise.resolve(),
  };
  take = t;
  try {
    if (format === 'wav') await startWav(ctx, out, t);
    else startOpus(ctx, out, t);
  } catch (e) {
    teardown(t);
    try { await writer.close(); } catch {}
    return fail(`could not start recording — ${(e && e.message) || e}`);
  }
  if (take !== t) return { ok: false, reason: 'superseded' };
  paint();
  return { ok: true, format: t.kind, name: t.name, where: writer.where };
}

// Releasing the tap and forgetting the take, from wherever it went wrong.
//
// The IDENTITY CHECK is the point. A stale ending — from a take that was already
// superseded — must not null out the take belonging to a NEWER one, which would orphan
// a live recorder: still encoding, no longer reachable, its audio going into a file
// nobody will ever be handed.
function teardown(which) {
  if (which && take !== which) return false;
  const t = take;
  if (t) {
    try { if (t.dest) Mixer.outputNode()?.disconnect(t.dest); } catch {}
    try { if (t.node) Mixer.outputNode()?.disconnect(t.node); } catch {}
    try { if (t.node) t.node.disconnect(); } catch {}
    try { if (t.sink) t.sink.disconnect(); } catch {}
  }
  take = null;
  stopping = false;
  stopPromise = null;
  paintButtons();
  // The format buttons go dead during a take, so they have to come back with the same
  // call that ends it. Leaving them to the tick meant half a second where the take was
  // over and the choice still refused to move.
  paintFormat();
  return true;
}

function stopRecording() {
  if (stopping && stopPromise) return stopPromise;
  if (!take) return Promise.resolve({ ok: false, reason: 'not recording' });
  const t = take;
  stopping = true;
  paintButtons();

  stopPromise = (t.kind === 'wav' ? finishWav(t) : finishOpus(t)).then(async (done) => {
    const seconds = (Date.now() - done.startedAt) / 1000;
    done.seconds = seconds;
    const bytes = done.bytes;
    const clipped = done.clipped;
    const name = done.name;
    if (!teardown(t)) return { ok: false, reason: 'superseded' };

    if (done.aborted) {
      setStatus('The recording ended on its own; nothing was saved.', 'not saved');
      return { ok: false, reason: done.aborted };
    }
    if (done.writeError) {
      setStatus(`Could not finish writing ${name} — ${done.writeError.message || done.writeError}.`,
        'write failed');
      return { ok: false, reason: String(done.writeError.message || done.writeError) };
    }

    lastTake = { name, bytes, seconds, format: done.kind, clipped };
    const clip = clipped
      ? ` ${clipped.toLocaleString()} samples clipped — pull the master down.`
      : '';

    // The recording is finished and safe on disk. NOW ask where it should live.
    const placed = await deliver(done);
    if (placed.kept) {
      setStatus(
        `Recorded ${name} — ${fmtDur(seconds)}, ${fmtBytes(bytes)}.${clip} Not saved anywhere yet; press "save take" to choose a place.`,
        `unsaved · ${fmtDur(seconds)}`,
      );
      return { ok: true, kept: true, name, bytes, seconds, format: done.kind, clipped };
    }
    if (!placed.ok) {
      setStatus(placed.reason, 'failed');
      return { ok: false, reason: placed.reason };
    }
    setStatus(
      `Saved ${placed.name} — ${fmtDur(seconds)}, ${fmtBytes(bytes)}.${clip}`,
      `saved · ${fmtDur(seconds)} · ${fmtBytes(bytes)}${clipped ? ' · clipped' : ''}`,
    );
    return { ok: true, name: placed.name, bytes, seconds, format: done.kind, clipped };
  }).catch((e) => {
    // Whatever went wrong, `stopping` must not survive it. It disables both buttons,
    // so a stop that threw on its way out would leave a panel that can never record
    // again — the 0.0.11 bug in a new coat.
    teardown(t);
    const why = String((e && e.message) || e);
    setStatus(`The take could not be finished — ${why}.`, 'failed');
    return { ok: false, reason: why };
  });
  return stopPromise;
}

// Hand the finished file over. The dialog lives HERE, after the performance.
//
// A cancelled dialog keeps the take rather than losing it — it is already a real file —
// and `pending` is what makes that legible instead of looking like it vanished.
async function deliver(t) {
  let blob;
  try {
    blob = await t.writer.file();
  } catch (e) {
    return { ok: false, reason: `the take could not be read back — ${(e && e.message) || e}` };
  }
  let dest = null;
  try {
    dest = await openWriter(t.name);
  } catch (e) {
    dest = null;
  }
  if (!dest) {
    pending = { writer: t.writer, name: t.name, bytes: t.bytes, seconds: t.seconds };
    paintPending();
    return { ok: false, reason: 'kept', kept: true, name: t.name };
  }
  try {
    await dest.write(blob);
    await dest.close();
  } catch (e) {
    pending = { writer: t.writer, name: t.name, bytes: t.bytes, seconds: t.seconds };
    paintPending();
    return { ok: false, reason: `could not write ${t.name} — ${(e && e.message) || e}`, kept: true };
  }
  await t.writer.discard();
  return { ok: true, name: dest.name || t.name, where: dest.where };
}

// Try again on a take that was recorded but never placed — a cancelled dialog, or a
// panel that was reloaded while one was running.
async function savePending() {
  if (!pending) return { ok: false, reason: 'nothing waiting' };
  const p = pending;
  const out = await deliver({ writer: p.writer, name: p.name, bytes: p.bytes, seconds: p.seconds });
  if (out.ok) {
    pending = null;
    paintPending();
    setStatus(`Saved ${out.name}.`, 'saved');
  } else if (!out.kept) {
    setStatus(out.reason, 'failed');
  }
  return out;
}

// A take found on disk that nobody placed. Every version before this one simply lost a
// take when the panel reloaded mid-recording; now it is still there to be claimed.
async function findPending() {
  try {
    const dir = await takesDir();
    let newest = null;
    for await (const [name, handle] of dir.entries()) {
      if (handle.kind !== 'file') continue;
      // Chrome keeps a `.crswap` scratch file beside an open writable. It is not a
      // take, and offering one back would hand over a file that is not the recording.
      // Found by a test that expected one file on disk and counted two.
      if (name.endsWith('.crswap')) continue;
      const f = await handle.getFile();
      if (!f.size) { try { await dir.removeEntry(name); } catch {} continue; }
      if (!newest || f.lastModified > newest.at) newest = { name, at: f.lastModified, bytes: f.size };
    }
    if (!newest) return;
    const dir2 = await takesDir();
    const fh = await dir2.getFileHandle(newest.name);
    pending = {
      name: newest.name,
      bytes: newest.bytes,
      seconds: null,
      writer: {
        name: newest.name,
        file: () => fh.getFile(),
        discard: async () => { try { await (await takesDir()).removeEntry(newest.name); } catch {} },
      },
    };
    paintPending();
    setStatus(`An unsaved take is waiting — ${newest.name}, ${fmtBytes(newest.bytes)}.`, 'take waiting');
  } catch {}
}

// One click, one decision. Refusing during the stop gap is what stops a fast second
// click starting a take underneath the one still being written.
function toggleRecording() {
  if (stopping) return Promise.resolve({ ok: false, reason: 'still finishing the last take' });
  return recording() ? stopRecording() : startRecording();
}

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

function fail(reason, short) {
  setStatus(reason, short);
  return { ok: false, reason };
}

// ---------------------------------------------------------------- ui

function setStatus(text, short) {
  const el = document.getElementById('rec-status');
  if (el) el.textContent = text || '';
  // Video mode had no status element at all, so a take there reported nothing on
  // screen. It gets its own, and a SHORTER line: the column is 118px wide and
  // bottom-anchored, so the full saved-take sentence once grew it upwards until the
  // buttons left the tape box entirely. Callers pass the short form; the CSS caps the
  // element as well, because the next long message will not have asked permission.
  const v = document.getElementById('video-rec-status');
  if (v) v.textContent = (short !== undefined ? short : text) || '';
}

// A recording you have forgotten about is the failure mode, so the elapsed time and the
// size are on screen the whole time, in both modes.
//
// THIS TICK NEVER STOPS, and that is the fix for the bug Brendan found: the button used
// to be repaintable only from inside onstop, so any path where that callback did not
// arrive left it reading "stop recording" with nothing able to correct it. Now the UI is
// RECONCILED against the recorder twice a second no matter what happened, so the worst
// a missed callback can cost is half a second of wrong label. A steady interval that
// does almost nothing is a small price for a control that cannot lie.
function paint() {
  paintButtons();
  paintFormat();
  paintPending();
  if (!recording()) return;
  const seconds = (Date.now() - take.startedAt) / 1000;
  setStatus(
    `Recording — ${fmtDur(seconds)}, ${fmtBytes(take.bytes)}. It stops when you say so.`,
    `${fmtDur(seconds)} · ${fmtBytes(take.bytes)}`,
  );
}

function paintButtons() {
  const on = recording();
  for (const id of ['rec-toggle', 'video-rec']) {
    const b = document.getElementById(id);
    if (!b) continue;
    b.setAttribute('aria-pressed', String(on));
    b.classList.toggle('rec-on', on);
    b.disabled = stopping;
    b.textContent = stopping
      ? 'finishing…'
      : on
        ? id === 'video-rec' ? '■ stop' : '■ stop recording'
        : id === 'video-rec' ? '● rec' : '● record';
  }
}

// The "save take" button exists only while there is a take to save. A control that is
// visible and does nothing is worse than one that is not there.
function paintPending() {
  for (const b of document.querySelectorAll('[data-recsave]')) {
    b.hidden = !pending;
    b.textContent = 'save take…';
  }
}

function paintFormat() {
  const f = FORMATS[format];
  for (const b of document.querySelectorAll('[data-recfmt]')) {
    const mine = b.dataset.recfmt === format;
    b.setAttribute('aria-pressed', String(mine));
    b.disabled = !!take;
  }
  const hint = document.getElementById('rec-format');
  if (hint) {
    const rate = (Mixer.context && Mixer.context() || {}).sampleRate;
    hint.textContent = `${f.label} · about ${mbPerMin(format).toFixed(1)} MB per minute`
      + (format === 'wav' && rate ? ` at ${(rate / 1000).toFixed(1)} kHz` : '')
      + ` · ${f.blurb}`;
  }
}

function initRecord() {
  for (const id of ['rec-toggle', 'video-rec']) {
    const b = document.getElementById(id);
    if (b) b.addEventListener('click', () => toggleRecording());
  }
  for (const b of document.querySelectorAll('[data-recfmt]')) {
    b.addEventListener('click', () => setFormat(b.dataset.recfmt));
  }
  for (const b of document.querySelectorAll('[data-recsave]')) {
    b.addEventListener('click', () => savePending());
  }
  // Restored THROUGH the setter, never by stamping the buttons. video.js learned this
  // the hard way with the HQ toggle: stamping aria-pressed left a control claiming a
  // state the module underneath it did not have.
  let saved = null;
  try { saved = localStorage.getItem(FMT_KEY); } catch {}
  setFormat(FORMATS[saved] ? saved : 'wav');

  paintButtons();
  paintFormat();
  paintPending();
  findPending();
  setInterval(paint, 500);
}

Object.assign(window, {
  recStart: startRecording,
  recStop: stopRecording,
  recToggle: toggleRecording,
  recIsRecording: recording,
  recFormat: () => format,
  recSetFormat: setFormat,
  recFormats: () => Object.keys(FORMATS),
  recMbPerMin: mbPerMin,
  recMime: () => (format === 'opus' ? OPUS_MIME : 'audio/wav'),
  recLastTake: () => lastTake,
  recElapsed: () => (recording() ? (Date.now() - take.startedAt) / 1000 : 0),
  recIsStopping: () => stopping,
  recBytes: () => (take ? take.bytes : 0),
  recClipped: () => (take ? take.clipped : (lastTake ? lastTake.clipped : 0)),
  // The suite needs to stop a take without a file landing in ~/Downloads on every run.
  recSetDownload: (fn) => { download = fn; },
  // And it needs to finish a take without a native save dialog opening, which nothing
  // in the harness can dismiss. `recSetWriter` replaces the delivery destination:
  // `() => null` is a cancelled dialog, which must KEEP the take rather than lose it.
  recSetWriter: (fn) => { openWriter = fn; },
  // Where a take is written while recording. Tests hold it in memory so a run leaves
  // nothing behind in the browser's private storage.
  recSetTakeStore: (fn) => { openTake = fn; },
  recMemoryTake: (name) => memoryTake(name, Object.keys(FORMATS[format].type.accept)[0]),
  recPending: () => (pending ? { name: pending.name, bytes: pending.bytes } : null),
  recFindPending: async () => { pending = null; await findPending(); return pending ? pending.name : null; },
  recSavePending: savePending,
});

initRecord();
})();
