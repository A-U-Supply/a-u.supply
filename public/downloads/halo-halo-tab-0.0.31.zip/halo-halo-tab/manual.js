// The manual's own page. Two jobs.
//
// The version comes from the MANIFEST, never from a literal — the same rule the mixer's
// heading follows, and for the same reason: Chrome keeps running an unpacked extension
// from the folder you loaded it from, so a manual that asserted its own version could
// confidently describe a build you are not running. That is the whole point of the
// manual living in here rather than only on the website.
(() => {
  const ver = document.getElementById('ver');
  try {
    ver.textContent = chrome.runtime.getManifest().version;
  } catch {
    // "Extension context invalidated" — the extension was reloaded while this window
    // stayed open. The manual is still readable, so say nothing rather than throw.
    ver.textContent = '';
  }

  // Closing it. `chrome.windows.remove` on this window is the reliable route from an
  // extension page; `window.close()` is the fallback for the case where this page has
  // been opened as an ordinary tab rather than a popup, where there is no window of
  // ours to remove. Esc as well, because that is what a popup ought to answer to.
  async function closeManual() {
    try {
      const w = await chrome.windows.getCurrent();
      const tabs = await chrome.tabs.query({ currentWindow: true });
      // Only take the whole window if this page IS the whole window. Closing someone's
      // browser window because the manual happened to be a tab in it would be rude.
      if (w && tabs.length === 1) { await chrome.windows.remove(w.id); return; }
    } catch {}
    window.close();
  }

  const closeBtn = document.getElementById('close');
  if (closeBtn) closeBtn.addEventListener('click', () => closeManual());
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeManual();
  });

  // Saving as a PDF is Chrome's print engine, not a bundled library: it is already
  // there, it renders this page exactly as the print stylesheet says, and it costs the
  // download nothing.
  //
  // A COLLAPSED <details> PRINTS NOTHING, so every section is opened first — a PDF
  // missing whichever sections happened to be shut is worse than no PDF. The previous
  // state is put back afterwards so the window is where you left it.
  const pdf = document.getElementById('pdf');
  if (pdf) {
    pdf.addEventListener('click', () => {
      const all = [...document.querySelectorAll('details')];
      const was = all.map((d) => d.open);
      all.forEach((d) => { d.open = true; });
      // print() blocks until the dialog is dismissed, so the restore goes straight
      // after it. Hanging it on `afterprint` instead meant that if that event never
      // arrived the page simply stayed fully expanded — which a test caught by
      // stubbing print() and finding every section still open afterwards.
      try { window.print(); } finally { all.forEach((d, i) => { d.open = was[i]; }); }
    });
  }
})();
