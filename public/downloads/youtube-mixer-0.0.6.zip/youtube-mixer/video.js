// Video mode: the performance layout.
//
// Same channels, same tape, same MIDI bindings — only the presentation changes.
//
// Cell:
//   ┏━━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━┓
//   ┃ lvl spd ┃    video    ┃ mtr M S ┃   faders run the FULL height of the row
//   ┃  (full  ┃    16:9     ┃     ♪ × ┃   pan sits at the foot of the right column
//   ┃  height)┃  top-align  ┃ ──█──── ┃
//   ┣━━━━━━━━━┻━━━━━━━━━━━━━┻━━━━━━━━━┫
//   ┃ ▓▓ title ░░░    ▶  ⏸            ┃   progress fills behind the outlined title
//   ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
//
// The grid is sized in JS so each cell is exactly video-plus-strips. Cells are
// otherwise 2:1 while the video is 16:9, which left ~20% of every cell as dead black.
// Now any leftover is a single margin around the whole grid instead of eight slivers.
//
// Depends on globals from panel.js (setGain, setMute, setSolo, setPan, dropChannel,
// toContent, dragging) and audio.js (Mixer). Classic scripts, shared scope, last.

const CHANNEL_COLOURS = ['#e0524f', '#e2c240', '#4f86e0', '#eae6de'];
const colourFor = (i) => CHANNEL_COLOURS[i % CHANNEL_COLOURS.length];

const RATE_MIN = 0.25;
const RATE_MAX = 2.5;

const tiles = new Map(); // tabId -> { el, parts }
let videoOn = false;
let videoTimer = null;
let hq = false;
const homes = new Map();

function stash(id) {
  const el = document.getElementById(id);
  if (el && !homes.has(el)) homes.set(el, { parent: el.parentNode, next: el.nextSibling });
  return el;
}
function restore(id) {
  const el = document.getElementById(id);
  const home = el && homes.get(el);
  if (home) home.parent.insertBefore(el, home.next);
}

// Drag helper: pointer capture so a drag that leaves a small tile still tracks.
function draggable(el, onMove) {
  const go = (e) => onMove(e, el.getBoundingClientRect());
  el.addEventListener('pointerdown', (e) => {
    // Capture is a nicety — it keeps a drag tracking when the pointer leaves a small
    // tile. It throws if the id is not an active pointer, and an unguarded throw here
    // aborts the handler before the drag even starts, so the control does nothing.
    try { el.setPointerCapture(e.pointerId); } catch {}
    dragging = el;
    go(e);
  });
  el.addEventListener('pointermove', (e) => { if (dragging === el) go(e); });
  const rel = () => { if (dragging === el) dragging = null; };
  el.addEventListener('pointerup', rel);
  el.addEventListener('pointercancel', rel);
}

function buildTile(tabId) {
  const el = document.createElement('div');
  el.className = 'tile';
  el.innerHTML = `
    <div class="tile__left">
      <div class="vfader vfader--lvl" data-help="Channel level. The full height of the tile is your throw.">
        <div class="vfader__fill"></div><span class="vfader__lab">lvl</span>
      </div>
      <div class="vfader vfader--spd" data-help="Playback speed, like a turntable's pitch fader. Double-click to return to 1.00.">
        <div class="vfader__fill"></div><span class="vfader__lab">spd</span>
      </div>
    </div>

    <div class="tile__mid">
      <div class="tile__vidbox">
        <video class="tile__v" autoplay muted playsinline></video>
        <canvas class="tile__viz" width="480" height="120"></canvas>
      </div>
    </div>

    <div class="tile__right">
      <div class="tile__rtop">
        <div class="vmeter" data-help="Live level of this channel."><div class="vmeter__fill"></div></div>
        <div class="tile__btns">
          <button class="tile__btn tile__m" data-help="Silence this channel without moving its fader.">M</button>
          <button class="tile__btn tile__s" data-help="Hear only this channel. Shift-click to solo several.">S</button>
          <button class="tile__btn tile__pitch" aria-pressed="true" data-help="On: speed changes without pitch. Off: pitch rides with speed, the way tape behaves.">&#9834;</button>
          <button class="tile__btn tile__x" data-help="Remove this tab from the mixer.">&times;</button>
        </div>
      </div>
      <div class="hpan" data-help="Stereo position. Double-click to centre.">
        <span class="hpan__dot"></span>
      </div>
    </div>

    <div class="tile__bottom">
      <span class="tile__titlewrap" data-help="Playback position — the fill behind the title. Drag to seek.">
        <span class="tile__progress"></span>
        <span class="tile__title"></span>
      </span>
      <button class="tile__btn tile__play" data-help="Resume this video.">&#9654;</button>
      <button class="tile__btn tile__pause" data-help="Pause this video. It stays in the mixer.">&#10073;&#10073;</button>
    </div>`;

  const q = (s) => el.querySelector(s);
  const parts = {
    left: q('.tile__left'), right: q('.tile__right'), bottom: q('.tile__bottom'),
    lvl: q('.vfader--lvl'), lvlFill: q('.vfader--lvl .vfader__fill'),
    spd: q('.vfader--spd'), spdFill: q('.vfader--spd .vfader__fill'),
    meter: q('.vmeter__fill'), vidbox: q('.tile__vidbox'),
    v: q('.tile__v'), viz: q('.tile__viz'), vizCtx: q('.tile__viz').getContext('2d'),
    m: q('.tile__m'), s: q('.tile__s'), pitch: q('.tile__pitch'), x: q('.tile__x'),
    pan: q('.hpan'), panDot: q('.hpan__dot'),
    titlewrap: q('.tile__titlewrap'), progress: q('.tile__progress'), title: q('.tile__title'),
    play: q('.tile__play'), pause: q('.tile__pause'),
    crop: null, streamAttached: false, rateVal: 1, duration: 0,
  };

  const keepsPitch = () => parts.pitch.getAttribute('aria-pressed') === 'true';
  const sendRate = (v) => toContent(tabId, { type: 'SET_RATE', rate: v, preservesPitch: keepsPitch() });

  draggable(parts.lvl, (e, r) => {
    const frac = Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height));
    parts.lvlFill.style.height = (frac * 100) + '%';
    setGain(tabId, frac * 1.5);
  });

  draggable(parts.spd, (e, r) => {
    const frac = Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height));
    const v = RATE_MIN + frac * (RATE_MAX - RATE_MIN);
    parts.rateVal = v;
    parts.spdFill.style.height = (frac * 100) + '%';
    sendRate(v);
  });
  parts.spd.addEventListener('dblclick', () => {
    parts.rateVal = 1;
    parts.spdFill.style.height = (((1 - RATE_MIN) / (RATE_MAX - RATE_MIN)) * 100) + '%';
    sendRate(1);
  });

  draggable(parts.pan, (e, r) => {
    const frac = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    parts.panDot.style.left = (frac * 100) + '%';
    setPan(tabId, frac * 2 - 1);
  });
  parts.pan.addEventListener('dblclick', () => {
    parts.panDot.style.left = '50%';
    setPan(tabId, 0);
  });

  // Progress doubles as the scrubber — video mode had no seek at all before this.
  draggable(parts.titlewrap, (e, r) => {
    if (!parts.duration) return;
    const frac = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    parts.progress.style.width = (frac * 100) + '%';
    toContent(tabId, { type: 'SEEK', absolute: frac * parts.duration });
  });

  parts.m.addEventListener('click', () => setMute(tabId));
  parts.s.addEventListener('click', (e) => setSolo(tabId, undefined, !e.shiftKey));
  parts.x.addEventListener('click', () => { dropChannel(tabId); renderVideo(); });
  parts.play.addEventListener('click', () => toContent(tabId, { type: 'PLAY' }));
  parts.pause.addEventListener('click', () => toContent(tabId, { type: 'PAUSE' }));
  parts.pitch.addEventListener('click', () => {
    parts.pitch.setAttribute('aria-pressed', String(!keepsPitch()));
    sendRate(parts.rateVal);
  });

  tiles.set(tabId, { el, parts });
  document.getElementById('video-grid').appendChild(el);
  return tiles.get(tabId);
}

function applyCrop(parts, crop) {
  const v = parts.v;
  if (!crop || crop.w <= 0.05 || crop.h <= 0.05) {
    v.style.width = '100%'; v.style.height = '100%'; v.style.left = '0'; v.style.top = '0';
    return;
  }
  v.style.width = (100 / crop.w) + '%';
  v.style.height = (100 / crop.h) + '%';
  v.style.left = -(crop.x * 100 / crop.w) + '%';
  v.style.top = -(crop.y * 100 / crop.h) + '%';
}

function drawViz(parts, points) {
  const g = parts.vizCtx;
  const { width: w, height: h } = parts.viz;
  g.clearRect(0, 0, w, h);
  if (!points || !points.length) return;
  g.fillStyle = parts.colour || '#c9a227';
  const bw = w / points.length;
  for (let i = 0; i < points.length; i++) {
    const bh = Math.max(1, points[i] * h);
    g.fillRect(i * bw, (h - bh) / 2, Math.max(1, bw - 1), bh);
  }
}

// Size the grid so each cell is exactly video-plus-strips, and centre whatever is
// left over as ONE margin. Strip sizes are measured from the DOM rather than
// duplicated here, so the CSS stays the single source of truth.
function layoutGrid() {
  const grid = document.getElementById('video-grid');
  const wrap = grid.parentElement;
  const first = tiles.values().next().value;
  if (!first || !wrap) return;

  const n = tiles.size;
  const cols = n <= 1 ? 1 : n <= 4 ? 2 : 3;
  const rows = Math.ceil(n / cols);

  const p = first.parts;
  const sideW = p.left.offsetWidth + p.right.offsetWidth;
  const bottomH = p.bottom.offsetHeight;
  const panH = p.pan.offsetHeight;
  const border = (first.el.offsetWidth - first.el.clientWidth) || 6;

  // The wrapper IS the space left over after the tape strip and button bar — it is a
  // flex:1 sibling of them. Subtracting their heights again shrank the grid to a
  // fraction of the screen and made the tiles overlap.
  const availW = wrap.clientWidth;
  const availH = wrap.clientHeight;
  if (availW <= 0 || availH <= 0) return;

  // Try height-limited, then width-limited, and take whichever fits both.
  const fromH = () => {
    const cellH = availH / rows;
    const videoH = cellH - bottomH - panH - border;
    const videoW = videoH * (16 / 9);
    return { videoW, videoH, cellW: videoW + sideW + border, cellH };
  };
  const fromW = () => {
    const cellW = availW / cols;
    const videoW = cellW - sideW - border;
    const videoH = videoW * (9 / 16);
    return { videoW, videoH, cellW, cellH: videoH + bottomH + panH + border };
  };

  let fit = fromH();
  if (fit.cellW * cols > availW || fit.videoW <= 0) fit = fromW();
  if (fit.videoW <= 0 || fit.videoH <= 0) return;

  grid.style.width = Math.floor(fit.cellW * cols) + 'px';
  grid.style.height = Math.floor(fit.cellH * rows) + 'px';
  grid.style.setProperty('--videoW', Math.floor(fit.videoW) + 'px');
}

async function renderVideo() {
  if (!videoOn) return;
  const st = Mixer.state();
  const channels = (st && st.channels) || [];
  const lv = Mixer.levels();
  const levelBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.db]));

  let structureChanged = false;
  for (const [tabId, t] of tiles) {
    if (!channels.some((c) => c.tabId === tabId)) {
      t.el.remove(); tiles.delete(tabId); structureChanged = true;
    }
  }

  const grid = document.getElementById('video-grid');
  grid.dataset.count = String(Math.min(channels.length, 6));

  for (const [i, ch] of channels.entries()) {
    let t = tiles.get(ch.tabId);
    if (!t) { t = buildTile(ch.tabId); structureChanged = true; }
    const p = t.parts;

    const colour = colourFor(i);
    p.colour = colour;
    t.el.style.setProperty('--ch', colour);

    p.title.textContent = ch.title || 'tab ' + ch.tabId;

    const stream = Mixer.getStream(ch.tabId);
    const hasVideo = !!(stream && stream.getVideoTracks && stream.getVideoTracks().length);
    if (hasVideo && !p.streamAttached) {
      p.v.srcObject = stream;
      p.v.play().catch(() => {});
      p.streamAttached = true;
    }
    t.el.classList.toggle('tile--audio', !hasVideo);

    if (dragging !== p.lvl) p.lvlFill.style.height = ((ch.level / 1.5) * 100) + '%';
    if (dragging !== p.pan) p.panDot.style.left = (((ch.pan + 1) / 2) * 100) + '%';

    const db = levelBy.get(ch.tabId);
    const meterFrac = db === null || db === undefined ? 0 : Math.max(0, Math.min(1, (db + 60) / 60));
    p.meter.style.height = (meterFrac * 100) + '%';

    p.m.setAttribute('aria-pressed', String(!!ch.muted));
    p.s.setAttribute('aria-pressed', String(!!ch.soloed));

    if (hasVideo) {
      const info = await toContent(ch.tabId, { type: 'INFO' });
      if (info && info.ok) {
        p.duration = info.duration || 0;
        if (dragging !== p.spd) {
          p.rateVal = info.playbackRate;
          const frac = (info.playbackRate - RATE_MIN) / (RATE_MAX - RATE_MIN);
          p.spdFill.style.height = (Math.max(0, Math.min(1, frac)) * 100) + '%';
        }
        p.pitch.setAttribute('aria-pressed', String(!!info.preservesPitch));
        if (dragging !== p.titlewrap && p.duration) {
          p.progress.style.width = ((info.currentTime / p.duration) * 100) + '%';
        }
        if (info.crop) { p.crop = info.crop; applyCrop(p, info.crop); }
      }
    } else {
      drawViz(p, Mixer.waveform(ch.tabId, 96));
    }
  }

  // DOM order must match channel order, or the colour sequence stops matching what
  // you see left-to-right — colours are assigned by channel index, and a dropped and
  // re-added channel otherwise keeps its old DOM position. Only re-append when the
  // order actually differs: moving a <video> node restarts its decode.
  const want = channels.map((c) => c.tabId);
  const have = [...grid.children].map((el) => {
    for (const [id, t] of tiles) if (t.el === el) return id;
    return null;
  });
  if (want.join() !== have.join()) {
    for (const id of want) { const t = tiles.get(id); if (t) grid.appendChild(t.el); }
    structureChanged = true;
  }

  document.getElementById('video-empty').style.display = channels.length ? 'none' : '';
  if (structureChanged) layoutGrid();
}

// ---------------------------------------------------------------- quality

// Our capture is only half the cost — each source tab is also decoding YouTube at full
// quality. Asking the player to drop its own resolution is the bigger saving. It is
// page JavaScript, so a content script cannot reach it: this needs MAIN world.
async function setYouTubeQuality(tabId, level) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      args: [level],
      func: (q) => {
        try {
          const p = document.getElementById('movie_player');
          if (!p || !p.setPlaybackQualityRange) return 'no player';
          // Undocumented internals — treat any failure as "quality unchanged".
          if (q === 'auto') p.setPlaybackQualityRange('tiny', 'highres');
          else p.setPlaybackQualityRange(q, q);
          return 'ok';
        } catch (e) {
          return 'err';
        }
      },
    });
  } catch {
    /* tab gone, not a YouTube page, or internals moved — never fatal */
  }
}

async function setQuality(high) {
  hq = !!high;
  localStorage.setItem('ym-hq', hq ? '1' : '0');
  const btn = document.getElementById('video-hq');
  if (btn) btn.setAttribute('aria-pressed', String(hq));

  await Mixer.setQuality(hq ? 'high' : 'low');

  const st = Mixer.state();
  for (const ch of (st.channels || [])) {
    if (!ch.synthetic) setYouTubeQuality(ch.tabId, hq ? 'auto' : 'tiny');
  }
  return { ok: true, hq };
}

// ---------------------------------------------------------------- mode

function setVideoMode(on) {
  videoOn = !!on;
  localStorage.setItem('ym-video', videoOn ? '1' : '0');
  document.body.classList.toggle('video-mode', videoOn);
  document.getElementById('video-switch').setAttribute('aria-pressed', String(videoOn));

  // Move the tape and MIDI panels rather than rebuilding them: one of each, no chance
  // of the two modes drifting apart, and every handler stays bound.
  stash('tape'); stash('midi');
  if (videoOn) {
    document.getElementById('video-tape').appendChild(document.getElementById('tape'));
    document.getElementById('video-midi-body').appendChild(document.getElementById('midi'));
  } else {
    restore('tape'); restore('midi');
  }

  Mixer.setVideoEnabled(videoOn);

  if (videoOn) {
    renderVideo().then(layoutGrid);
    if (!videoTimer) videoTimer = setInterval(renderVideo, 250);
  } else {
    clearInterval(videoTimer);
    videoTimer = null;
    for (const [, t] of tiles) { t.parts.v.srcObject = null; t.parts.streamAttached = false; }
  }
}

function initVideo() {
  document.getElementById('video-switch')
    .addEventListener('click', () => setVideoMode(!videoOn));

  document.getElementById('video-full').addEventListener('click', () => {
    const el = document.getElementById('video');
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen().catch(() => {});
  });

  const clean = document.getElementById('video-clean');
  clean.addEventListener('click', () => {
    const on = clean.getAttribute('aria-pressed') !== 'true';
    clean.setAttribute('aria-pressed', String(on));
    document.body.classList.toggle('video-clean', on);
  });

  const midiBtn = document.getElementById('video-midi-btn');
  midiBtn.addEventListener('click', () => {
    const on = midiBtn.getAttribute('aria-pressed') !== 'true';
    midiBtn.setAttribute('aria-pressed', String(on));
    document.getElementById('video-midi').style.display = on ? 'block' : 'none';
  });

  document.getElementById('video-hq')
    .addEventListener('click', () => setQuality(!hq));

  window.addEventListener('resize', () => { if (videoOn) layoutGrid(); });
  document.addEventListener('fullscreenchange', () => { if (videoOn) setTimeout(layoutGrid, 120); });

  hq = localStorage.getItem('ym-hq') === '1';
  document.getElementById('video-hq').setAttribute('aria-pressed', String(hq));
  setVideoMode(localStorage.getItem('ym-video') === '1');
}

initVideo();

Object.assign(window, {
  videoMode: setVideoMode,
  videoTiles: () => tiles.size,
  videoIsOn: () => videoOn,
  videoQuality: setQuality,
  videoIsHq: () => hq,
  videoLayout: layoutGrid,
  videoColourOf: (tabId) => {
    const t = tiles.get(tabId);
    return t ? t.el.style.getPropertyValue('--ch') : null;
  },
  videoBoxRatio: (tabId) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    const r = t.parts.vidbox.getBoundingClientRect();
    return r.height ? r.width / r.height : null;
  },
  // How much of the middle column the picture actually uses — the "no wasted space"
  // claim, measured rather than eyeballed.
  videoFillRatio: (tabId) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    const box = t.parts.vidbox.getBoundingClientRect();
    const mid = t.parts.vidbox.parentElement.getBoundingClientRect();
    return mid.width ? box.width / mid.width : null;
  },
  // test seam: synthetic channels have no content script, so no duration arrives
  videoSetDuration: (tabId, d) => { const t = tiles.get(tabId); if (t) t.parts.duration = d; },
  videoReady: true,
});
