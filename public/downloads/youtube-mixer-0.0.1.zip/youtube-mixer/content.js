// Content script on youtube.com: direct control of the native <video>.
//
// This is where continuous varispeed comes from. YouTube's own UI offers discrete
// rates, but the underlying HTMLMediaElement accepts any float, so `playbackRate`
// takes 1.037 exactly. `preservesPitch = false` makes pitch ride with speed, which
// is tape behaviour; true time-stretches instead.
//
// YouTube is an SPA and swaps the media element on navigation, so never cache it.

function video() {
  // The main player video; ads and previews can add others, so prefer the largest.
  const vids = [...document.querySelectorAll('video')];
  if (!vids.length) return null;
  return vids.sort((a, b) => b.clientWidth * b.clientHeight - a.clientWidth * a.clientHeight)[0];
}

function info(v) {
  return {
    ok: true,
    playbackRate: v.playbackRate,
    preservesPitch: v.preservesPitch,
    volume: v.volume,
    muted: v.muted,
    currentTime: v.currentTime,
    duration: Number.isFinite(v.duration) ? v.duration : null,
    paused: v.paused,
    readyState: v.readyState,
    videoId: new URLSearchParams(location.search).get('v'),
    // A pre-roll ad puts a different <video> in front of the content one; callers
    // should not trust rate/seek while this is true.
    isAd: !!document.querySelector('.ad-showing, .ytp-ad-player-overlay'),
    title: document.title,
  };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'content') return false;

  const v = video();
  if (!v) {
    sendResponse({ ok: false, reason: 'no video element', href: location.href });
    return true;
  }

  try {
    switch (msg.type) {
      case 'INFO':
        break;

      case 'SET_RATE':
        // preservesPitch first, so the rate change lands with the intended mode.
        if (msg.preservesPitch !== undefined) v.preservesPitch = !!msg.preservesPitch;
        v.playbackRate = msg.rate;
        break;

      case 'SET_VOLUME':
        if (msg.volume !== undefined) v.volume = Math.max(0, Math.min(1, msg.volume));
        if (msg.muted !== undefined) v.muted = !!msg.muted;
        break;

      case 'SEEK':
        if (msg.absolute !== undefined) v.currentTime = msg.absolute;
        else if (msg.delta !== undefined) v.currentTime = v.currentTime + msg.delta;
        break;

      case 'PLAY':
        v.play();
        break;

      case 'PAUSE':
        v.pause();
        break;

      default:
        sendResponse({ ok: false, reason: 'unknown ' + msg.type });
        return true;
    }
    sendResponse(info(v));
  } catch (e) {
    sendResponse({ ok: false, error: String((e && e.message) || e) });
  }
  return true;
});
