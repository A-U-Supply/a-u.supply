// Action click -> get a stream id for the active tab -> hand it to the offscreen doc.
// getMediaStreamId requires the extension to have been invoked on the target tab,
// which the action click satisfies. Adding a second tab = click the action on it.

const OFFSCREEN_URL = 'offscreen.html';

async function hasOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });
  return contexts.length > 0;
}

let creating = null;
async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  if (creating) return creating;
  creating = chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ['USER_MEDIA'],
    justification: 'Mix captured tab audio through a Web Audio graph.',
  });
  try {
    await creating;
  } finally {
    creating = null;
  }
}

// createDocument resolves before offscreen.js has necessarily registered its
// listener, so retry until there is a receiver.
async function sendToOffscreen(msg, tries = 20) {
  for (let i = 0; i < tries; i++) {
    try {
      return await chrome.runtime.sendMessage({ target: 'offscreen', ...msg });
    } catch (e) {
      if (i === tries - 1) throw e;
      await new Promise((r) => setTimeout(r, 50));
    }
  }
}

// Open the mixer panel on install. Also the only reliable way to get an extension
// page open under automation: top-level navigation to chrome-extension:// is blocked,
// but an extension-initiated tabs.create is not.
chrome.runtime.onInstalled.addListener(async () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('panel.html') });
  // Declared content scripts only run on navigation, so inject into YouTube tabs
  // that were already open when the extension loaded.
  const tabs = await chrome.tabs.query({ url: '*://*.youtube.com/*' });
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] });
    } catch (e) {
      console.warn('[mixer] inject failed', t.id, e.message);
    }
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await ensureOffscreen();

    const streamId = await chrome.tabCapture.getMediaStreamId({
      targetTabId: tab.id,
    });

    const res = await sendToOffscreen({
      type: 'ADD_CHANNEL',
      streamId,
      tabId: tab.id,
      title: tab.title || String(tab.id),
    });

    console.log('[mixer] ADD_CHANNEL result', res);
  } catch (e) {
    console.error('[mixer] add channel failed', e);
  }
});

// Console helpers for the spike: run these from the service worker devtools.
globalThis.mixerState = () => sendToOffscreen({ type: 'GET_STATE' });
globalThis.mixerLevels = () => sendToOffscreen({ type: 'GET_LEVELS' });
globalThis.mixerGain = (tabId, value) =>
  sendToOffscreen({ type: 'SET_GAIN', tabId, value });
globalThis.mixerDrop = (tabId) => sendToOffscreen({ type: 'DROP_CHANNEL', tabId });

// Same path as the action click, callable without the toolbar button so the
// spike can be driven over CDP.
globalThis.mixerAdd = async (tabId) => {
  await ensureOffscreen();
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  return sendToOffscreen({ type: 'ADD_CHANNEL', streamId, tabId, title: 'tab ' + tabId });
};

globalThis.mixerTabs = async () => {
  const tabs = await chrome.tabs.query({});
  return tabs.map((t) => ({ id: t.id, audible: t.audible, url: (t.url || '').slice(0, 60) }));
};
