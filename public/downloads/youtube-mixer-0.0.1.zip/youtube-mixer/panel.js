// Extension page: the mixer UI.
//
// Two control surfaces per deck, deliberately distinct:
//   - level -> offscreen GainNode on the captured stream (works for ANY audible tab)
//   - rate / transport / seek -> content script on the native <video> (YouTube only)

// ---------------------------------------------------------------- plumbing

async function ensureOffscreen() {
  const ctxs = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (ctxs.length) return { created: false };
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Mix captured tab audio through a Web Audio graph.',
  });
  return { created: true };
}

async function toOffscreen(msg, tries = 25) {
  // Every path needs the document, not just addChannel — otherwise the first call
  // of a session gets "Receiving end does not exist".
  await ensureOffscreen();
  for (let i = 0; i < tries; i++) {
    try {
      return await chrome.runtime.sendMessage({ target: 'offscreen', ...msg });
    } catch (e) {
      if (i === tries - 1) return { ok: false, error: String(e.message || e) };
      await new Promise((r) => setTimeout(r, 60));
    }
  }
}

// Talks to the content script in a YouTube tab (not the offscreen document).
async function toContent(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, { target: 'content', ...msg });
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
}

const listTabs = async () =>
  (await chrome.tabs.query({})).map((t) => ({
    id: t.id,
    audible: !!t.audible,
    title: (t.title || '').slice(0, 80),
    url: t.url || '',
  }));

async function addChannel(tabId) {
  await ensureOffscreen();
  let streamId;
  try {
    streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  } catch (e) {
    return { ok: false, stage: 'getMediaStreamId', error: String(e.message || e) };
  }
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  return toOffscreen({
    type: 'ADD_CHANNEL', streamId, tabId, title: (tab && tab.title) || 'tab ' + tabId,
  });
}

const getState = () => toOffscreen({ type: 'GET_STATE' });
const getLevels = () => toOffscreen({ type: 'GET_LEVELS' });
const setGain = (tabId, value) => toOffscreen({ type: 'SET_LEVEL', tabId, value });
const setMute = (tabId, muted) => toOffscreen({ type: 'SET_MUTE', tabId, muted });
const setSolo = (tabId, soloed, exclusive) =>
  toOffscreen({ type: 'SET_SOLO', tabId, soloed, exclusive });
const setPan = (tabId, pan) => toOffscreen({ type: 'SET_PAN', tabId, pan });
const dropChannel = (tabId) => toOffscreen({ type: 'DROP_CHANNEL', tabId });
const tapeSet = (msg) => toOffscreen({ type: 'TAPE_SET', ...msg });
const tapeCmd = (cmd, seconds) => toOffscreen({ type: 'TAPE_CMD', cmd, seconds });
const tapeQuery = () => toOffscreen({ type: 'TAPE_QUERY' });

// ---------------------------------------------------------------- ui state

const decks = new Map(); // tabId -> { el, parts }
let dragging = null; // control the user is moving; never overwrite it from a poll

const fmtTime = (s) =>
  Number.isFinite(s)
    ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`
    : '--:--';
const fmtPan = (v) =>
  Math.abs(v) < 0.02 ? 'C' : (v < 0 ? 'L' : 'R') + Math.round(Math.abs(v) * 100);
const fmtDb = (db) => (db === null || db === undefined ? '  -inf' : db.toFixed(1).padStart(6));

function trackDrag(el) {
  el.addEventListener('pointerdown', () => (dragging = el));
  el.addEventListener('pointerup', () => (dragging = null));
  el.addEventListener('blur', () => { if (dragging === el) dragging = null; });
}

function buildDeck(tab) {
  const el = document.createElement('div');
  el.className = 'deck';
  const isYt = tab.url.includes('youtube.com/watch');

  el.innerHTML = `
    <div class="deck__head">
      <span class="deck__title"></span>
      <span class="deck__tag"></span>
      <span class="deck__meter"></span>
    </div>
    <div class="row">
      <label>level</label>
      <input type="range" class="level" min="0" max="1.5" step="0.01" value="1" />
      <span class="val lvlv">1.00</span>
      <span class="btns">
        <button class="mute hot" aria-pressed="false">mute</button>
        <button class="solo" aria-pressed="false">solo</button>
        <button class="cap">capture</button>
      </span>
    </div>
    <div class="row pan-row">
      <label>pan</label>
      <input type="range" class="pan" min="-1" max="1" step="0.01" value="0" />
      <span class="val panv">C</span>
      <span class="btns"><button class="pancenter">centre</button></span>
    </div>
    <div class="row rate-row">
      <label>rate</label>
      <input type="range" class="rate" min="0.25" max="2.5" step="0.001" value="1" />
      <span class="val ratev">1.000</span>
      <span class="btns">
        <button class="rate1">1.0</button>
        <button class="pitch" aria-pressed="true">keep pitch</button>
      </span>
    </div>
    <div class="row seek-row">
      <label>pos</label>
      <input type="range" class="seek" min="0" max="1000" step="1" value="0" />
      <span class="val time">--:--</span>
      <span class="btns">
        <button class="play">play</button>
        <button class="pause">pause</button>
      </span>
    </div>`;

  const q = (s) => el.querySelector(s);
  const parts = {
    title: q('.deck__title'), tag: q('.deck__tag'), meter: q('.deck__meter'),
    level: q('.level'), lvlv: q('.lvlv'), mute: q('.mute'), solo: q('.solo'), cap: q('.cap'),
    pan: q('.pan'), panv: q('.panv'), pancenter: q('.pancenter'), panRow: q('.pan-row'),
    rate: q('.rate'), ratev: q('.ratev'), rate1: q('.rate1'), pitch: q('.pitch'),
    seek: q('.seek'), time: q('.time'), play: q('.play'), pause: q('.pause'),
    rateRow: q('.rate-row'), seekRow: q('.seek-row'),
    duration: 0, isYt,
  };

  if (!isYt) {
    // Rate, seek and transport come from the content script, which is YouTube-only.
    for (const row of [parts.rateRow, parts.seekRow]) {
      row.classList.add('idle');
      row.querySelectorAll('input,button').forEach((n) => (n.disabled = true));
    }
  }

  [parts.level, parts.pan, parts.rate, parts.seek].forEach(trackDrag);

  parts.level.addEventListener('input', () => {
    const v = Number(parts.level.value);
    parts.lvlv.textContent = v.toFixed(2);
    setGain(tab.id, v);
  });

  parts.pan.addEventListener('input', () => {
    const v = Number(parts.pan.value);
    parts.panv.textContent = fmtPan(v);
    setPan(tab.id, v);
  });
  parts.pancenter.addEventListener('click', () => {
    parts.pan.value = '0';
    parts.panv.textContent = 'C';
    setPan(tab.id, 0);
  });

  // Mute and solo are mixer-wide state, so the offscreen graph owns them; the
  // panel only sends intent and reflects whatever comes back.
  parts.mute.addEventListener('click', () => setMute(tab.id));
  // Shift-click builds a multi-channel solo instead of replacing it.
  parts.solo.addEventListener('click', (e) => setSolo(tab.id, undefined, !e.shiftKey));

  parts.cap.addEventListener('click', async () => {
    parts.cap.textContent = '…';
    const r = await addChannel(tab.id);
    if (!r || r.ok === false) {
      parts.cap.textContent = 'use toolbar';
      parts.cap.title = (r && (r.error || r.reason)) || 'capture failed';
    }
    refresh();
  });

  const applyRate = () => {
    const v = Number(parts.rate.value);
    parts.ratev.textContent = v.toFixed(3);
    toContent(tab.id, {
      type: 'SET_RATE',
      rate: v,
      preservesPitch: parts.pitch.getAttribute('aria-pressed') === 'true',
    });
  };
  parts.rate.addEventListener('input', applyRate);
  parts.rate1.addEventListener('click', () => { parts.rate.value = '1'; applyRate(); });
  parts.pitch.addEventListener('click', () => {
    const on = parts.pitch.getAttribute('aria-pressed') !== 'true';
    parts.pitch.setAttribute('aria-pressed', String(on));
    applyRate();
  });

  parts.seek.addEventListener('change', () => {
    if (!parts.duration) return;
    toContent(tab.id, {
      type: 'SEEK', absolute: (Number(parts.seek.value) / 1000) * parts.duration,
    });
  });
  parts.play.addEventListener('click', () => toContent(tab.id, { type: 'PLAY' }));
  parts.pause.addEventListener('click', () => toContent(tab.id, { type: 'PAUSE' }));

  decks.set(tab.id, { el, parts });
  document.getElementById('decks').appendChild(el);
  return decks.get(tab.id);
}

async function refresh() {
  const tabs = await listTabs();
  const st = await getState();
  const lv = await getLevels();
  const captured = new Map((st.channels || []).map((c) => [c.tabId, c]));
  const levelBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.db]));

  // Anything audible, plus anything already captured (it may have gone quiet).
  const shown = tabs.filter(
    (t) => (t.audible || captured.has(t.id)) && !t.url.startsWith('chrome-extension://'),
  );

  for (const [tabId, d] of decks) {
    if (!shown.some((t) => t.id === tabId)) { d.el.remove(); decks.delete(tabId); }
  }

  for (const tab of shown) {
    const d = decks.get(tab.id) || buildDeck(tab);
    const p = d.parts;
    p.title.textContent = tab.title;
    const cap = captured.get(tab.id);
    p.tag.textContent = cap ? 'captured' : p.isYt ? 'youtube' : 'audible';
    p.cap.style.display = cap ? 'none' : '';
    p.meter.textContent = cap ? fmtDb(levelBy.get(tab.id)) + ' dB' : '';
    // Level, pan, mute and solo only exist once a channel is captured.
    for (const n of [p.level, p.pan, p.pancenter, p.mute, p.solo]) n.disabled = !cap;
    p.panRow.classList.toggle('idle', !cap);
    if (cap) {
      p.mute.setAttribute('aria-pressed', String(!!cap.muted));
      p.solo.setAttribute('aria-pressed', String(!!cap.soloed));
      if (dragging !== p.level) {
        p.level.value = String(cap.level);
        p.lvlv.textContent = Number(cap.level).toFixed(2);
      }
      if (dragging !== p.pan) {
        p.pan.value = String(cap.pan);
        p.panv.textContent = fmtPan(cap.pan);
      }
    }

    if (p.isYt) {
      const info = await toContent(tab.id, { type: 'INFO' });
      if (info && info.ok) {
        p.duration = info.duration || 0;
        if (dragging !== p.rate) {
          p.rate.value = String(info.playbackRate);
          p.ratev.textContent = Number(info.playbackRate).toFixed(3);
        }
        p.pitch.setAttribute('aria-pressed', String(!!info.preservesPitch));
        if (dragging !== p.seek && p.duration) {
          p.seek.value = String(Math.round((info.currentTime / p.duration) * 1000));
        }
        p.time.textContent = info.isAd
          ? 'ad…'
          : `${fmtTime(info.currentTime)}/${fmtTime(info.duration)}`;
        p.tag.textContent = info.isAd ? 'ad playing' : p.tag.textContent;
      }
    }
  }

  document.getElementById('decks-hint').innerHTML = shown.length
    ? 'Rate, position and transport come from the content script, so they are ' +
      'YouTube-only. Level works on any captured tab. If <code>capture</code> is ' +
      'refused, click the toolbar button on that tab — Chrome requires it.'
    : 'No audible tabs. Play something, then come back.';
}

// ---------------------------------------------------------------- tape ui

function buildTape() {
  const el = document.getElementById('tape');
  el.innerHTML = `
    <div class="row">
      <label>engage</label>
      <span class="btns">
        <button id="t-thru" aria-pressed="true">thru</button>
        <button id="t-tape" aria-pressed="false">tape</button>
        <button id="t-rev">reverse</button>
        <button id="t-stop">stop</button>
        <button id="t-play">1.0</button>
      </span>
      <span></span><span></span>
    </div>
    <div class="row">
      <label>speed</label>
      <input type="range" id="t-rate" min="-2" max="2" step="0.001" value="1" />
      <span class="val" id="t-ratev">1.000</span>
      <span class="btns"><button id="t-interp" aria-pressed="false">cubic</button></span>
    </div>
    <div class="row">
      <label>shuttle</label>
      <span class="btns">
        <button id="t-rew">&#9664;&#9664; rew</button>
        <button id="t-ff">ff &#9654;&#9654;</button>
        <button id="t-live">to live</button>
      </span>
      <span></span><span></span>
    </div>
    <div class="row">
      <label>stutter</label>
      <span class="btns">
        <button data-stut="0.06">60ms</button>
        <button data-stut="0.125">125ms</button>
        <button data-stut="0.25">250ms</button>
        <button data-stut="0.5">500ms</button>
      </span>
      <span></span><span></span>
    </div>
    <div class="row">
      <label>loop</label>
      <span class="btns">
        <button data-loop="1">1s</button>
        <button data-loop="2">2s</button>
        <button data-loop="4">4s</button>
        <button data-loop="8">8s</button>
        <button id="t-loopoff">off</button>
      </span>
      <span></span><span></span>
    </div>
    <p class="hint" id="t-state"></p>`;

  const rate = el.querySelector('#t-rate');
  const ratev = el.querySelector('#t-ratev');
  trackDrag(rate);
  const setRate = (v, glide) => {
    rate.value = String(v);
    ratev.textContent = Number(v).toFixed(3);
    tapeSet({ rate: Number(v), glide });
  };
  rate.addEventListener('input', () => setRate(rate.value, 0.01));

  const mode = (m) => {
    el.querySelector('#t-thru').setAttribute('aria-pressed', String(m === 'thru'));
    el.querySelector('#t-tape').setAttribute('aria-pressed', String(m === 'tape'));
    tapeSet({ mode: m });
  };
  el.querySelector('#t-thru').addEventListener('click', () => mode('thru'));
  el.querySelector('#t-tape').addEventListener('click', () => mode('tape'));

  // These only mean anything with the tape engaged, so engage it for them.
  el.querySelector('#t-rev').addEventListener('click', () => { mode('tape'); setRate(-1, 0.02); });
  el.querySelector('#t-stop').addEventListener('click', () => { mode('tape'); setRate(0, 0.02); });
  el.querySelector('#t-play').addEventListener('click', () => { mode('tape'); setRate(1, 0.05); });

  el.querySelectorAll('[data-loop]').forEach((b) =>
    b.addEventListener('click', () => {
      mode('tape');
      tapeCmd('loopSecondsBack', Number(b.dataset.loop));
    }));
  el.querySelector('#t-loopoff').addEventListener('click', () => tapeSet({ loopEnabled: false }));

  // Shuttle and stutter are momentary: held down they act, released they restore.
  const shuttle = (btn, rate) => {
    const start = () => { mode('tape'); tapeSet({ rate, glide: 0.02 }); };
    const stop = () => tapeSet({ rate: 1, glide: 0.06 });
    btn.addEventListener('pointerdown', start);
    btn.addEventListener('pointerup', stop);
    btn.addEventListener('pointerleave', stop);
    btn.addEventListener('pointercancel', stop);
  };
  shuttle(el.querySelector('#t-rew'), -4);
  shuttle(el.querySelector('#t-ff'), 4);
  el.querySelector('#t-live').addEventListener('click', () => tapeCmd('toLive'));

  el.querySelectorAll('[data-stut]').forEach((b) => {
    const seconds = Number(b.dataset.stut);
    const on = () => {
      mode('tape');
      toOffscreen({ type: 'TAPE_CMD', cmd: 'stutter', on: true, seconds });
      b.setAttribute('aria-pressed', 'true');
    };
    const off = () => {
      toOffscreen({ type: 'TAPE_CMD', cmd: 'stutter', on: false });
      b.setAttribute('aria-pressed', 'false');
    };
    b.addEventListener('pointerdown', on);
    b.addEventListener('pointerup', off);
    b.addEventListener('pointerleave', off);
    b.addEventListener('pointercancel', off);
  });

  const interp = el.querySelector('#t-interp');
  interp.addEventListener('click', () => {
    const cubic = interp.getAttribute('aria-pressed') !== 'true';
    interp.setAttribute('aria-pressed', String(cubic));
    tapeSet({ interp: cubic ? 'cubic' : 'linear' });
  });

  return { rate, ratev, state: el.querySelector('#t-state') };
}

let tapeUi = null;
async function refreshTape() {
  const q = await tapeQuery();
  const ready = !!(q && q.ok);

  // Don't let the tape look engaged before there is anything to tape.
  const el = document.getElementById('tape');
  el.classList.toggle('idle', !ready);
  el.querySelectorAll('input,button').forEach((n) => (n.disabled = !ready));
  if (!ready) {
    el.querySelectorAll('[aria-pressed]').forEach((n) =>
      n.setAttribute('aria-pressed', String(n.id === 't-thru')));
    tapeUi.state.textContent = 'Tape idle — capture a tab first.';
    return;
  }

  // Reflect the worklet's actual state — the tape can be driven from the console
  // or by a gesture, so the buttons must follow it rather than only their own clicks.
  el.querySelector('#t-thru').setAttribute('aria-pressed', String(q.mode === 'thru'));
  el.querySelector('#t-tape').setAttribute('aria-pressed', String(q.mode === 'tape'));
  el.querySelector('#t-interp').setAttribute('aria-pressed', String(q.interp === 'cubic'));

  if (dragging !== tapeUi.rate) {
    tapeUi.rate.value = String(q.rate);
    tapeUi.ratev.textContent = Number(q.rate).toFixed(3);
  }
  tapeUi.state.textContent =
    `${q.mode} · ${q.interp} · ${q.behindLiveSec.toFixed(2)}s behind live · ` +
    `${q.secondsRecorded.toFixed(0)}/${q.bufferSeconds}s recorded` +
    (q.loopEnabled ? ` · loop ${q.loopLenSec.toFixed(2)}s` : '');
}

// ---------------------------------------------------------------- boot

tapeUi = buildTape();
refresh();
refreshTape();
setInterval(refresh, 700);
setInterval(refreshTape, 500);

// Kept for console use and the CDP spike drivers.
Object.assign(window, {
  mixerTabs: listTabs, mixerAdd: addChannel, mixerState: getState,
  mixerLevels: getLevels, mixerGain: setGain, mixerDrop: dropChannel,
  mixerMute: setMute, mixerSolo: setSolo, mixerPan: setPan,
  tapeSet, tapeCmd, tapeQuery,
  tapeOn: () => tapeSet({ mode: 'tape' }),
  tapeThru: () => tapeSet({ mode: 'thru' }),
  tapeRate: (rate, glide) => tapeSet({ rate, glide }),
  tapeLoop: (seconds) => tapeCmd('loopSecondsBack', seconds),
  tapeLoopOff: () => tapeSet({ loopEnabled: false }),
  tapeInterp: (interp) => tapeSet({ interp }),
  tapeStutter: (on, seconds) => toOffscreen({ type: 'TAPE_CMD', cmd: 'stutter', on, seconds }),
  tapeToLive: () => tapeCmd('toLive'),
  testTone: (on, hz) => toOffscreen({ type: 'TEST_TONE', on, hz }),
  probe: () => toOffscreen({ type: 'PROBE' }),
  probeTones: (hz) => toOffscreen({ type: 'PROBE_TONES', hz }),
  deckInfo: (tabId) => toContent(tabId, { type: 'INFO' }),
  deckRate: (tabId, rate, preservesPitch) =>
    toContent(tabId, { type: 'SET_RATE', rate, preservesPitch }),
  deckVolume: (tabId, volume, muted) => toContent(tabId, { type: 'SET_VOLUME', volume, muted }),
  deckSeek: (tabId, absolute, delta) => toContent(tabId, { type: 'SEEK', absolute, delta }),
  deckPlay: (tabId) => toContent(tabId, { type: 'PLAY' }),
  deckPause: (tabId) => toContent(tabId, { type: 'PAUSE' }),
  mixerReady: true,
});
