// Keyboard control: vi-like bindings, one grammar, generated help.
//
// Tube's request, and his pointer to `doo-nothing/los` for the grammar. This follows
// los's doctrine rather than inventing one:
//
//   - the AXIS RULE: navigate along the layout axis, adjust on the perpendicular
//   - COUNTS: a number prefix repeats any nav or adjust key (`5l`, `3j`)
//   - COARSE: the shift-variant of an adjust key is a bigger step
//   - `?` help, `gg`/`G` first/last, `0` reset the selected param
//
// and, from los's own Mixer module — a console of vertical strips, which is exactly
// what this is — `h`/`l` select the strip, `j`/`k` select the param within it, `K`/`J`
// adjust it, `m`/`s` mute and solo.
//
// THE TAPE IS THE MASTER STRIP. In los's mixer, `h`/`l` runs through the channels and
// then reaches MASTER, and `G` jumps straight to it. Here the tape is that strip: its
// speed, loop and interpolation sit under the same keys as a channel's level and pan.
// Brendan chose this over a separate tape mode — one grammar to learn rather than two,
// and no question of which one you are in.
//
// EVERYTHING HERE DRIVES THE EXISTING CONTROLS. A key clicks the button the mouse
// would click, or writes to the range input and dispatches the `input` event the mouse
// would cause. Nothing reimplements what a control does, so the keyboard cannot drift
// away from the mouse — and because the list-mode decks and the one tape element are
// in the DOM in both modes, the same bindings work in video mode with no second
// implementation. The tiles catch up on their own poll.
//
// Depends on globals from panel.js (decks, deckOrder, toContent, dropChannel) and
// audio.js (Mixer). Classic scripts, shared scope, loaded last.

// ---------------------------------------------------------------- remapping
//
// Learn mode, deliberately the same interaction MIDI already has: arm a target, then
// give it the input you want. One way to rebind things in this panel rather than two.
// Overrides live in chrome.storage.local beside the MIDI mappings and are keyed by a
// binding's stable id, not by the key it currently holds — which would be circular the
// moment a key can move.
//
// Some bindings are `fixed` and refuse to move: the multi-key sequences (`gg`, `gt#`,
// `dd`), `Esc`, and `?` itself. Rebinding the way back into the help list is a way to
// lock yourself out of the thing that tells you what you have done.

const KEY_STORE = 'keyBindings';
let keyOverrides = {}; // binding id -> the single key it now answers to
let keyLearn = false;
let keyArmed = null; // binding id waiting for a key

// Keys the grammar itself claims. A binding may not take one of these, or counts and
// sequences would stop working with no way to see why.
const RESERVED = new Set(['g', 'd', '?', 'Escape', 'Tab',
  '0', '1', '2', '3', '4', '5', '6', '7', '8', '9']);

// An override of '' means UNBOUND, and must not read as "no override". Losing that
// distinction makes a binding whose key was taken by another quietly spring back to
// its default — with the stored map saying one thing and the keyboard doing another,
// and possibly re-creating the very conflict that displaced it.
function keysFor(b) {
  if (!(b.id in keyOverrides)) return b.keys;
  return keyOverrides[b.id] ? [keyOverrides[b.id]] : [];
}

async function loadKeyBindings() {
  try {
    const got = await chrome.storage.local.get(KEY_STORE);
    keyOverrides = (got && got[KEY_STORE]) || {};
  } catch { keyOverrides = {}; }
}
const saveKeyBindings = () => {
  try { chrome.storage.local.set({ [KEY_STORE]: keyOverrides }); } catch {}
};

// Assign, and take the key off whatever else in the same scope was holding it. Two
// actions on one key is the whole failure mode of a remappable keyboard, so it is
// resolved here rather than left to whichever binding the handler happens to find
// first.
function assignKey(id, key) {
  const b = BINDINGS.find((x) => x.id === id);
  if (!b || b.fixed) return { ok: false, reason: 'this one cannot move' };
  if (RESERVED.has(key)) return { ok: false, reason: `${key} belongs to the grammar` };

  const taken = BINDINGS.filter((x) => x.id !== id && !x.fixed
    && (x.where === 'any' || b.where === 'any' || x.where === b.where)
    && keysFor(x).includes(key));
  for (const other of taken) keyOverrides[other.id] = ''; // unbound, not silently shared

  keyOverrides[id] = key;
  saveKeyBindings();
  return { ok: true, id, key, displaced: taken.map((x) => x.id) };
}

function resetKeyBindings() {
  keyOverrides = {};
  saveKeyBindings();
  renderHelp();
  paintSelection();
}

// ---------------------------------------------------------------- selection

let keyStrip = 0; // index into deckOrder, or STRIP_TAPE
let keyParam = 0;
let keyCount = ''; // the digits typed so far
let keyPending = ''; // a partial sequence: 'g', 'gt', 'd'
const STRIP_TAPE = -1;

// A param is a range input somewhere in the DOM plus how far its 1% step goes. The
// selector is resolved fresh every time: decks are rebuilt as channels come and go,
// and a cached node would be a node that no longer exists.
const DECK_PARAMS = [
  { id: 'level', label: 'level', sel: '.level', reset: 1 },
  { id: 'pan', label: 'pan', sel: '.pan', reset: 0 },
  { id: 'rate', label: 'speed', sel: '.rate', reset: 1 },
  { id: 'seek', label: 'position', sel: '.seek', reset: 0 },
];

const TAPE_PARAMS = [
  { id: 'rate', label: 'tape speed', sel: '#t-rate', reset: 1 },
  { id: 'loop', label: 'loop', cycle: ['off', '1', '2', '4', '8'], reset: 'off' },
  { id: 'interp', label: 'interpolation', toggle: '#t-interp', reset: false },
];

const onTape = () => keyStrip === STRIP_TAPE;
const params = () => (onTape() ? TAPE_PARAMS : DECK_PARAMS);
const param = () => params()[Math.min(keyParam, params().length - 1)];

// The deck the keyboard is pointed at. By POSITION, never by tab id — the same reason
// MIDI binds by position: Chrome renumbers tabs every session, and a mapping to an id
// is a mapping to nothing tomorrow.
function selectedDeck() {
  if (onTape()) return null;
  const tabId = deckOrder[keyStrip];
  if (tabId === undefined) return null;
  const d = decks.get(tabId);
  return d ? { tabId, parts: d.parts, el: d.el } : null;
}

function paramInput() {
  const p = param();
  if (!p.sel) return null;
  if (onTape()) return document.querySelector(p.sel);
  const d = selectedDeck();
  return d ? d.el.querySelector(p.sel) : null;
}

// ---------------------------------------------------------------- acting

// Write to a range input the way a drag does, so its own handler runs. Setting .value
// alone changes the number on screen and nothing else — the listeners are on `input`.
function nudge(fraction) {
  const el = paramInput();
  if (el) {
    const min = Number(el.min);
    const max = Number(el.max);
    const next = Math.max(min, Math.min(max, Number(el.value) + (max - min) * fraction));
    el.value = String(next);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return;
  }

  // Not a range: a cycle or a toggle. A step of either sign moves one position, which
  // is what `K`/`J` mean on a discrete param.
  const p = param();
  if (p.cycle) return cycleLoop(fraction > 0 ? 1 : -1);
  if (p.toggle) return click(p.toggle);
}

function resetParam() {
  const p = param();
  const el = paramInput();
  if (el) {
    el.value = String(p.reset);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    return;
  }
  if (p.cycle) return click('#t-loopoff');
  if (p.toggle) {
    const b = document.querySelector(p.toggle);
    if (b && (b.getAttribute('aria-pressed') === 'true') !== p.reset) b.click();
  }
}

// The loop row is five buttons rather than a range, so "adjust" walks them.
function cycleLoop(dir) {
  const order = ['off', '1', '2', '4', '8'];
  const at = order.indexOf(String(loopNow()));
  const next = order[Math.max(0, Math.min(order.length - 1, (at < 0 ? 0 : at) + dir))];
  if (next === 'off') click('#t-loopoff');
  else click(`[data-loop="${next}"]`);
}

let loopChosen = 'off'; // the tape reports no loop length back, so remember what we set
const loopNow = () => loopChosen;

function click(sel) {
  const el = document.querySelector(sel);
  if (!el) return false;
  if (sel === '#t-loopoff') loopChosen = 'off';
  const m = /data-loop="(\d+)"/.exec(sel);
  if (m) loopChosen = m[1];
  el.click();
  return true;
}

// Momentary controls — shuttle and stutter — are pointerdown/pointerup, not click.
// Held keys must behave like held buttons or the tape never comes back.
const held = new Set();
function hold(sel, key) {
  const el = document.querySelector(sel);
  if (!el || held.has(key)) return;
  held.add(key);
  el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerId: 1 }));
}
function release(sel, key) {
  const el = document.querySelector(sel);
  if (!held.delete(key) || !el) return;
  el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerId: 1 }));
}

function deckClick(what) {
  const d = selectedDeck();
  if (!d) return;
  const el = d.el.querySelector(what);
  if (el) el.click();
}

// ---------------------------------------------------------------- the bindings
//
// One table. The handler dispatches from it and the help overlay is generated from
// it, so the two cannot disagree about what a key does — the failure that makes
// printed shortcut lists worthless within a release or two.

const BINDINGS = [
  { id: 'strip-prev', keys: ['h'], where: 'any', group: 'moving',
    help: 'previous strip — channels, then the tape',
    run: (n) => moveStrip(-n) },
  { id: 'strip-next', keys: ['l'], where: 'any', group: 'moving',
    help: 'next strip, wrapping onto the tape',
    run: (n) => moveStrip(n) },
  { id: 'param-next', keys: ['j'], where: 'any', group: 'moving',
    help: 'next param in this strip',
    run: (n) => moveParam(n) },
  { id: 'param-prev', keys: ['k'], where: 'any', group: 'moving',
    help: 'previous param',
    run: (n) => moveParam(-n) },
  { id: 'first', fixed: true, keys: ['gg'], where: 'any', group: 'moving',
    help: 'first channel',
    run: () => setStrip(0) },
  { id: 'tape', keys: ['G'], where: 'any', group: 'moving',
    help: 'the tape',
    run: () => setStrip(STRIP_TAPE) },
  { id: 'goto', fixed: true, keys: ['gt#'], where: 'any', group: 'moving',
    help: 'go to channel # — numbers are counts, as in los',
    run: null },

  { id: 'up', keys: ['K', '='], where: 'any', group: 'adjusting',
    help: 'raise the selected param 1% (counts)',
    run: (n) => nudge(0.01 * n) },
  { id: 'down', keys: ['J', '-'], where: 'any', group: 'adjusting',
    help: 'lower it 1%',
    run: (n) => nudge(-0.01 * n) },
  { id: 'coarse-up', keys: ['+'], where: 'any', group: 'adjusting',
    help: 'raise it 5% — coarse',
    run: (n) => nudge(0.05 * n) },
  { id: 'coarse-down', keys: ['_'], where: 'any', group: 'adjusting',
    help: 'lower it 5%',
    run: (n) => nudge(-0.05 * n) },
  { id: 'reset', keys: ['0'], where: 'any', group: 'adjusting',
    help: 'reset it — level 1.00, pan centre, speed 1.000, position to the start',
    run: () => resetParam() },

  { id: 'ch-play', keys: ['Space'], where: 'deck', group: 'this channel',
    help: 'play / pause it',
    run: () => {
      const d = selectedDeck();
      if (d) deckClick(d.parts.paused ? '.play' : '.pause');
    } },
  { id: 'ch-mute', keys: ['m'], where: 'deck', group: 'this channel', help: 'mute', run: () => deckClick('.mute') },
  { id: 'ch-solo', keys: ['s'], where: 'deck', group: 'this channel', help: 'solo', run: () => deckClick('.solo') },
  { id: 'ch-pitch', keys: ['v'], where: 'deck', group: 'this channel',
    help: 'pitch mode — on, speed changes without pitch; off, pitch rides with it',
    run: () => deckClick('.pitch') },
  { id: 'ch-back', keys: ['['], where: 'deck', group: 'this channel',
    help: 'seek back 5s (counts)',
    run: (n) => seekBy(-5 * n) },
  { id: 'ch-fwd', keys: [']'], where: 'deck', group: 'this channel',
    help: 'seek forward 5s',
    run: (n) => seekBy(5 * n) },
  { id: 'ch-remove', fixed: true, keys: ['dd'], where: 'deck', group: 'this channel',
    help: 'remove it from the mixer',
    run: () => { const d = selectedDeck(); if (d) { dropChannel(d.tabId); refresh(); } } },

  { id: 'tape-engage', keys: ['Space'], where: 'tape', group: 'the tape',
    help: 'thru ↔ tape',
    run: () => click(document.querySelector('#t-thru').getAttribute('aria-pressed') === 'true'
      ? '#t-tape' : '#t-thru') },
  { id: 'tape-reverse', keys: ['v'], where: 'tape', group: 'the tape',
    help: 'reverse — latches, and leaves the head in the past',
    run: () => click('#t-rev') },
  { id: 'tape-stop', keys: ['s'], where: 'tape', group: 'the tape', help: 'stop the head', run: () => click('#t-stop') },
  { id: 'tape-live', keys: ['L'], where: 'tape', group: 'the tape',
    help: 'to live — the way back from the past',
    run: () => click('#t-live') },
  { id: 'tape-loopoff', keys: ['x'], where: 'tape', group: 'the tape', help: 'loop off', run: () => click('#t-loopoff') },
  // One binding per momentary control, not one binding holding four keys. An override
  // replaces a binding's keys with the single key you pressed, so "stutter" as one
  // four-key binding would collapse to a single length the first time anyone moved it.
  // These are also the keys most worth moving: their defaults are ergonomic guesses —
  // four adjacent under a left hand — rather than anything the grammar demands.
  { id: 'tape-rew', keys: ['['], where: 'tape', group: 'the tape',
    help: 'hold to shuttle back at 4x', hold: '#t-rew' },
  { id: 'tape-ff', keys: [']'], where: 'tape', group: 'the tape',
    help: 'hold to shuttle forward at 4x', hold: '#t-ff' },
  { id: 'tape-stut-60', keys: ['q'], where: 'tape', group: 'the tape',
    help: 'hold to stutter the last 60ms', hold: '[data-stut="0.06"]' },
  { id: 'tape-stut-125', keys: ['w'], where: 'tape', group: 'the tape',
    help: 'hold to stutter the last 125ms', hold: '[data-stut="0.125"]' },
  { id: 'tape-stut-250', keys: ['e'], where: 'tape', group: 'the tape',
    help: 'hold to stutter the last 250ms', hold: '[data-stut="0.25"]' },
  { id: 'tape-stut-500', keys: ['r'], where: 'tape', group: 'the tape',
    help: 'hold to stutter the last 500ms', hold: '[data-stut="0.5"]' },

  // vi yanks with `y`, and a snapshot is a yank: it copies what is on screen out to
  // somewhere you can keep it. Defined in snapshot.js, which loads before this file.
  { id: 'mix-snap', keys: ['y'], where: 'any', group: 'everywhere',
    help: 'snapshot the mix — one file, readable and reloadable',
    run: () => { if (typeof takeSnapshot === 'function') takeSnapshot(); } },

  { id: 'record', keys: ['R'], where: 'any', group: 'everywhere',
    help: 'start or stop recording the mix',
    run: () => { if (typeof recToggle === 'function') recToggle(); } },

  { id: 'help', fixed: true, keys: ['?'], where: 'any', group: 'everywhere', help: 'this list', run: () => toggleHelp() },
  { id: 'escape', fixed: true, keys: ['Esc'], where: 'any', group: 'everywhere',
    help: 'close this list, or clear a half-typed count',
    run: null },
];

function seekBy(seconds) {
  const d = selectedDeck();
  if (d) toContent(d.tabId, { type: 'SEEK', delta: seconds });
}

// ---------------------------------------------------------------- moving

function stripCount() {
  return deckOrder.length + 1; // the channels, then the tape
}

function setStrip(next) {
  keyStrip = next;
  keyParam = 0;
  paintSelection();
}

function moveStrip(by) {
  const n = stripCount();
  // The tape sits after the last channel, so the whole run wraps through it.
  const at = onTape() ? n - 1 : keyStrip;
  const next = ((at + by) % n + n) % n;
  setStrip(next === n - 1 ? STRIP_TAPE : next);
}

function moveParam(by) {
  const list = params();
  keyParam = ((keyParam + by) % list.length + list.length) % list.length;
  paintSelection();
}

// ---------------------------------------------------------------- showing it

// Selection has to be visible in both modes, and the two look nothing alike, so this
// marks whatever exists: the deck in the list, the tile in video mode, the tape strip
// either way, plus a line of text naming the param — because a highlighted row does
// not tell you what `K` is about to change.
function paintSelection() {
  for (const [tabId, d] of decks) {
    const on = !onTape() && deckOrder[keyStrip] === tabId;
    d.el.classList.toggle('sel', on);
    d.el.querySelectorAll('.row').forEach((row, i) => {
      // The deck's rows are level, pan, rate, seek — the same order as DECK_PARAMS.
      row.classList.toggle('sel', on && i === keyParam);
    });
  }
  if (typeof tiles !== 'undefined') {
    for (const [tabId, t] of tiles) {
      t.el.classList.toggle('sel', !onTape() && deckOrder[keyStrip] === tabId);
    }
  }
  const tape = document.getElementById('tape');
  if (tape) tape.classList.toggle('sel', onTape());

  const state = document.getElementById('keysbar');
  if (!state) return;
  const where = onTape() ? 'tape' : `channel ${keyStrip + 1}`;
  const el = paramInput();
  const value = el ? Number(el.value).toFixed(3) : '';
  state.textContent = `${where} · ${param().label}${value ? ' ' + value : ''}`
    + (keyCount ? `  ${keyCount}…` : '');
}

// ---------------------------------------------------------------- help

function helpRows() {
  const groups = new Map();
  for (const b of BINDINGS) {
    if (!groups.has(b.group)) groups.set(b.group, []);
    groups.get(b.group).push(b);
  }
  return groups;
}

function helpBox() {
  let el = document.getElementById('keys-help');
  if (el) return el;
  el = document.createElement('div');
  el.id = 'keys-help';
  el.hidden = true;
  document.body.appendChild(el);

  // Clicking the backdrop closes; clicking a row in learn mode arms it instead.
  el.addEventListener('click', (e) => {
    const row = e.target.closest && e.target.closest('[data-bind]');
    if (keyLearn && row) {
      e.stopPropagation();
      keyArmed = keyArmed === row.dataset.bind ? null : row.dataset.bind;
      renderHelp();
      return;
    }
    if (e.target === el) toggleHelp(false);
  });
  return el;
}

// Rendered fresh every time it opens, and again whenever a binding moves. The list
// IS the bindings — there is no second copy to fall out of date, which is what makes
// a printed shortcut table worthless a release later.
function renderHelp() {
  const el = helpBox();
  let html = '<div class="keys-help__box">'
    + '<h2>keys</h2>'
    + '<p class="keys-help__bar">'
    + `<button id="keys-learn" aria-pressed="${keyLearn}">learn</button>`
    + '<button id="keys-reset">reset all</button>'
    + `<span class="keys-help__status">${
      keyArmed
        ? 'press the key you want for <b>' + (BINDINGS.find((b) => b.id === keyArmed) || {}).help + '</b>'
        : keyLearn
          ? 'click a line to rebind it'
          : 'rebind any of these: turn on learn, click a line, press a key'
    }</span></p>`;
  for (const [group, list] of helpRows()) {
    html += `<h3>${group}</h3><table>`;
    for (const b of list) {
      const shown = keysFor(b).filter(Boolean);
      const keys = shown.length
        ? shown.map((k) => `<kbd>${k === ' ' ? 'Space' : k}</kbd>`).join(' ')
        : '<span class="keys-help__none">unbound</span>';
      const cls = 'keys-help__row'
        + (b.fixed ? ' keys-help__row--fixed' : '')
        + (keyArmed === b.id ? ' keys-help__row--armed' : '')
        + (keyOverrides[b.id] !== undefined ? ' keys-help__row--moved' : '');
      html += `<tr class="${cls}"${b.fixed ? '' : ` data-bind="${b.id}"`}>`
        + `<td class="keys-help__k">${keys}</td><td>${b.help}</td></tr>`;
    }
    html += '</table>';
  }
  html += '<p class="hint">Sequences, <kbd>Esc</kbd> and <kbd>?</kbd> stay put — '
    + 'rebinding the way back into this list is a way to lose it. '
    + '<kbd>?</kbd> or <kbd>Esc</kbd> closes.</p></div>';
  el.innerHTML = html;

  el.querySelector('#keys-learn').addEventListener('click', (e) => {
    e.stopPropagation();
    keyLearn = !keyLearn;
    keyArmed = null;
    renderHelp();
  });
  el.querySelector('#keys-reset').addEventListener('click', (e) => {
    e.stopPropagation();
    resetKeyBindings();
  });
  return el;
}

function toggleHelp(force) {
  const el = helpBox();
  const next = force === undefined ? el.hidden : force;
  if (next) renderHelp();
  else { keyLearn = false; keyArmed = null; }
  document.getElementById('keys-help').hidden = !next;
}

// ---------------------------------------------------------------- the handler

// Typing must never move a fader. The panel is full of focusable range inputs, and a
// range input eats arrow keys itself; a focused BUTTON eats Space and Enter. Leave
// both alone rather than fighting the browser for them.
function keysBusy() {
  const el = document.activeElement;
  if (!el) return false;
  const tag = el.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true;
  return !!el.isContentEditable;
}

// A momentary binding carries the control it holds, so it resolves through the same
// overrides as everything else and nothing needs a table of which key means which.
function holdTargetFor(k) {
  const b = BINDINGS.find((x) => x.hold && keysFor(x).includes(k));
  return b ? b.hold : null;
}

function onKeyDown(ev) {
  if (ev.ctrlKey || ev.metaKey || ev.altKey || keysBusy()) return;
  const k = ev.key;

  // An armed binding takes the next key, whatever it is — that is what learn means.
  // Escape still escapes, or arming a binding with nothing free would trap you.
  if (keyArmed && k !== 'Escape') {
    ev.preventDefault();
    const r = assignKey(keyArmed, k === ' ' ? 'Space' : k);
    keyArmed = null;
    renderHelp();
    if (!r.ok) {
      const s = document.querySelector('.keys-help__status');
      if (s) s.textContent = r.reason;
    }
    return;
  }

  if (k === 'Escape') {
    keyCount = ''; keyPending = '';
    toggleHelp(false);
    paintSelection();
    return;
  }

  // A focused button owns Space and Enter — the browser will click it, which is what
  // the person pressing it expects.
  if ((k === ' ' || k === 'Enter') && document.activeElement
      && document.activeElement.tagName === 'BUTTON') return;

  // Half-typed sequences come FIRST, before counts and before the momentary keys.
  //
  // `gt2` is why. The count branch below claims any digit, so with this block after
  // it the 2 was eaten as a count and `gt` quietly expired — the selection never
  // moved, and every later check drifted with it. A pending sequence owns the next
  // key, whatever it is.
  if (keyPending === 'g') {
    keyPending = '';
    ev.preventDefault();
    if (k === 'g') { setStrip(0); keyCount = ''; paintSelection(); return; }
    if (k === 't') { keyPending = 'gt'; return; }
    return;
  }
  if (keyPending === 'gt') {
    keyPending = '';
    ev.preventDefault();
    const i = Number(k) - 1;
    if (Number.isInteger(i) && i >= 0 && i < deckOrder.length) setStrip(i);
    keyCount = '';
    paintSelection();
    return;
  }
  if (keyPending === 'd') {
    keyPending = '';
    ev.preventDefault();
    if (k === 'd' && !onTape()) {
      const d = selectedDeck();
      if (d) { dropChannel(d.tabId); refresh(); }
    }
    keyCount = '';
    return;
  }

  // Momentary keys on the tape strip: held down they act, released they restore.
  const holdSel = onTape() ? holdTargetFor(k) : null;
  if (holdSel) {
    ev.preventDefault();
    hold(holdSel, k);
    return;
  }

  // Counts. A leading 0 is the reset key, not the start of a number.
  if (/^[1-9]$/.test(k) || (k === '0' && keyCount)) {
    keyCount += k;
    ev.preventDefault();
    paintSelection();
    return;
  }

  const n = Math.max(1, Number(keyCount) || 1);

  if (k === 'g') { keyPending = 'g'; ev.preventDefault(); return; }
  if (k === 'd' && !onTape()) { keyPending = 'd'; ev.preventDefault(); return; }

  const where = onTape() ? 'tape' : 'deck';
  const key = k === ' ' ? 'Space' : k;
  const b = BINDINGS.find((x) => x.run && keysFor(x).includes(key)
    && (x.where === 'any' || x.where === where));
  if (!b) return;

  ev.preventDefault();
  b.run(n);
  keyCount = '';
  paintSelection();
}

function onKeyUp(ev) {
  const sel = holdTargetFor(ev.key);
  if (sel) release(sel, ev.key);
}

function initKeys() {
  document.addEventListener('keydown', onKeyDown);
  document.addEventListener('keyup', onKeyUp);
  // Releasing outside the window would otherwise leave a stutter latched on.
  window.addEventListener('blur', () => {
    for (const k of [...held]) release(holdTargetFor(k), k);
  });
  loadKeyBindings().then(paintSelection);
  paintSelection();
}

initKeys();

Object.assign(window, {
  keysState: () => ({
    strip: onTape() ? 'tape' : keyStrip,
    stripLabel: onTape() ? 'tape' : `channel ${keyStrip + 1}`,
    param: param().id,
    paramLabel: param().label,
    count: keyCount,
    pending: keyPending,
    helpOpen: !!document.getElementById('keys-help')
      && !document.getElementById('keys-help').hidden,
  }),
  keysBindings: () => BINDINGS.map((b) => ({
    id: b.id, keys: keysFor(b), where: b.where, help: b.help, fixed: !!b.fixed,
  })),
  keysOverrides: () => ({ ...keyOverrides }),
  keysLearn: (on) => { keyLearn = !!on; keyArmed = null; renderHelp(); return keyLearn; },
  keysArm: (id) => { keyArmed = id; renderHelp(); return keyArmed; },
  keysReset: resetKeyBindings,
  keysHelpToggle: toggleHelp,
  keysReady: true,
});
