// Video mode: the performance layout.
//
// Same channels, same tape, same MIDI bindings — only the presentation changes.
//
// Cell:
//   ┏━━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━┓
//   ┃ lvl spd ┃    video    ┃ mtr M S ┃   faders run the FULL height of the row
//   ┃  (full  ┃    16:9     ┃     ♪ × ┃   pan sits at the foot of the right column
//   ┃  height)┃  top-align  ┃ ──█──── ┃
//   ┣━━━━━━━━━┻━━━━━━━━━━━━━┻━━━━━━━━━┫
//   ┃ ▓▓ title ░░░    ▶  ⏸            ┃   progress fills behind the outlined title
//   ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
//
// The grid is sized in JS so each cell is exactly video-plus-strips. Cells are
// otherwise 2:1 while the video is 16:9, which left ~20% of every cell as dead black.
// Now any leftover is a single margin around the whole grid instead of eight slivers.
//
// Depends on globals from panel.js (setGain, setMute, setSolo, setPan, dropChannel,
// toContent, dragging) and audio.js (Mixer). Classic scripts, shared scope, last.

const CHANNEL_COLOURS = ['#e0524f', '#e2c240', '#4f86e0', '#eae6de'];
const colourFor = (i) => CHANNEL_COLOURS[i % CHANNEL_COLOURS.length];

const RATE_MIN = 0.25;
const RATE_MAX = 2.5;

const tiles = new Map(); // tabId -> { el, parts }
let videoOn = false;
let videoTimer = null;
let hq = false;
const homes = new Map();

function stash(id) {
  const el = document.getElementById(id);
  if (el && !homes.has(el)) homes.set(el, { parent: el.parentNode, next: el.nextSibling });
  return el;
}
function restore(id) {
  const el = document.getElementById(id);
  const home = el && homes.get(el);
  if (home) home.parent.insertBefore(el, home.next);
}

// Drag helper: pointer capture so a drag that leaves a small tile still tracks.
function draggable(el, onMove) {
  const go = (e) => onMove(e, el.getBoundingClientRect());
  el.addEventListener('pointerdown', (e) => {
    // Capture is a nicety — it keeps a drag tracking when the pointer leaves a small
    // tile. It throws if the id is not an active pointer, and an unguarded throw here
    // aborts the handler before the drag even starts, so the control does nothing.
    try { el.setPointerCapture(e.pointerId); } catch {}
    dragging = el;
    go(e);
  });
  el.addEventListener('pointermove', (e) => { if (dragging === el) go(e); });
  const rel = () => { if (dragging === el) dragging = null; };
  el.addEventListener('pointerup', rel);
  el.addEventListener('pointercancel', rel);
}

function buildTile(tabId) {
  const el = document.createElement('div');
  el.className = 'tile';
  el.dataset.tab = String(tabId); // so a test can name one tile among several
  el.innerHTML = `
    <div class="tile__left">
      <div class="vfader vfader--lvl" data-help="Channel level. The full height of the tile is your throw.">
        <div class="vfader__fill"></div><span class="vfader__lab">lvl</span>
      </div>
      <div class="tile__spdcol">
        <div class="vfader vfader--spd" data-help="Playback speed, like a turntable's pitch fader. Double-click to return to 1.00.">
          <div class="vfader__fill"></div><span class="vfader__lab">spd</span>
        </div>
        <button class="tile__rate1" data-help="Snap this channel back to normal speed.">1.0</button>
      </div>
    </div>

    <div class="tile__mid">
      <div class="tile__vidbox">
        <video class="tile__v" autoplay muted playsinline></video>
        <canvas class="tile__viz" width="480" height="120"></canvas>
      </div>
    </div>

    <div class="tile__right">
      <div class="tile__rtop">
        <div class="vmeter" data-help="Live level of this channel."><div class="vmeter__fill"></div></div>
        <div class="tile__btns">
          <button class="tile__btn tile__m" data-help="Silence this channel without moving its fader.">M</button>
          <button class="tile__btn tile__s" data-help="Hear only this channel. Shift-click to solo several.">S</button>
          <button class="tile__btn tile__pitch" aria-pressed="true" data-help="On: speed changes without pitch. Off: pitch rides with speed, the way tape behaves.">&#9834;</button>
          <button class="tile__btn tile__x" data-help="Remove this tab from the mixer.">&times;</button>
        </div>
      </div>
      <div class="hpan" data-help="Stereo position. Double-click to centre.">
        <span class="hpan__dot"></span>
      </div>
    </div>

    <div class="tile__bottom">
      <span class="tile__titlewrap" data-help="Playback position — the fill behind the title. Drag to seek.">
        <span class="tile__progress"></span>
        <span class="tile__title"></span>
      </span>
      <button class="tile__btn tile__play" data-help="Resume this video.">&#9654;</button>
      <button class="tile__btn tile__pause" data-help="Pause this video. It stays in the mixer.">&#10073;&#10073;</button>
      <span class="tile__note"></span>
      <button class="tile__btn tile__probe" data-help="Copy a report of what this tab actually contains — which player it has and where, and what this extension can and cannot reach. Paste it into a bug report. Works whether or not the channel is behaving.">probe</button>
    </div>`;

  const q = (s) => el.querySelector(s);
  const parts = {
    left: q('.tile__left'), right: q('.tile__right'), bottom: q('.tile__bottom'),
    lvl: q('.vfader--lvl'), lvlFill: q('.vfader--lvl .vfader__fill'),
    spd: q('.vfader--spd'), spdFill: q('.vfader--spd .vfader__fill'),
    meter: q('.vmeter__fill'), vidbox: q('.tile__vidbox'),
    v: q('.tile__v'), viz: q('.tile__viz'), vizCtx: q('.tile__viz').getContext('2d'),
    m: q('.tile__m'), s: q('.tile__s'), pitch: q('.tile__pitch'), x: q('.tile__x'),
    rate1: q('.tile__rate1'), note: q('.tile__note'), probe: q('.tile__probe'),
    pan: q('.hpan'), panDot: q('.hpan__dot'),
    titlewrap: q('.tile__titlewrap'), progress: q('.tile__progress'), title: q('.tile__title'),
    play: q('.tile__play'), pause: q('.tile__pause'),
    crop: null, frame: null, streamAttached: false, rateVal: 1, duration: 0,
    // Whether the page-side script answered last time we asked. Everything below the
    // audio graph — speed, scrub, transport, pitch — depends on it, so the tile says
    // so rather than accepting clicks that go nowhere.
    controllable: true, paused: false, scrubbable: true,
  };

  const keepsPitch = () => parts.pitch.getAttribute('aria-pressed') === 'true';
  const sendRate = (v) => toContent(tabId, { type: 'SET_RATE', rate: v, preservesPitch: keepsPitch() });

  draggable(parts.lvl, (e, r) => {
    const frac = Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height));
    parts.lvlFill.style.height = (frac * 100) + '%';
    setGain(tabId, frac * 1.5);
  });

  draggable(parts.spd, (e, r) => {
    const frac = Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height));
    const v = RATE_MIN + frac * (RATE_MAX - RATE_MIN);
    parts.rateVal = v;
    parts.spdFill.style.height = (frac * 100) + '%';
    sendRate(v);
  });
  // Back to normal speed. Double-click on the fader has always done this and nothing
  // said so — the same complaint as the reverse toggle in 0.0.8, where the only way
  // out was to already know the way out. List mode has had a visible `1.0` button
  // since the beginning; this is that button, at the foot of the fader it belongs to.
  const toNormalRate = () => {
    parts.rateVal = 1;
    parts.spdFill.style.height = (((1 - RATE_MIN) / (RATE_MAX - RATE_MIN)) * 100) + '%';
    sendRate(1);
  };
  parts.spd.addEventListener('dblclick', toNormalRate);
  parts.rate1.addEventListener('click', toNormalRate);

  draggable(parts.pan, (e, r) => {
    const frac = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    parts.panDot.style.left = (frac * 100) + '%';
    setPan(tabId, frac * 2 - 1);
  });
  parts.pan.addEventListener('dblclick', () => {
    parts.panDot.style.left = '50%';
    setPan(tabId, 0);
  });

  // Progress doubles as the scrubber — video mode had no seek at all before this.
  draggable(parts.titlewrap, (e, r) => {
    if (!parts.duration) return;
    const frac = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    parts.progress.style.width = (frac * 100) + '%';
    toContent(tabId, { type: 'SEEK', absolute: frac * parts.duration });
  });

  // The picture is the biggest target in the tile and the transport buttons are the
  // smallest, at the far end of it. Clicking what you are looking at stops it.
  parts.vidbox.addEventListener('click', () => {
    if (dragging || !parts.controllable) return;
    toContent(tabId, { type: parts.paused ? 'PLAY' : 'PAUSE' });
    parts.paused = !parts.paused; // optimistic; the next INFO is the authority
  });

  // Always available, not only when something is already broken. The first version
  // hung this off the "no control" note, which meant a channel that was connected and
  // misbehaving — Netflix, scrubbing into an error page — had no way to be asked what
  // it was. The case you most want to report is not always the case that looks dead.
  parts.probe.addEventListener('click', async () => {
    const was = parts.probe.textContent;
    parts.probe.textContent = (await copyProbe(tabId)) ? 'copied' : 'console';
    setTimeout(() => { parts.probe.textContent = was; }, 2500);
  });

  parts.m.addEventListener('click', () => setMute(tabId));
  parts.s.addEventListener('click', (e) => setSolo(tabId, undefined, !e.shiftKey));
  parts.x.addEventListener('click', () => { dropChannel(tabId); renderVideo(); });
  parts.play.addEventListener('click', () => toContent(tabId, { type: 'PLAY' }));
  parts.pause.addEventListener('click', () => toContent(tabId, { type: 'PAUSE' }));
  parts.pitch.addEventListener('click', () => {
    parts.pitch.setAttribute('aria-pressed', String(!keepsPitch()));
    sendRate(parts.rateVal);
  });

  parts.tile = el; // setControllable marks the tile itself, not only its controls
  tiles.set(tabId, { el, parts });
  document.getElementById('video-grid').appendChild(el);
  return tiles.get(tabId);
}

// The crop arrives as fractions of the TAB VIEWPORT; the styles below are fractions
// of the CAPTURED FRAME. Those are the same numbers only when the frame is the
// viewport with nothing added.
//
// It usually isn't. Both quality tiers ask for a 16:9 box (426x240, 960x540) and a
// browser window is rarely 16:9, so the capturer fits the tab inside that box and
// pads the rest. A viewport narrower than 16:9 gets pillarboxed, and viewport
// fractions then land too far left and too wide — which is how the YouTube sidebar
// reappeared on the right of every tile after Brendan resized the window. Nothing
// about the code changed; the window did.
//
// Same object-fit: contain maths the content script uses for the picture inside the
// element. When the frame needs no padding the scales match, both pads are 0, and
// this reduces to `crop` unchanged — asserted in test/video.mjs.
function frameCrop(crop, frame) {
  if (!crop) return null;
  if (!frame || !frame.fw || !frame.fh || !frame.vw || !frame.vh) return crop;
  const { fw, fh, vw, vh } = frame;

  const scale = Math.min(fw / vw, fh / vh);
  const cw = vw * scale;
  const ch = vh * scale;
  const padX = (fw - cw) / 2;
  const padY = (fh - ch) / 2;

  return {
    x: (padX + crop.x * cw) / fw,
    y: (padY + crop.y * ch) / fh,
    w: (crop.w * cw) / fw,
    h: (crop.h * ch) / fh,
  };
}

function applyCrop(parts, crop, frame) {
  const v = parts.v;
  const c = frameCrop(crop, frame);
  if (!c || c.w <= 0.05 || c.h <= 0.05) {
    v.style.width = '100%'; v.style.height = '100%'; v.style.left = '0'; v.style.top = '0';
    return;
  }
  v.style.width = (100 / c.w) + '%';
  v.style.height = (100 / c.h) + '%';
  v.style.left = -(c.x * 100 / c.w) + '%';
  v.style.top = -(c.y * 100 / c.h) + '%';
}

// What the capture actually hands us, as opposed to what we asked for. getSettings()
// is authoritative once the track is running; the element's intrinsic size is the
// fallback for the first frames, when settings can still be empty.
function frameSize(stream, el) {
  const t = stream && stream.getVideoTracks ? stream.getVideoTracks()[0] : null;
  const s = t && t.getSettings ? t.getSettings() : null;
  if (s && s.width && s.height) return { fw: s.width, fh: s.height };
  if (el && el.videoWidth && el.videoHeight) return { fw: el.videoWidth, fh: el.videoHeight };
  return null;
}

function drawViz(parts, points) {
  const g = parts.vizCtx;
  const { width: w, height: h } = parts.viz;
  g.clearRect(0, 0, w, h);
  if (!points || !points.length) return;
  g.fillStyle = parts.colour || '#c9a227';
  const bw = w / points.length;
  for (let i = 0; i < points.length; i++) {
    const bh = Math.max(1, points[i] * h);
    g.fillRect(i * bw, (h - bh) / 2, Math.max(1, bw - 1), bh);
  }
}

// Say out loud when a channel has no page-side control, and stop pretending the
// controls that need it are live.
//
// Level, pan, mute and solo run in this page's own audio graph and work on anything
// that can be captured. Speed, scrub, transport and the pitch mode run on the media
// element itself, through the content script, and there are tabs it cannot reach: one
// that has navigated since it was added (the activeTab grant goes with the old page),
// a chrome:// page, a player with its media inside an iframe.
//
// Before 0.0.9 those controls were simply always drawn and silently did nothing on
// every non-YouTube tab, which is what Brendan hit. A dead control that looks alive is
// worse than one that admits it, so the tile marks them idle and says what to do.
function setControllable(parts, on, reason) {
  if (parts.controllable === on) return;
  parts.controllable = on;
  for (const el of [parts.spd, parts.rate1, parts.play, parts.pause, parts.pitch]) {
    el.classList.toggle('idle', !on);
  }
  // The scrubber has two reasons to be idle and both must hold for it to come back.
  parts.titlewrap.classList.toggle('idle', !on || !parts.scrubbable);
  for (const el of [parts.rate1, parts.play, parts.pause, parts.pitch]) el.disabled = !on;
  parts.tile.classList.toggle('tile--nocontrol', !on);
  parts.note.textContent = on
    ? ''
    : reason === 'no media element'
      ? 'nothing here to drive'
      : 'no control — click the toolbar button on this tab';
}

// A protected stream is drivable but not seekable — see the refusal in content.js.
// Speed, pitch and transport stay live; only the scrubber goes, and it says why
// rather than silently doing nothing or, worse, breaking the page.
function setScrubbable(parts, on) {
  if (parts.scrubbable === on) return;
  parts.scrubbable = on;
  parts.titlewrap.classList.toggle('idle', !on || !parts.controllable);
  if (parts.controllable) parts.note.textContent = on ? '' : 'no scrub — protected';
}

// Size the grid so each cell is exactly video-plus-strips, and centre whatever is
// left over as ONE margin. Strip sizes are measured from the DOM rather than
// duplicated here, so the CSS stays the single source of truth.
function layoutGrid() {
  const grid = document.getElementById('video-grid');
  const wrap = grid.parentElement;
  const first = tiles.values().next().value;
  if (!first || !wrap) return;

  const n = tiles.size;
  const cols = n <= 1 ? 1 : n <= 4 ? 2 : 3;
  const rows = Math.ceil(n / cols);

  const p = first.parts;
  const sideW = p.left.offsetWidth + p.right.offsetWidth;
  const bottomH = p.bottom.offsetHeight;
  const panH = p.pan.offsetHeight;
  const border = (first.el.offsetWidth - first.el.clientWidth) || 6;

  // The wrapper IS the space left over after the tape strip and button bar — it is a
  // flex:1 sibling of them. Subtracting their heights again shrank the grid to a
  // fraction of the screen and made the tiles overlap.
  const availW = wrap.clientWidth;
  const availH = wrap.clientHeight;
  if (availW <= 0 || availH <= 0) return;

  // Try height-limited, then width-limited, and take whichever fits both.
  const fromH = () => {
    const cellH = availH / rows;
    const videoH = cellH - bottomH - panH - border;
    const videoW = videoH * (16 / 9);
    return { videoW, videoH, cellW: videoW + sideW + border, cellH };
  };
  const fromW = () => {
    const cellW = availW / cols;
    const videoW = cellW - sideW - border;
    const videoH = videoW * (9 / 16);
    return { videoW, videoH, cellW, cellH: videoH + bottomH + panH + border };
  };

  let fit = fromH();
  if (fit.cellW * cols > availW || fit.videoW <= 0) fit = fromW();
  if (fit.videoW <= 0 || fit.videoH <= 0) return;

  grid.style.width = Math.floor(fit.cellW * cols) + 'px';
  grid.style.height = Math.floor(fit.cellH * rows) + 'px';
  grid.style.setProperty('--videoW', Math.floor(fit.videoW) + 'px');
}

async function renderVideo() {
  if (!videoOn) return;
  const st = Mixer.state();
  const channels = (st && st.channels) || [];
  const lv = Mixer.levels();
  const levelBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.db]));
  const stateBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.state]));

  let structureChanged = false;
  for (const [tabId, t] of tiles) {
    if (!channels.some((c) => c.tabId === tabId)) {
      t.el.remove(); tiles.delete(tabId); structureChanged = true;
    }
  }

  const grid = document.getElementById('video-grid');
  grid.dataset.count = String(Math.min(channels.length, 6));

  for (const [i, ch] of channels.entries()) {
    let t = tiles.get(ch.tabId);
    if (!t) { t = buildTile(ch.tabId); structureChanged = true; }
    const p = t.parts;

    const colour = colourFor(i);
    p.colour = colour;
    t.el.style.setProperty('--ch', colour);

    p.title.textContent = ch.title || 'tab ' + ch.tabId;

    const stream = Mixer.getStream(ch.tabId);
    const hasVideo = !!(stream && stream.getVideoTracks && stream.getVideoTracks().length);
    if (hasVideo && !p.streamAttached) {
      p.v.srcObject = stream;
      p.v.play().catch(() => {});
      p.streamAttached = true;
    }

    if (dragging !== p.lvl) p.lvlFill.style.height = ((ch.level / 1.5) * 100) + '%';
    if (dragging !== p.pan) p.panDot.style.left = (((ch.pan + 1) / 2) * 100) + '%';

    const db = levelBy.get(ch.tabId);
    const meterFrac = db === null || db === undefined ? 0 : Math.max(0, Math.min(1, (db + 60) / 60));
    p.meter.style.height = (meterFrac * 100) + '%';
    // Green until it is worth knowing, amber approaching the rails, red at them. The
    // meter's HEIGHT is still RMS, which is what you balance by; the COLOUR is peak,
    // which is what runs out of headroom.
    p.meter.dataset.level = stateBy.get(ch.tabId) || 'ok';

    p.m.setAttribute('aria-pressed', String(!!ch.muted));
    p.s.setAttribute('aria-pressed', String(!!ch.soloed));

    // Ask every channel, not just the ones a URL guess called YouTube. What the page
    // side can do is now a live fact — it answers or it does not — rather than
    // something inferred from an address that was read once at capture time.
    const info = await toContent(ch.tabId, { type: 'INFO' });
    setControllable(p, !!(info && info.ok), info && info.reason);

    if (info && info.ok) {
      p.duration = info.duration || 0;
      p.paused = !!info.paused;
      if (dragging !== p.spd) {
        p.rateVal = info.playbackRate;
        const frac = (info.playbackRate - RATE_MIN) / (RATE_MAX - RATE_MIN);
        p.spdFill.style.height = (Math.max(0, Math.min(1, frac)) * 100) + '%';
      }
      p.pitch.setAttribute('aria-pressed', String(!!info.preservesPitch));
      setScrubbable(p, !info.drm);
      if (dragging !== p.titlewrap && p.duration) {
        p.progress.style.width = ((info.currentTime / p.duration) * 100) + '%';
      }

      // The tab can navigate to a new video under us — autoplay, or the next one
      // in a mix. Audio and picture follow it, because both come from the live
      // stream; the title did not, because ch.title is a snapshot taken once at
      // capture time and never written again. document.title is read fresh on
      // every INFO, so just use it. Never on a failed INFO: the content script
      // answers {ok:false} during the navigation gap and blanking the label there
      // would be a flicker on every track change.
      if (info.title) {
        p.title.textContent = info.title;
        Mixer.setTitle(ch.tabId, info.title); // no-op unless it actually changed
      }

      // An audio-only source will never have a picture — SoundCloud and Bandcamp
      // drive a 0x0 <audio> — so stop paying for frames of a webpage nobody is
      // going to look at. Not merely hidden by CSS: the track is switched off, so
      // the page is not being sent at all.
      if (info.picture === false) {
        p.crop = null; // a stale rectangle from a previous video would freeze on screen
        if (ch.wantsVideo) Mixer.setChannelVideo(ch.tabId, false);
      } else if (!ch.wantsVideo) {
        Mixer.setChannelVideo(ch.tabId, true);
      }

      if (info.crop) {
        p.crop = info.crop;
        const fs = frameSize(stream, p.v);
        p.frame = fs && info.vw && info.vh
          ? { ...fs, vw: info.vw, vh: info.vh }
          : null;
        applyCrop(p, info.crop, p.frame);
      }
    } else {
      // No answer, so no fresh title either. The tab's own title is the next best
      // thing and it is already being polled for the deck list — better than a tile
      // sitting there naming a video that stopped playing when the tab moved on.
      // Nothing comes back for a synthetic channel, which has no tab, and it keeps
      // whatever label it was given.
      const fallback = tabTitleOf(ch.tabId);
      if (fallback) p.title.textContent = fallback;
    }

    // Show the picture only once we know which rectangle of it is the player.
    //
    // Everything else gets the waveform: an audio-only tab, and any tab we have not
    // heard from yet. That second case is the privacy one. An uncropped frame is the
    // whole webpage — the sidebar, the account menu, whatever is in the next tab
    // along — and until 0.0.9 that is exactly what every non-YouTube tile showed,
    // permanently. The scope is both the honest picture of an audio source and the
    // safe thing to display when we cannot yet crop.
    const showPicture = hasVideo && !!p.crop;
    t.el.classList.toggle('tile--audio', !showPicture);
    if (!showPicture) drawViz(p, Mixer.waveform(ch.tabId, 96));
  }

  // DOM order must match channel order, or the colour sequence stops matching what
  // you see left-to-right — colours are assigned by channel index, and a dropped and
  // re-added channel otherwise keeps its old DOM position. Only re-append when the
  // order actually differs: moving a <video> node restarts its decode.
  const want = channels.map((c) => c.tabId);
  const have = [...grid.children].map((el) => {
    for (const [id, t] of tiles) if (t.el === el) return id;
    return null;
  });
  if (want.join() !== have.join()) {
    for (const id of want) { const t = tiles.get(id); if (t) grid.appendChild(t.el); }
    structureChanged = true;
  }

  document.getElementById('video-empty').style.display = channels.length ? 'none' : '';
  if (structureChanged) layoutGrid();
}

// ---------------------------------------------------------------- quality

// Our capture is only half the cost — each source tab is also decoding YouTube at full
// quality. Asking the player to drop its own resolution is the bigger saving. It is
// page JavaScript, so a content script cannot reach it: this needs MAIN world.
async function setYouTubeQuality(tabId, level) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      args: [level],
      func: (q) => {
        try {
          const p = document.getElementById('movie_player');
          if (!p || !p.setPlaybackQualityRange) return 'no player';
          // Undocumented internals — treat any failure as "quality unchanged".
          if (q === 'auto') p.setPlaybackQualityRange('tiny', 'highres');
          else p.setPlaybackQualityRange(q, q);
          return 'ok';
        } catch (e) {
          return 'err';
        }
      },
    });
  } catch {
    /* tab gone, not a YouTube page, or internals moved — never fatal */
  }
}

async function setQuality(high) {
  hq = !!high;
  localStorage.setItem('ym-hq', hq ? '1' : '0');
  const btn = document.getElementById('video-hq');
  if (btn) btn.setAttribute('aria-pressed', String(hq));

  await Mixer.setQuality(hq ? 'high' : 'low');

  const st = Mixer.state();
  for (const ch of (st.channels || [])) {
    if (!ch.synthetic) setYouTubeQuality(ch.tabId, hq ? 'auto' : 'tiny');
  }
  return { ok: true, hq };
}

// ---------------------------------------------------------------- mode

function setVideoMode(on) {
  videoOn = !!on;
  localStorage.setItem('ym-video', videoOn ? '1' : '0');
  document.body.classList.toggle('video-mode', videoOn);
  document.getElementById('video-switch').setAttribute('aria-pressed', String(videoOn));

  // Move the tape and MIDI panels rather than rebuilding them: one of each, no chance
  // of the two modes drifting apart, and every handler stays bound.
  stash('tape'); stash('midi'); stash('keysbar');
  if (videoOn) {
    document.getElementById('video-taperow').prepend(document.getElementById('tape'));
    // The keyboard strip follows the tape, by the same move-don't-rebuild rule: one
    // element, no chance of the two modes drifting apart about what is selected.
    document.getElementById('video-tape').appendChild(document.getElementById('keysbar'));
    document.getElementById('video-midi-body').appendChild(document.getElementById('midi'));
  } else {
    restore('tape'); restore('midi'); restore('keysbar');
  }

  Mixer.setVideoEnabled(videoOn);

  if (videoOn) {
    renderVideo().then(layoutGrid);
    if (!videoTimer) videoTimer = setInterval(renderVideo, 250);
  } else {
    clearInterval(videoTimer);
    videoTimer = null;
    for (const [, t] of tiles) { t.parts.v.srcObject = null; t.parts.streamAttached = false; }
  }
}

function initVideo() {
  document.getElementById('video-switch')
    .addEventListener('click', () => setVideoMode(!videoOn));

  document.getElementById('video-full').addEventListener('click', () => {
    const el = document.getElementById('video');
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen().catch(() => {});
  });

  const clean = document.getElementById('video-clean');
  clean.addEventListener('click', () => {
    const on = clean.getAttribute('aria-pressed') !== 'true';
    clean.setAttribute('aria-pressed', String(on));
    document.body.classList.toggle('video-clean', on);
  });

  const midiBtn = document.getElementById('video-midi-btn');
  midiBtn.addEventListener('click', () => {
    const on = midiBtn.getAttribute('aria-pressed') !== 'true';
    midiBtn.setAttribute('aria-pressed', String(on));
    document.getElementById('video-midi').style.display = on ? 'block' : 'none';
  });

  document.getElementById('video-hq')
    .addEventListener('click', () => setQuality(!hq));

  window.addEventListener('resize', () => { if (videoOn) layoutGrid(); });
  document.addEventListener('fullscreenchange', () => { if (videoOn) setTimeout(layoutGrid, 120); });

  // Through setQuality, not by stamping the attribute: audio.js always starts at
  // 'low', so setting the button by hand left it claiming HQ over a 426x240 capture
  // after every panel reload. Same family as the stale title — the panel saying
  // something that is not true.
  setQuality(localStorage.getItem('ym-hq') === '1');
  setVideoMode(localStorage.getItem('ym-video') === '1');
}

initVideo();

Object.assign(window, {
  videoMode: setVideoMode,
  videoTiles: () => tiles.size,
  videoIsOn: () => videoOn,
  videoQuality: setQuality,
  videoIsHq: () => hq,
  videoLayout: layoutGrid,
  // The crop maths, reachable without a real capture. Everything that made the
  // sidebar reappear lives in here, and a real capture cannot be automated (the
  // toolbar click is manual), so this is the only place it can be guarded.
  videoFrameCrop: frameCrop,
  videoApplyCrop: (tabId, crop, frame) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    applyCrop(t.parts, crop, frame);
    const s = t.parts.v.style;
    return { w: s.width, h: s.height, l: s.left, t: s.top };
  },
  // The capability gate, reachable without a real tab. renderVideo drives this from
  // whether the content script answered; a synthetic channel is never answered, so
  // this is how the enabled state is exercised in both directions.
  videoSetControllable: (tabId, on, reason) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    setControllable(t.parts, !!on, reason);
    return t.parts.controllable;
  },
  videoTileState: (tabId) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    const p = t.parts;
    return {
      controllable: p.controllable,
      note: p.note.textContent,
      nocontrol: t.el.classList.contains('tile--nocontrol'),
      audio: t.el.classList.contains('tile--audio'),
      spdIdle: p.spd.classList.contains('idle'),
      rate: p.rateVal,
      spdFill: p.spdFill.style.height,
      crop: p.crop,
      paused: p.paused,
    };
  },
  videoTileTitle: (tabId) => {
    const t = tiles.get(tabId);
    return t ? t.parts.title.textContent : null;
  },
  // Whether the captured frame really is the tab viewport, per channel. Capture
  // cannot be automated, so this is the only way to see the padding on a real tab:
  // run it in the panel console with tabs captured and video mode on. `padX`/`padY`
  // above a pixel or two is the frame carrying bars, which is what put the YouTube
  // sidebar back into every tile.
  videoFrameReport: () => [...tiles].map(([tabId, t]) => {
    const f = t.parts.frame;
    if (!f) return { tabId, frame: null };
    const scale = Math.min(f.fw / f.vw, f.fh / f.vh);
    return {
      tabId,
      frame: `${f.fw}x${f.fh}`, viewport: `${f.vw}x${f.vh}`,
      frameAspect: +(f.fw / f.fh).toFixed(3), viewportAspect: +(f.vw / f.vh).toFixed(3),
      padX: +((f.fw - f.vw * scale) / 2).toFixed(2),
      padY: +((f.fh - f.vh * scale) / 2).toFixed(2),
      crop: t.parts.crop, mapped: frameCrop(t.parts.crop, f),
    };
  }),
  videoColourOf: (tabId) => {
    const t = tiles.get(tabId);
    return t ? t.el.style.getPropertyValue('--ch') : null;
  },
  videoBoxRatio: (tabId) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    const r = t.parts.vidbox.getBoundingClientRect();
    return r.height ? r.width / r.height : null;
  },
  // How much of the middle column the picture actually uses — the "no wasted space"
  // claim, measured rather than eyeballed.
  videoFillRatio: (tabId) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    const box = t.parts.vidbox.getBoundingClientRect();
    const mid = t.parts.vidbox.parentElement.getBoundingClientRect();
    return mid.width ? box.width / mid.width : null;
  },
  // test seam: synthetic channels have no content script, so no duration arrives
  videoSetDuration: (tabId, d) => { const t = tiles.get(tabId); if (t) t.parts.duration = d; },
  videoReady: true,
});
