// Offscreen document: owns the single AudioContext, every captured channel, and the
// tape. One offscreen document is allowed per extension, so all channels live here.
//
// Graph:  [tab capture] -> gain -> (meter tap) -> master -> TAPE -> out meter -> dest

let ctx = null;
let master = null;
let masterAnalyser = null; // pre-tape
let outAnalyser = null; // post-tape
let outL = null, outR = null; // post-tape, per side
let tape = null;
const channels = new Map(); // tabId -> { stream, source, gain, analyser, title }

const TAPE_SECONDS = 60;
const TAPE_LATENCY_SEC = 0.25;

async function ensureAudio() {
  if (ctx) return ctx;
  ctx = new AudioContext();

  await ctx.audioWorklet.addModule(chrome.runtime.getURL('tape-worklet.js'));

  master = ctx.createGain();
  master.gain.value = 1;

  masterAnalyser = ctx.createAnalyser();
  masterAnalyser.fftSize = 2048;
  master.connect(masterAnalyser); // tap only

  tape = new AudioWorkletNode(ctx, 'tape', {
    numberOfInputs: 1,
    numberOfOutputs: 1,
    outputChannelCount: [2],
    processorOptions: { seconds: TAPE_SECONDS, latencySec: TAPE_LATENCY_SEC },
  });

  outAnalyser = ctx.createAnalyser();
  outAnalyser.fftSize = 2048;

  // An AnalyserNode downmixes to mono, so pan is invisible to it. Split for L/R.
  outL = ctx.createAnalyser(); outL.fftSize = 2048;
  outR = ctx.createAnalyser(); outR.fftSize = 2048;
  const splitter = ctx.createChannelSplitter(2);

  master.connect(tape);
  tape.connect(outAnalyser); // tap only
  tape.connect(splitter);
  splitter.connect(outL, 0);
  splitter.connect(outR, 1);
  tape.connect(ctx.destination);

  await ctx.resume();
  return ctx;
}

// RMS in dBFS over one analyser frame. null for digital silence.
function rmsDb(analyser) {
  const buf = new Float32Array(analyser.fftSize);
  analyser.getFloatTimeDomainData(buf);
  let sum = 0;
  for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
  const rms = Math.sqrt(sum / buf.length);
  return rms > 0 ? 20 * Math.log10(rms) : null;
}

async function addChannel({ streamId, tabId, title }) {
  if (channels.has(tabId)) return { ok: true, already: true, tabId };

  // Legacy mandatory-constraint form is required for chromeMediaSource: 'tab'.
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
    video: false,
  });

  const c = await ensureAudio();
  const source = c.createMediaStreamSource(stream);
  const gain = c.createGain();
  gain.gain.value = 1;
  const panner = c.createStereoPanner();
  panner.pan.value = 0;
  const analyser = c.createAnalyser();
  analyser.fftSize = 2048;

  // Capturing a tab suppresses its own playback, so this graph is the only path to
  // the speakers — not a duplicate of it.
  source.connect(gain);
  gain.connect(analyser); // metering tap, pre-pan so the meter reads the fader
  gain.connect(panner);
  panner.connect(master);

  // level/muted/soloed are the intent; gain.gain is the computed result.
  channels.set(tabId, {
    stream, source, gain, panner, analyser, title,
    level: 1, muted: false, soloed: false,
  });
  applyGains();

  return {
    ok: true,
    tabId,
    title,
    channelCount: channels.size,
    sampleRate: c.sampleRate,
    trackSettings: stream.getAudioTracks()[0]?.getSettings?.() ?? null,
  };
}

function dropChannel(tabId) {
  const ch = channels.get(tabId);
  if (!ch) return { ok: false, reason: 'no such channel' };
  ch.stream.getTracks().forEach((t) => t.stop());
  try {
    ch.source.disconnect();
    ch.gain.disconnect();
    ch.panner.disconnect();
  } catch {}
  channels.delete(tabId);
  applyGains(); // dropping the soloed channel must un-duck the rest
  return { ok: true, channelCount: channels.size };
}

// Solo is a property of the whole mixer, not of one channel, so effective gain is
// always recomputed across every channel rather than poked per-channel.
function applyGains() {
  if (!ctx) return;
  const anySolo = [...channels.values()].some((c) => c.soloed);
  for (const ch of channels.values()) {
    const target = ch.muted || (anySolo && !ch.soloed) ? 0 : ch.level;
    ch.gain.gain.setTargetAtTime(target, ctx.currentTime, 0.01); // ramp, no click
  }
}

function setLevel(tabId, value) {
  const ch = channels.get(tabId);
  if (!ch) return { ok: false, reason: 'no such channel' };
  ch.level = Math.max(0, value);
  applyGains();
  return { ok: true, tabId, level: ch.level };
}

function setMute(tabId, muted) {
  const ch = channels.get(tabId);
  if (!ch) return { ok: false, reason: 'no such channel' };
  ch.muted = muted === undefined ? !ch.muted : !!muted;
  applyGains();
  return { ok: true, tabId, muted: ch.muted };
}

function setSolo(tabId, soloed, exclusive) {
  const ch = channels.get(tabId);
  if (!ch) return { ok: false, reason: 'no such channel' };
  const next = soloed === undefined ? !ch.soloed : !!soloed;
  // Exclusive by default: soloing one clears the others, which is what a single
  // click on a mixer means. Pass exclusive:false to build a multi-channel solo.
  if (next && exclusive !== false) {
    for (const other of channels.values()) other.soloed = false;
  }
  ch.soloed = next;
  applyGains();
  return {
    ok: true, tabId, soloed: ch.soloed,
    soloing: [...channels.entries()].filter(([, c]) => c.soloed).map(([id]) => id),
  };
}

function setPan(tabId, pan) {
  const ch = channels.get(tabId);
  if (!ch) return { ok: false, reason: 'no such channel' };
  const v = Math.max(-1, Math.min(1, pan));
  ch.panner.pan.setTargetAtTime(v, ctx.currentTime, 0.01);
  return { ok: true, tabId, pan: v };
}

// Test seam: a channel fed by an oscillator instead of a captured stream, so
// pan/mute/solo can be exercised without the toolbar click tabCapture requires.
async function testChannel({ tabId, hz = 440 }) {
  const c = await ensureAudio();
  if (channels.has(tabId)) return { ok: true, already: true, tabId };
  const osc = c.createOscillator();
  osc.frequency.value = hz;
  const gain = c.createGain();
  const panner = c.createStereoPanner();
  const analyser = c.createAnalyser();
  analyser.fftSize = 2048;
  osc.connect(gain);
  gain.connect(analyser);
  gain.connect(panner);
  panner.connect(master);
  osc.start();
  channels.set(tabId, {
    stream: { getTracks: () => [], getAudioTracks: () => [] },
    source: osc, gain, panner, analyser, title: 'test ' + hz + 'Hz',
    level: 1, muted: false, soloed: false, synthetic: true,
  });
  applyGains();
  return { ok: true, tabId, hz, channelCount: channels.size };
}

function state() {
  return {
    ok: true,
    contextState: ctx ? ctx.state : 'none',
    sampleRate: ctx ? ctx.sampleRate : null,
    tapeReady: !!tape,
    channels: [...channels.entries()].map(([tabId, ch]) => ({
      tabId,
      title: ch.title,
      level: ch.level,
      muted: ch.muted,
      soloed: ch.soloed,
      synthetic: !!ch.synthetic,
      pan: ch.panner.pan.value,
      gain: ch.gain.gain.value, // computed from level/mute/solo
      live: ch.stream.getAudioTracks()[0]?.readyState ?? 'unknown',
    })),
  };
}

function levels() {
  if (!ctx) return { ok: false, reason: 'no context' };
  return {
    ok: true,
    masterPreTape: rmsDb(masterAnalyser),
    out: rmsDb(outAnalyser),
    outL: rmsDb(outL),
    outR: rmsDb(outR),
    channels: [...channels.entries()].map(([tabId, ch]) => ({
      tabId,
      title: (ch.title || '').slice(0, 40),
      gain: ch.gain.gain.value,
      db: rmsDb(ch.analyser),
    })),
  };
}

// Dominant frequency of an analyser frame, by parabolic-interpolated peak bin.
// Used to prove varispeed: a 440Hz tone at rate 0.5 must come out near 220Hz.
function peakHz(analyser) {
  const bins = new Float32Array(analyser.frequencyBinCount);
  analyser.getFloatFrequencyData(bins);
  let peak = 1;
  for (let i = 2; i < bins.length - 1; i++) if (bins[i] > bins[peak]) peak = i;
  const binHz = ctx.sampleRate / analyser.fftSize;
  const [l, c, r] = [bins[peak - 1], bins[peak], bins[peak + 1]];
  const denom = l - 2 * c + r;
  const shift = denom !== 0 ? (0.5 * (l - r)) / denom : 0;
  return (peak + shift) * binHz;
}

// Test tone straight into master, so the tape can be exercised with no tab capture.
let testOsc = null;
async function testTone({ on, hz = 440 }) {
  const c = await ensureAudio();
  if (on === false) {
    if (testOsc) {
      try { testOsc.stop(); testOsc.disconnect(); } catch {}
      testOsc = null;
    }
    return { ok: true, tone: 'off' };
  }
  if (testOsc) { try { testOsc.stop(); testOsc.disconnect(); } catch {} }
  testOsc = c.createOscillator();
  const g = c.createGain();
  g.gain.value = 0.3;
  testOsc.frequency.value = hz;
  testOsc.connect(g).connect(master);
  testOsc.start();
  return { ok: true, tone: 'on', hz, sampleRate: c.sampleRate };
}

// Independent of the FFT: count zero crossings over one time-domain frame.
function zeroCrossHz(analyser) {
  const buf = new Float32Array(analyser.fftSize);
  analyser.getFloatTimeDomainData(buf);
  let crossings = 0;
  for (let i = 1; i < buf.length; i++) {
    if ((buf[i - 1] < 0 && buf[i] >= 0) || (buf[i - 1] >= 0 && buf[i] < 0)) crossings++;
  }
  return (crossings / 2) * (ctx.sampleRate / buf.length);
}

// dBFS at a specific frequency — used to measure interpolation imaging.
function dbAt(analyser, hz) {
  const bins = new Float32Array(analyser.frequencyBinCount);
  analyser.getFloatFrequencyData(bins);
  const binHz = ctx.sampleRate / analyser.fftSize;
  const c = Math.round(hz / binHz);
  let peak = -Infinity;
  for (let i = Math.max(0, c - 1); i <= c + 1 && i < bins.length; i++) {
    if (bins[i] > peak) peak = bins[i];
  }
  return Number.isFinite(peak) ? peak : null;
}

function probeTones(hzList) {
  if (!ctx) return { ok: false, reason: 'no context' };
  return { ok: true, out: hzList.map((hz) => ({ hz, db: dbAt(outAnalyser, hz) })) };
}

function probe() {
  if (!ctx) return { ok: false, reason: 'no context' };
  return {
    ok: true,
    inHz: peakHz(masterAnalyser),
    outHz: peakHz(outAnalyser),
    inZcHz: zeroCrossHz(masterAnalyser),
    outZcHz: zeroCrossHz(outAnalyser),
    inDb: rmsDb(masterAnalyser),
    outDb: rmsDb(outAnalyser),
  };
}

// ---- tape ---------------------------------------------------------------

function tapeSet(msg) {
  if (!tape) return { ok: false, reason: 'tape not ready' };
  if (msg.rate !== undefined) {
    const p = tape.parameters.get('rate');
    // Ramp rather than jump so varispeed glides, per the tape feel.
    p.setTargetAtTime(msg.rate, ctx.currentTime, msg.glide ?? 0.05);
  }
  const fwd = {};
  for (const k of ['mode', 'loopEnabled', 'latencySec', 'interp']) {
    if (msg[k] !== undefined) fwd[k] = msg[k];
  }
  if (Object.keys(fwd).length) tape.port.postMessage({ type: 'set', ...fwd });
  return { ok: true, applied: { ...fwd, rate: msg.rate } };
}

function tapeCmd(msg) {
  if (!tape) return { ok: false, reason: 'tape not ready' };
  tape.port.postMessage({
    type: msg.cmd, seconds: msg.seconds, on: msg.on, catchUp: msg.catchUp,
  });
  return { ok: true, cmd: msg.cmd, on: msg.on, seconds: msg.seconds };
}

function tapeQuery() {
  if (!tape) return Promise.resolve({ ok: false, reason: 'tape not ready' });
  return new Promise((resolve) => {
    const to = setTimeout(() => resolve({ ok: false, reason: 'tape query timeout' }), 2000);
    const onMsg = (e) => {
      if (e.data && e.data.type === 'state') {
        clearTimeout(to);
        tape.port.removeEventListener('message', onMsg);
        resolve({ ok: true, ...e.data });
      }
    };
    tape.port.addEventListener('message', onMsg);
    tape.port.start();
    tape.port.postMessage({ type: 'query' });
  });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen') return false;

  (async () => {
    try {
      switch (msg.type) {
        case 'ADD_CHANNEL': sendResponse(await addChannel(msg)); break;
        case 'DROP_CHANNEL': sendResponse(dropChannel(msg.tabId)); break;
        case 'SET_GAIN': // kept as an alias so existing callers keep working
        case 'SET_LEVEL': sendResponse(setLevel(msg.tabId, msg.value)); break;
        case 'SET_MUTE': sendResponse(setMute(msg.tabId, msg.muted)); break;
        case 'SET_SOLO': sendResponse(setSolo(msg.tabId, msg.soloed, msg.exclusive)); break;
        case 'SET_PAN': sendResponse(setPan(msg.tabId, msg.pan)); break;
        case 'GET_STATE': sendResponse(state()); break;
        case 'GET_LEVELS': sendResponse(levels()); break;
        case 'TAPE_SET': sendResponse(tapeSet(msg)); break;
        case 'TAPE_CMD': sendResponse(tapeCmd(msg)); break;
        case 'TAPE_QUERY': sendResponse(await tapeQuery()); break;
        case 'TEST_TONE': sendResponse(await testTone(msg)); break;
        case 'TEST_CHANNEL': sendResponse(await testChannel(msg)); break;
        case 'PROBE': sendResponse(probe()); break;
        case 'PROBE_TONES': sendResponse(probeTones(msg.hz || [])); break;
        default: sendResponse({ ok: false, reason: 'unknown message ' + msg.type });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e), name: e && e.name });
    }
  })();

  return true; // async response
});
