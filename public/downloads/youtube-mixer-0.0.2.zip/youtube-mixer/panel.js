// Extension page: the mixer UI.
//
// The deck list is a direct rendering of the offscreen graph's channels — nothing
// else is ever listed. That is deliberate: v0.0.1 also listed merely-audible tabs,
// which rendered a full deck whose level and pan were disabled (they need a capture)
// while rate and pos worked (they come from the content script and don't). It looked
// like two broken sliders. Now, if a deck is on screen it is captured, so all of its
// controls work.
//
// Two control surfaces per deck, with different reach:
//   - level / pan / mute / solo -> offscreen graph on the captured stream (any tab)
//   - rate / transport / seek   -> content script on the native <video> (YouTube only)

// ---------------------------------------------------------------- plumbing

async function ensureOffscreen() {
  const ctxs = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (ctxs.length) return { created: false };
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Mix captured tab audio through a Web Audio graph.',
  });
  return { created: true };
}

async function toOffscreen(msg, tries = 25) {
  // Every path needs the document, not just addChannel — otherwise the first call
  // of a session gets "Receiving end does not exist".
  await ensureOffscreen();
  for (let i = 0; i < tries; i++) {
    try {
      return await chrome.runtime.sendMessage({ target: 'offscreen', ...msg });
    } catch (e) {
      if (i === tries - 1) return { ok: false, error: String(e.message || e) };
      await new Promise((r) => setTimeout(r, 60));
    }
  }
}

// Talks to the content script in a YouTube tab (not the offscreen document).
async function toContent(tabId, msg) {
  try {
    return await chrome.tabs.sendMessage(tabId, { target: 'content', ...msg });
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
}

const listTabs = async () =>
  (await chrome.tabs.query({})).map((t) => ({
    id: t.id,
    audible: !!t.audible,
    title: (t.title || '').slice(0, 80),
    url: t.url || '',
  }));

async function addChannel(tabId) {
  await ensureOffscreen();
  let streamId;
  try {
    streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  } catch (e) {
    return { ok: false, stage: 'getMediaStreamId', error: String(e.message || e) };
  }
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  return toOffscreen({
    type: 'ADD_CHANNEL', streamId, tabId, title: (tab && tab.title) || 'tab ' + tabId,
  });
}

const getState = () => toOffscreen({ type: 'GET_STATE' });
const getLevels = () => toOffscreen({ type: 'GET_LEVELS' });
const setGain = (tabId, value) => toOffscreen({ type: 'SET_LEVEL', tabId, value });
const setMute = (tabId, muted) => toOffscreen({ type: 'SET_MUTE', tabId, muted });
const setSolo = (tabId, soloed, exclusive) =>
  toOffscreen({ type: 'SET_SOLO', tabId, soloed, exclusive });
const setPan = (tabId, pan) => toOffscreen({ type: 'SET_PAN', tabId, pan });
const dropChannel = (tabId) => toOffscreen({ type: 'DROP_CHANNEL', tabId });
const tapeSet = (msg) => toOffscreen({ type: 'TAPE_SET', ...msg });
const tapeCmd = (cmd, seconds) => toOffscreen({ type: 'TAPE_CMD', cmd, seconds });
const tapeQuery = () => toOffscreen({ type: 'TAPE_QUERY' });

// ---------------------------------------------------------------- ui state

const decks = new Map(); // tabId -> { el, parts }
let dragging = null; // control the user is moving; never overwrite it from a poll

// Last KNOWN-GOOD channel list. A failed message must never be read as "no
// channels" — refresh() runs every 700ms, so treating one dropped message as an
// empty mixer wiped every deck on screen. That was the v0.0.1 bug that made paused
// tracks look permanently lost.
let lastChannels = [];

const fmtTime = (s) =>
  Number.isFinite(s)
    ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`
    : '--:--';
const fmtPan = (v) =>
  Math.abs(v) < 0.02 ? 'C' : (v < 0 ? 'L' : 'R') + Math.round(Math.abs(v) * 100);
const fmtDb = (db) => (db === null || db === undefined ? '  -inf' : db.toFixed(1).padStart(6));

function trackDrag(el) {
  el.addEventListener('pointerdown', () => (dragging = el));
  el.addEventListener('pointerup', () => (dragging = null));
  el.addEventListener('blur', () => { if (dragging === el) dragging = null; });
}

// ---------------------------------------------------------------- decks

function buildDeck(tabId, isYt) {
  const el = document.createElement('div');
  el.className = 'deck';

  el.innerHTML = `
    <div class="deck__head">
      <span class="deck__title"></span>
      <span class="deck__tag" data-help="This channel's state. 'captured' means audio is flowing. 'paused' means it is still in the mixer but the tab is silent. 'ad playing' means YouTube is running an advert, which has its own player, so rate and position apply to the advert until it ends."></span>
      <span class="deck__meter" data-help="Live level of this channel in dBFS, measured after the fader and before the pan."></span>
      <button class="deck__x" title="Remove from mixer"
        data-help="Take this tab out of the mixer and stop capturing it. Add it back with the toolbar button.">&times;</button>
    </div>
    <div class="row">
      <label>level</label>
      <input type="range" class="level" min="0" max="1.5" step="0.01" value="1"
        data-help="Channel fader. Runs to 1.5 so you can push a quiet source past unity. Works on any captured tab, YouTube or not." />
      <span class="val lvlv">1.00</span>
      <span class="btns">
        <button class="mute hot" aria-pressed="false"
          data-help="Silence this channel without moving its fader.">mute</button>
        <button class="solo" aria-pressed="false"
          data-help="Hear only this channel. Ducks the others without touching their faders, so unsoloing restores your mix exactly. Shift-click to solo several at once.">solo</button>
      </span>
    </div>
    <div class="row pan-row">
      <label>pan</label>
      <input type="range" class="pan" min="-1" max="1" step="0.01" value="0"
        data-help="Position in the stereo field, hard left through centre to hard right." />
      <span class="val panv">C</span>
      <span class="btns"><button class="pancenter"
        data-help="Return this channel to dead centre.">centre</button></span>
    </div>
    <div class="row rate-row">
      <label>rate</label>
      <input type="range" class="rate" min="0.25" max="2.5" step="0.001" value="1"
        data-help="Playback speed of the video itself, continuously variable — 1.037 is a real setting, not rounded to a preset. YouTube tabs only." />
      <span class="val ratev">1.000</span>
      <span class="btns">
        <button class="rate1" data-help="Snap the speed back to normal.">1.0</button>
        <button class="pitch" aria-pressed="true"
          data-help="On: speed changes without changing pitch (time-stretch). Off: pitch rides with speed, the way tape behaves.">keep pitch</button>
      </span>
    </div>
    <div class="row seek-row">
      <label>pos</label>
      <input type="range" class="seek" min="0" max="1000" step="1" value="0"
        data-help="Scrub the video. YouTube tabs only." />
      <span class="val time">--:--</span>
      <span class="btns">
        <button class="play" data-help="Resume this video.">play</button>
        <button class="pause" data-help="Pause this video. It stays in the mixer — the channel is not removed.">pause</button>
      </span>
    </div>`;

  const q = (s) => el.querySelector(s);
  const parts = {
    title: q('.deck__title'), tag: q('.deck__tag'), meter: q('.deck__meter'),
    x: q('.deck__x'),
    level: q('.level'), lvlv: q('.lvlv'), mute: q('.mute'), solo: q('.solo'),
    pan: q('.pan'), panv: q('.panv'), pancenter: q('.pancenter'), panRow: q('.pan-row'),
    rate: q('.rate'), ratev: q('.ratev'), rate1: q('.rate1'), pitch: q('.pitch'),
    seek: q('.seek'), time: q('.time'), play: q('.play'), pause: q('.pause'),
    rateRow: q('.rate-row'), seekRow: q('.seek-row'),
    duration: 0, isYt,
  };

  if (!isYt) {
    // Rate, seek and transport come from the content script, which is YouTube-only.
    for (const row of [parts.rateRow, parts.seekRow]) {
      row.classList.add('idle');
      row.querySelectorAll('input,button').forEach((n) => (n.disabled = true));
    }
  }

  [parts.level, parts.pan, parts.rate, parts.seek].forEach(trackDrag);

  parts.level.addEventListener('input', () => {
    const v = Number(parts.level.value);
    parts.lvlv.textContent = v.toFixed(2);
    setGain(tabId, v);
  });

  parts.pan.addEventListener('input', () => {
    const v = Number(parts.pan.value);
    parts.panv.textContent = fmtPan(v);
    setPan(tabId, v);
  });
  parts.pancenter.addEventListener('click', () => {
    parts.pan.value = '0';
    parts.panv.textContent = 'C';
    setPan(tabId, 0);
  });

  // Mute and solo are mixer-wide state, so the offscreen graph owns them; the
  // panel only sends intent and reflects whatever comes back.
  parts.mute.addEventListener('click', () => setMute(tabId));
  // Shift-click builds a multi-channel solo instead of replacing it.
  parts.solo.addEventListener('click', (e) => setSolo(tabId, undefined, !e.shiftKey));

  parts.x.addEventListener('click', async () => {
    await dropChannel(tabId);
    refresh();
  });

  const applyRate = () => {
    const v = Number(parts.rate.value);
    parts.ratev.textContent = v.toFixed(3);
    toContent(tabId, {
      type: 'SET_RATE',
      rate: v,
      preservesPitch: parts.pitch.getAttribute('aria-pressed') === 'true',
    });
  };
  parts.rate.addEventListener('input', applyRate);
  parts.rate1.addEventListener('click', () => { parts.rate.value = '1'; applyRate(); });
  parts.pitch.addEventListener('click', () => {
    const on = parts.pitch.getAttribute('aria-pressed') !== 'true';
    parts.pitch.setAttribute('aria-pressed', String(on));
    applyRate();
  });

  parts.seek.addEventListener('change', () => {
    if (!parts.duration) return;
    toContent(tabId, {
      type: 'SEEK', absolute: (Number(parts.seek.value) / 1000) * parts.duration,
    });
  });
  parts.play.addEventListener('click', () => toContent(tabId, { type: 'PLAY' }));
  parts.pause.addEventListener('click', () => toContent(tabId, { type: 'PAUSE' }));

  decks.set(tabId, { el, parts });
  document.getElementById('decks').appendChild(el);
  return decks.get(tabId);
}

async function refresh() {
  const st = await getState();
  const fresh = !!(st && st.ok && Array.isArray(st.channels));
  if (fresh) lastChannels = st.channels;
  const channels = fresh ? st.channels : lastChannels;

  const lv = await getLevels();
  const levelBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.db]));

  // Tabs are consulted only for titles and to notice one that has closed — never to
  // decide what belongs in the mixer.
  let tabById = null;
  try {
    tabById = new Map((await listTabs()).map((t) => [t.id, t]));
  } catch {
    tabById = null; // a failed query must not be read as "every tab closed"
  }

  // A closed tab's capture is dead, so retire the channel with it. Only act when the
  // tab list is trustworthy AND the channel list is fresh.
  if (fresh && tabById) {
    for (const ch of channels) {
      if (!ch.synthetic && !tabById.has(ch.tabId)) dropChannel(ch.tabId);
    }
  }

  const live = channels.filter(
    (ch) => ch.synthetic || !tabById || tabById.has(ch.tabId),
  );

  for (const [tabId, d] of decks) {
    if (!live.some((c) => c.tabId === tabId)) { d.el.remove(); decks.delete(tabId); }
  }

  for (const ch of live) {
    const tab = tabById ? tabById.get(ch.tabId) : null;
    const isYt = tab ? tab.url.includes('youtube.com/watch') : false;
    const d = decks.get(ch.tabId) || buildDeck(ch.tabId, isYt);
    const p = d.parts;

    p.title.textContent = (tab && tab.title) || ch.title || 'tab ' + ch.tabId;
    const dead = ch.live && ch.live !== 'live';
    p.tag.textContent = ch.synthetic
      ? 'test'
      : dead
        ? 'stream ended'
        : tab && tab.audible
          ? 'captured'
          : 'paused';
    p.meter.textContent = fmtDb(levelBy.get(ch.tabId)) + ' dB';

    p.mute.setAttribute('aria-pressed', String(!!ch.muted));
    p.solo.setAttribute('aria-pressed', String(!!ch.soloed));
    if (dragging !== p.level) {
      p.level.value = String(ch.level);
      p.lvlv.textContent = Number(ch.level).toFixed(2);
    }
    if (dragging !== p.pan) {
      p.pan.value = String(ch.pan);
      p.panv.textContent = fmtPan(ch.pan);
    }

    if (p.isYt) {
      const info = await toContent(ch.tabId, { type: 'INFO' });
      if (info && info.ok) {
        p.duration = info.duration || 0;
        if (dragging !== p.rate) {
          p.rate.value = String(info.playbackRate);
          p.ratev.textContent = Number(info.playbackRate).toFixed(3);
        }
        p.pitch.setAttribute('aria-pressed', String(!!info.preservesPitch));
        if (dragging !== p.seek && p.duration) {
          p.seek.value = String(Math.round((info.currentTime / p.duration) * 1000));
        }
        p.time.textContent = info.isAd
          ? 'ad…'
          : `${fmtTime(info.currentTime)}/${fmtTime(info.duration)}`;
        if (info.isAd) p.tag.textContent = 'ad playing';
      }
    }
  }

  document.getElementById('decks-empty').style.display = live.length ? 'none' : '';
}

// ---------------------------------------------------------------- tape ui

function buildTape() {
  const el = document.getElementById('tape');
  el.innerHTML = `
    <div class="row">
      <label>engage</label>
      <span class="btns">
        <button id="t-thru" aria-pressed="true"
          data-help="Audio passes straight through with no delay. The tape keeps recording underneath, so switching to it is seamless.">thru</button>
        <button id="t-tape" aria-pressed="false"
          data-help="Play from the tape head instead of live. It sits a quarter second behind, which is the room you have to scrub back into.">tape</button>
        <button id="t-rev" data-help="Play the tape backwards at normal speed.">reverse</button>
        <button id="t-stop" data-help="Halt the tape head. Sources keep playing underneath; the tape simply stops moving.">stop</button>
        <button id="t-play" data-help="Return the tape to normal forward speed.">1.0</button>
      </span>
      <span></span><span></span>
    </div>
    <div class="row">
      <label>speed</label>
      <input type="range" id="t-rate" min="-2" max="2" step="0.001" value="1"
        data-help="Tape speed, continuously variable. Negative is reverse, zero is a dead stop. Held above 1 it will catch up to live and stay there — you cannot play faster than the tabs are recording." />
      <span class="val" id="t-ratev">1.000</span>
      <span class="btns"><button id="t-interp" aria-pressed="false"
        data-help="Interpolation quality for off-speed playback. Cubic is smoother and costs slightly more CPU; the difference shows most at odd speeds.">cubic</button></span>
    </div>
    <div class="row">
      <label>shuttle</label>
      <span class="btns">
        <button id="t-rew" data-help="Hold to run backwards at 4x. Release and it resumes normal speed where it landed, like a real transport.">&#9664;&#9664; rew</button>
        <button id="t-ff" data-help="Hold to run forwards at 4x. It will reach live and stop there.">ff &#9654;&#9654;</button>
        <button id="t-live" data-help="Jump the tape head back to the present without changing speed.">to live</button>
      </span>
      <span></span><span></span>
    </div>
    <div class="row">
      <label>stutter</label>
      <span class="btns">
        <button data-stut="0.06" data-help="Hold to loop the last 60ms. Release and it snaps back to live.">60ms</button>
        <button data-stut="0.125" data-help="Hold to loop the last 125ms. Release and it snaps back to live.">125ms</button>
        <button data-stut="0.25" data-help="Hold to loop the last 250ms. Release and it snaps back to live.">250ms</button>
        <button data-stut="0.5" data-help="Hold to loop the last 500ms. Release and it snaps back to live.">500ms</button>
      </span>
      <span></span><span></span>
    </div>
    <div class="row">
      <label>loop</label>
      <span class="btns">
        <button data-loop="1" data-help="Grab the last second and repeat it until you press off.">1s</button>
        <button data-loop="2" data-help="Grab the last two seconds and repeat them until you press off.">2s</button>
        <button data-loop="4" data-help="Grab the last four seconds and repeat them until you press off.">4s</button>
        <button data-loop="8" data-help="Grab the last eight seconds and repeat them until you press off.">8s</button>
        <button id="t-loopoff" data-help="Stop looping and carry on from where the tape is.">off</button>
      </span>
      <span></span><span></span>
    </div>
    <p class="hint" id="t-state"
      data-help="Tape mode, interpolation, how far behind live the tape head is, and how much of the 60 second buffer has been filled."></p>`;

  const rate = el.querySelector('#t-rate');
  const ratev = el.querySelector('#t-ratev');
  trackDrag(rate);
  const setRate = (v, glide) => {
    rate.value = String(v);
    ratev.textContent = Number(v).toFixed(3);
    tapeSet({ rate: Number(v), glide });
  };
  rate.addEventListener('input', () => setRate(rate.value, 0.01));

  const mode = (m) => {
    el.querySelector('#t-thru').setAttribute('aria-pressed', String(m === 'thru'));
    el.querySelector('#t-tape').setAttribute('aria-pressed', String(m === 'tape'));
    tapeSet({ mode: m });
  };
  el.querySelector('#t-thru').addEventListener('click', () => mode('thru'));
  el.querySelector('#t-tape').addEventListener('click', () => mode('tape'));

  // These only mean anything with the tape engaged, so engage it for them.
  el.querySelector('#t-rev').addEventListener('click', () => { mode('tape'); setRate(-1, 0.02); });
  el.querySelector('#t-stop').addEventListener('click', () => { mode('tape'); setRate(0, 0.02); });
  el.querySelector('#t-play').addEventListener('click', () => { mode('tape'); setRate(1, 0.05); });

  el.querySelectorAll('[data-loop]').forEach((b) =>
    b.addEventListener('click', () => {
      mode('tape');
      tapeCmd('loopSecondsBack', Number(b.dataset.loop));
    }));
  el.querySelector('#t-loopoff').addEventListener('click', () => tapeSet({ loopEnabled: false }));

  // Shuttle and stutter are momentary: held down they act, released they restore.
  const shuttle = (btn, rate) => {
    const start = () => { mode('tape'); tapeSet({ rate, glide: 0.02 }); };
    const stop = () => tapeSet({ rate: 1, glide: 0.06 });
    btn.addEventListener('pointerdown', start);
    btn.addEventListener('pointerup', stop);
    btn.addEventListener('pointerleave', stop);
    btn.addEventListener('pointercancel', stop);
  };
  shuttle(el.querySelector('#t-rew'), -4);
  shuttle(el.querySelector('#t-ff'), 4);
  el.querySelector('#t-live').addEventListener('click', () => tapeCmd('toLive'));

  el.querySelectorAll('[data-stut]').forEach((b) => {
    const seconds = Number(b.dataset.stut);
    const on = () => {
      mode('tape');
      toOffscreen({ type: 'TAPE_CMD', cmd: 'stutter', on: true, seconds });
      b.setAttribute('aria-pressed', 'true');
    };
    const off = () => {
      toOffscreen({ type: 'TAPE_CMD', cmd: 'stutter', on: false });
      b.setAttribute('aria-pressed', 'false');
    };
    b.addEventListener('pointerdown', on);
    b.addEventListener('pointerup', off);
    b.addEventListener('pointerleave', off);
    b.addEventListener('pointercancel', off);
  });

  const interp = el.querySelector('#t-interp');
  interp.addEventListener('click', () => {
    const cubic = interp.getAttribute('aria-pressed') !== 'true';
    interp.setAttribute('aria-pressed', String(cubic));
    tapeSet({ interp: cubic ? 'cubic' : 'linear' });
  });

  return { rate, ratev, state: el.querySelector('#t-state') };
}

let tapeUi = null;
async function refreshTape() {
  const q = await tapeQuery();
  const ready = !!(q && q.ok);

  // Don't let the tape look engaged before there is anything to tape.
  const el = document.getElementById('tape');
  el.classList.toggle('idle', !ready);
  el.querySelectorAll('input,button').forEach((n) => (n.disabled = !ready));
  if (!ready) {
    el.querySelectorAll('[aria-pressed]').forEach((n) =>
      n.setAttribute('aria-pressed', String(n.id === 't-thru')));
    tapeUi.state.textContent = 'Tape idle — add a channel first.';
    return;
  }

  // Reflect the worklet's actual state — the tape can be driven from the console
  // or by a gesture, so the buttons must follow it rather than only their own clicks.
  el.querySelector('#t-thru').setAttribute('aria-pressed', String(q.mode === 'thru'));
  el.querySelector('#t-tape').setAttribute('aria-pressed', String(q.mode === 'tape'));
  el.querySelector('#t-interp').setAttribute('aria-pressed', String(q.interp === 'cubic'));

  if (dragging !== tapeUi.rate) {
    tapeUi.rate.value = String(q.rate);
    tapeUi.ratev.textContent = Number(q.rate).toFixed(3);
  }
  tapeUi.state.textContent =
    `${q.mode} · ${q.interp} · ${q.behindLiveSec.toFixed(2)}s behind live · ` +
    `${q.secondsRecorded.toFixed(0)}/${q.bufferSeconds}s recorded` +
    (q.loopEnabled ? ` · loop ${q.loopLenSec.toFixed(2)}s` : '');
}

// ---------------------------------------------------------------- help switch

function initHelp() {
  const btn = document.getElementById('help-switch');
  const tip = document.getElementById('help-tip');
  let on = localStorage.getItem('ym-help') === '1';

  const apply = () => {
    btn.setAttribute('aria-pressed', String(on));
    document.body.classList.toggle('help-on', on);
    if (!on) tip.classList.remove('on');
  };

  btn.addEventListener('click', () => {
    on = !on;
    localStorage.setItem('ym-help', on ? '1' : '0');
    apply();
  });

  const show = (target) => {
    if (!on) return;
    const el = target && target.closest && target.closest('[data-help]');
    if (!el) { tip.classList.remove('on'); return; }
    tip.textContent = el.getAttribute('data-help');
    tip.classList.add('on');

    // Sit under the element, nudged back inside the viewport if it would overflow.
    const r = el.getBoundingClientRect();
    const t = tip.getBoundingClientRect();
    let left = r.left;
    let top = r.bottom + 6;
    if (left + t.width > window.innerWidth - 8) left = window.innerWidth - t.width - 8;
    if (top + t.height > window.innerHeight - 8) top = r.top - t.height - 6;
    tip.style.left = Math.max(8, left) + 'px';
    tip.style.top = Math.max(8, top) + 'px';
  };

  // Delegated, so controls built later (decks appear and disappear) are covered
  // without rebinding. focusin as well as hover keeps it reachable by keyboard.
  document.addEventListener('pointerover', (e) => show(e.target));
  document.addEventListener('focusin', (e) => show(e.target));
  document.addEventListener('pointerleave', () => tip.classList.remove('on'), true);

  apply();
}

// ---------------------------------------------------------------- boot

tapeUi = buildTape();
initHelp();
refresh();
refreshTape();
setInterval(refresh, 700);
setInterval(refreshTape, 500);

// Kept for console use and the CDP drivers.
Object.assign(window, {
  mixerTabs: listTabs, mixerAdd: addChannel, mixerState: getState,
  mixerLevels: getLevels, mixerGain: setGain, mixerDrop: dropChannel,
  mixerMute: setMute, mixerSolo: setSolo, mixerPan: setPan,
  mixerRefresh: refresh,
  tapeSet, tapeCmd, tapeQuery,
  tapeOn: () => tapeSet({ mode: 'tape' }),
  tapeThru: () => tapeSet({ mode: 'thru' }),
  tapeRate: (rate, glide) => tapeSet({ rate, glide }),
  tapeLoop: (seconds) => tapeCmd('loopSecondsBack', seconds),
  tapeLoopOff: () => tapeSet({ loopEnabled: false }),
  tapeInterp: (interp) => tapeSet({ interp }),
  tapeStutter: (on, seconds) => toOffscreen({ type: 'TAPE_CMD', cmd: 'stutter', on, seconds }),
  tapeToLive: () => tapeCmd('toLive'),
  testTone: (on, hz) => toOffscreen({ type: 'TEST_TONE', on, hz }),
  probe: () => toOffscreen({ type: 'PROBE' }),
  probeTones: (hz) => toOffscreen({ type: 'PROBE_TONES', hz }),
  deckInfo: (tabId) => toContent(tabId, { type: 'INFO' }),
  deckRate: (tabId, rate, preservesPitch) =>
    toContent(tabId, { type: 'SET_RATE', rate, preservesPitch }),
  deckVolume: (tabId, volume, muted) => toContent(tabId, { type: 'SET_VOLUME', volume, muted }),
  deckSeek: (tabId, absolute, delta) => toContent(tabId, { type: 'SEEK', absolute, delta }),
  deckPlay: (tabId) => toContent(tabId, { type: 'PLAY' }),
  deckPause: (tabId) => toContent(tabId, { type: 'PAUSE' }),
  mixerReady: true,
});
