// Action click -> get a stream id for the active tab -> hand it to the offscreen doc.
// getMediaStreamId requires the extension to have been invoked on the target tab,
// which the action click satisfies. Adding a second tab = click the action on it.

const OFFSCREEN_URL = 'offscreen.html';

async function hasOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });
  return contexts.length > 0;
}

let creating = null;
async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  if (creating) return creating;
  creating = chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: ['USER_MEDIA'],
    justification: 'Mix captured tab audio through a Web Audio graph.',
  });
  try {
    await creating;
  } finally {
    creating = null;
  }
}

// createDocument resolves before offscreen.js has necessarily registered its
// listener, so retry until there is a receiver.
async function sendToOffscreen(msg, tries = 20) {
  for (let i = 0; i < tries; i++) {
    try {
      return await chrome.runtime.sendMessage({ target: 'offscreen', ...msg });
    } catch (e) {
      if (i === tries - 1) throw e;
      await new Promise((r) => setTimeout(r, 50));
    }
  }
}

// Show the panel, reusing the existing one rather than stacking up duplicates.
// Querying by URL rather than remembering a tab id means there is no stale id to
// invalidate when the user closes it — single instance by construction.
//
// Note this is also the only reliable way to get an extension page open under
// automation: top-level navigation to chrome-extension:// is blocked, but an
// extension-initiated tabs.create is not.
async function openOrFocusPanel() {
  const url = chrome.runtime.getURL('panel.html');
  const [existing] = await chrome.tabs.query({ url });
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
    return existing;
  }
  return chrome.tabs.create({ url });
}

chrome.runtime.onInstalled.addListener(async () => {
  await openOrFocusPanel();
  // Declared content scripts only run on navigation, so inject into YouTube tabs
  // that were already open when the extension loaded.
  const tabs = await chrome.tabs.query({ url: '*://*.youtube.com/*' });
  for (const t of tabs) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: t.id }, files: ['content.js'] });
    } catch (e) {
      console.warn('[mixer] inject failed', t.id, e.message);
    }
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await ensureOffscreen();

    const streamId = await chrome.tabCapture.getMediaStreamId({
      targetTabId: tab.id,
    });

    const res = await sendToOffscreen({
      type: 'ADD_CHANNEL',
      streamId,
      tabId: tab.id,
      title: tab.title || String(tab.id),
    });

    console.log('[mixer] ADD_CHANNEL result', res);

    // Surface the mixer once the channel exists, so the click that adds a tab is
    // also the click that gets you back to the panel. The capture has to happen
    // first: this click is the only thing granting tabCapture invocation for this
    // tab, and focusing another tab first would spend it.
    await openOrFocusPanel();
  } catch (e) {
    console.error('[mixer] add channel failed', e);
    // Still show the panel — it explains what went wrong better than a silent click.
    await openOrFocusPanel();
  }
});

globalThis.mixerOpenPanel = openOrFocusPanel;

// Console helpers for the spike: run these from the service worker devtools.
globalThis.mixerState = () => sendToOffscreen({ type: 'GET_STATE' });
globalThis.mixerLevels = () => sendToOffscreen({ type: 'GET_LEVELS' });
globalThis.mixerGain = (tabId, value) =>
  sendToOffscreen({ type: 'SET_GAIN', tabId, value });
globalThis.mixerDrop = (tabId) => sendToOffscreen({ type: 'DROP_CHANNEL', tabId });

// Same path as the action click, callable without the toolbar button so the
// spike can be driven over CDP.
globalThis.mixerAdd = async (tabId) => {
  await ensureOffscreen();
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  return sendToOffscreen({ type: 'ADD_CHANNEL', streamId, tabId, title: 'tab ' + tabId });
};

globalThis.mixerTabs = async () => {
  const tabs = await chrome.tabs.query({});
  return tabs.map((t) => ({ id: t.id, audible: t.audible, url: (t.url || '').slice(0, 60) }));
};
