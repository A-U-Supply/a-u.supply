// Content script on youtube.com: direct control of the native <video>.
//
// This is where continuous varispeed comes from. YouTube's own UI offers discrete
// rates, but the underlying HTMLMediaElement accepts any float, so `playbackRate`
// takes 1.037 exactly. `preservesPitch = false` makes pitch ride with speed, which
// is tape behaviour; true time-stretches instead.
//
// YouTube is an SPA and swaps the media element on navigation, so never cache it.

function video() {
  // The main player video; ads and previews can add others, so prefer the largest.
  const vids = [...document.querySelectorAll('video')];
  if (!vids.length) return null;
  return vids.sort((a, b) => b.clientWidth * b.clientHeight - a.clientWidth * a.clientHeight)[0];
}

// Where the player sits within the tab, as fractions of the viewport.
//
// Video mode crops the captured tab down to just this rectangle. Fractions rather
// than pixels because the capture is scaled to whatever size we asked for, so pixel
// coordinates would be wrong; fractions survive any scaling.
//
// Fractions of the VIEWPORT, though — not of the captured frame. Those are only the
// same thing when the frame has no padding, so `info()` also reports the viewport
// these were measured against and the panel maps them across. See applyCrop.
//
// Region Capture (CropTarget.fromElement + track.cropTo) is the purpose-built API for
// this and cannot be used: CropTarget is not serialisable through extension messaging
// and arrives as a blank object. A plain rectangle serialises fine.
function cropRect(v) {
  const r = v.getBoundingClientRect();
  const vw = window.innerWidth || 1;
  const vh = window.innerHeight || 1;
  if (!r.width || !r.height) return null;

  // Crop to the PICTURE, not the element. The <video> box is often larger than the
  // image inside it — the browser letterboxes when the video's aspect does not match
  // the element's — and on light-theme YouTube the page behind is white, so cropping
  // to the element box catches white strips above and below. Same maths as
  // `object-fit: contain`.
  //
  // With no videoWidth there is no picture to crop to, only the element box, and
  // cropping to that is the pre-0.0.6 bug — white strips and all. That happens
  // whenever metadata has not loaded yet, and whenever an ad <video> wins the
  // largest-element sort. Report nothing instead: the panel keeps the last good
  // rectangle, which is a far better guess than the element box.
  const iw = v.videoWidth;
  const ih = v.videoHeight;
  if (!iw || !ih) return null;

  let { left, top, width, height } = r;
  const scale = Math.min(width / iw, height / ih);
  const cw = iw * scale;
  const chh = ih * scale;
  left += (width - cw) / 2;
  top += (height - chh) / 2;
  width = cw;
  height = chh;

  // And a hair in from that, so rounding between the page and the scaled capture can
  // never reach the page behind. Proportional, not a flat pixel: at the default low
  // quality the capture is 426px wide, so one CSS px of a 1500px viewport is about a
  // quarter of a captured pixel and guards nothing.
  const insetX = Math.max(1, width * 0.004);
  const insetY = Math.max(1, height * 0.004);
  if (width > insetX * 4 && height > insetY * 4) {
    left += insetX; top += insetY; width -= insetX * 2; height -= insetY * 2;
  }

  return {
    x: Math.max(0, left / vw),
    y: Math.max(0, top / vh),
    w: Math.min(1, width / vw),
    h: Math.min(1, height / vh),
  };
}

function info(v) {
  return {
    ok: true,
    crop: cropRect(v),
    // The viewport `crop` is a fraction of. The captured frame is this viewport
    // fitted into a 16:9 box, so unless the window happens to be 16:9 the frame
    // carries padding and these two coordinate spaces are not the same one.
    vw: window.innerWidth,
    vh: window.innerHeight,
    playbackRate: v.playbackRate,
    preservesPitch: v.preservesPitch,
    volume: v.volume,
    muted: v.muted,
    currentTime: v.currentTime,
    duration: Number.isFinite(v.duration) ? v.duration : null,
    paused: v.paused,
    readyState: v.readyState,
    videoId: new URLSearchParams(location.search).get('v'),
    // A pre-roll ad puts a different <video> in front of the content one; callers
    // should not trust rate/seek while this is true.
    isAd: !!document.querySelector('.ad-showing, .ytp-ad-player-overlay'),
    title: document.title,
  };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'content') return false;

  const v = video();
  if (!v) {
    sendResponse({ ok: false, reason: 'no video element', href: location.href });
    return true;
  }

  try {
    switch (msg.type) {
      case 'INFO':
        break;

      case 'SET_RATE':
        // preservesPitch first, so the rate change lands with the intended mode.
        if (msg.preservesPitch !== undefined) v.preservesPitch = !!msg.preservesPitch;
        v.playbackRate = msg.rate;
        break;

      case 'SET_VOLUME':
        if (msg.volume !== undefined) v.volume = Math.max(0, Math.min(1, msg.volume));
        if (msg.muted !== undefined) v.muted = !!msg.muted;
        break;

      case 'SEEK':
        if (msg.absolute !== undefined) v.currentTime = msg.absolute;
        else if (msg.delta !== undefined) v.currentTime = v.currentTime + msg.delta;
        break;

      case 'PLAY':
        v.play();
        break;

      case 'PAUSE':
        v.pause();
        break;

      default:
        sendResponse({ ok: false, reason: 'unknown ' + msg.type });
        return true;
    }
    sendResponse(info(v));
  } catch (e) {
    sendResponse({ ok: false, error: String((e && e.message) || e) });
  }
  return true;
});
