// The recorder: a take of the finished mix.
//
// It taps the LAST node before the speakers, after the tape and after the DC blocker,
// so what lands in the file is exactly what you heard — a reverse pass, a stutter, a
// speed ride, all baked in. Brendan chose that over the raw pre-tape blend: the
// recording is the performance, not the ingredients.
//
// WebM/Opus, because Chrome encodes it itself. That matters more than the format war
// suggests: an encoder in the browser means a long take costs essentially no memory and
// there is no length cap to enforce or warn about. WAV would have to be held whole in
// memory and written at the end, which buys Logic a drag-and-drop and buys us a hard
// twenty-minute ceiling. If converting turns out to be the annoying part, a WAV toggle
// is a later decision made with evidence.
//
// Nothing here touches the audible path. The recorder is a second destination hung off
// the same node, so starting and stopping a take is inaudible — which is the whole
// point of being able to hit record in the middle of something good.
//
// SCOPED, for the reason snapshot.js is: these are classic scripts sharing one global
// scope, and a repeated top-level name is a SyntaxError that silently kills the file.
(() => {

const MIME = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/ogg;codecs=opus',
].find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m)) || '';

let recorder = null;
let chunks = [];
let dest = null;
let startedAt = 0;
let tick = null;
let lastTake = null; // { name, bytes, seconds }

const recording = () => !!recorder && recorder.state === 'recording';

const fmtDur = (s) => {
  const t = Math.max(0, Math.floor(s));
  const m = Math.floor(t / 60);
  return `${m}:${String(t % 60).padStart(2, '0')}`;
};

const fmtBytes = (b) =>
  b > 1024 * 1024 ? (b / 1024 / 1024).toFixed(1) + ' MB' : Math.round(b / 1024) + ' kB';

function takeName() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `quodlibet-take-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.webm`;
}

async function startRecording() {
  if (recording()) return { ok: false, reason: 'already recording' };
  if (!MIME) return fail('this Chrome cannot record audio — no supported format');

  // Ask about CHANNELS, not about the graph. The first version of this guard tested
  // `Mixer.outputNode()` — but ensureAudio() builds the whole chain whether or not
  // anything is feeding it, so an empty mixer passed the check and recorded a
  // beautifully encoded ten minutes of silence. Finding that out at the end of a take
  // is the worst possible moment to find it out.
  const st = Mixer.state();
  if (!st.channels || !st.channels.length)
    return fail('nothing to record yet — add a channel first');

  await Mixer.ensureAudio().catch(() => {});
  const out = Mixer.outputNode();
  const ctx = Mixer.context();
  if (!out || !ctx) return fail('the audio graph is not running');

  dest = ctx.createMediaStreamDestination();
  out.connect(dest); // a tap; the speakers keep their own connection

  chunks = [];
  recorder = new MediaRecorder(dest.stream, { mimeType: MIME, audioBitsPerSecond: 192000 });
  recorder.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
  // A timeslice rather than one blob at the end: the recorder hands over a chunk a
  // second, so the elapsed size on screen is real and a crashed tab loses a second
  // rather than the take.
  recorder.start(1000);
  startedAt = Date.now();

  tick = setInterval(paint, 500);
  paint();
  return { ok: true, mimeType: MIME };
}

function stopRecording() {
  if (!recorder) return Promise.resolve({ ok: false, reason: 'not recording' });
  return new Promise((resolve) => {
    const r = recorder;
    r.onstop = () => {
      const seconds = (Date.now() - startedAt) / 1000;
      const blob = new Blob(chunks, { type: MIME });
      try { Mixer.outputNode()?.disconnect(dest); } catch {}
      dest = null; recorder = null; chunks = [];
      clearInterval(tick); tick = null;

      const name = takeName();
      lastTake = { name, bytes: blob.size, seconds };
      download(blob, name);
      setStatus(`Saved ${name} — ${fmtDur(seconds)}, ${fmtBytes(blob.size)}.`);
      paintButtons();
      resolve({ ok: true, name, bytes: blob.size, seconds });
    };
    r.stop();
  });
}

const toggleRecording = () => (recording() ? stopRecording() : startRecording());

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

function fail(reason) {
  setStatus(reason);
  return { ok: false, reason };
}

// ---------------------------------------------------------------- ui

function setStatus(text) {
  const el = document.getElementById('rec-status');
  if (el) el.textContent = text || '';
}

// A recording you have forgotten about is the failure mode, so the elapsed time and the
// size are on screen the whole time, in both modes.
function paint() {
  if (!recording()) return;
  const seconds = (Date.now() - startedAt) / 1000;
  const bytes = chunks.reduce((n, c) => n + c.size, 0);
  setStatus(`Recording — ${fmtDur(seconds)}, ${fmtBytes(bytes)}. It stops when you say so.`);
  paintButtons();
}

function paintButtons() {
  const on = recording();
  for (const id of ['rec-toggle', 'video-rec']) {
    const b = document.getElementById(id);
    if (!b) continue;
    b.setAttribute('aria-pressed', String(on));
    b.classList.toggle('rec-on', on);
    b.textContent = on ? (id === 'video-rec' ? '■ stop' : '■ stop recording') : (id === 'video-rec' ? '● rec' : '● record');
  }
}

function initRecord() {
  for (const id of ['rec-toggle', 'video-rec']) {
    const b = document.getElementById(id);
    if (b) b.addEventListener('click', () => toggleRecording());
  }
  paintButtons();
  if (!MIME) setStatus('This Chrome cannot record audio.');
}

Object.assign(window, {
  recStart: startRecording,
  recStop: stopRecording,
  recToggle: toggleRecording,
  recIsRecording: recording,
  recMime: () => MIME,
  recLastTake: () => lastTake,
  recElapsed: () => (recording() ? (Date.now() - startedAt) / 1000 : 0),
  recBytes: () => chunks.reduce((n, c) => n + c.size, 0),
  // The suite needs to stop a take without a file landing in ~/Downloads on every run.
  recSetDownload: (fn) => { download = fn; },
});

initRecord();
})();
