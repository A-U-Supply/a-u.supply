// The mixer's audio graph. Lives in the panel.
//
// It used to live in an offscreen document, messaged over chrome.runtime. That is
// gone: Chrome refuses to capture a tab that already has an active stream ("Cannot
// capture a tab with an active stream"), so video could not be a second capture
// handed to the panel — one capture must carry both, and the only context that can
// show video is the panel. So the panel owns everything.
//
// Consequences, both good: there is no message boundary left to drop a message across
// (which is what emptied the deck list in v0.0.1), and closing the mixer now ends the
// captures, returning the tabs to normal playback.
//
// Graph:  [tab capture] -> gain -> (meter tap) -> pan -> master -> TAPE -> out -> dest

const Mixer = (() => {
  let ctx = null;
  let master = null;
  let masterAnalyser = null; // pre-tape
  // The last node before the speakers. Kept because the recorder taps here: what it
  // writes is what you hear, tape and all, which is what a take is supposed to be.
  let outNode = null;
  let outAnalyser = null; // post-tape
  let outL = null, outR = null; // post-tape, per side
  let tape = null;
  const channels = new Map(); // tabId -> { stream, source, gain, panner, analyser, … }

  const TAPE_SECONDS = 60;
  const TAPE_LATENCY_SEC = 0.25;

  // Tile-sized, not tab-sized. Unconstrained, a captured tab arrives at ~2880x1756 —
  // about 5 megapixels a frame, four of which would melt a laptop mid-performance.
  //
  // Four real videos still made Brendan's machine work hard at 960x540, so LOW is the
  // default and high quality is opt-in. Note our capture is only half the cost: each
  // source tab is also decoding YouTube at full quality, which the panel handles
  // separately by asking the player to drop its own resolution.
  const QUALITY = {
    low: { maxWidth: 426, maxHeight: 240, maxFrameRate: 15 },
    high: { maxWidth: 960, maxHeight: 540, maxFrameRate: 30 },
  };
  let quality = 'low';

  // `ready` rather than `ctx`, because ctx is assigned before the worklet module is
  // awaited — leaving a window where ctx is truthy but every analyser is still null.
  // Reporting guarded on ctx crashed in that window once the panel started calling
  // this directly instead of over a message round-trip.
  let ready = false;
  let initPromise = null;

  function ensureAudio() {
    if (ready) return Promise.resolve(ctx);
    if (initPromise) return initPromise; // concurrent callers must not build twice
    initPromise = buildGraph();
    return initPromise;
  }

  async function buildGraph() {
    ctx = new AudioContext();

    await ctx.audioWorklet.addModule(chrome.runtime.getURL('tape-worklet.js'));

    master = ctx.createGain();
    master.gain.value = 1;

    masterAnalyser = ctx.createAnalyser();
    masterAnalyser.fftSize = 2048;
    master.connect(masterAnalyser); // tap only

    tape = new AudioWorkletNode(ctx, 'tape', {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [2],
      processorOptions: { seconds: TAPE_SECONDS, latencySec: TAPE_LATENCY_SEC },
    });

    outAnalyser = ctx.createAnalyser();
    outAnalyser.fftSize = 2048;

    // An AnalyserNode downmixes to mono, so pan is invisible to it. Split for L/R.
    outL = ctx.createAnalyser(); outL.fftSize = 2048;
    outR = ctx.createAnalyser(); outR.fftSize = 2048;
    const splitter = ctx.createChannelSplitter(2);

    // DC blocker. Belt and braces against anything parking a constant on the output —
    // a frozen tape head did exactly that and buzzed until you left tape mode. The
    // worklet now fades to silence at rest, but nothing downstream should be able to
    // send DC to the speakers regardless of how it got there.
    const dcBlock = (outNode = ctx.createBiquadFilter());
    dcBlock.type = 'highpass';
    dcBlock.frequency.value = 15; // below anything musical, above DC
    dcBlock.Q.value = 0.707;

    master.connect(tape);
    tape.connect(dcBlock);
    // Meter AFTER the filter, so what is measured is what is heard.
    dcBlock.connect(outAnalyser); // tap only
    dcBlock.connect(splitter);
    splitter.connect(outL, 0);
    splitter.connect(outR, 1);
    dcBlock.connect(ctx.destination);

    await ctx.resume();
    ready = true;
    return ctx;
  }

  // Mean sample value. A frozen read head outputs the same sample forever, which is
  // a DC offset — RMS alone can read near-zero if that sample happens to sit near the
  // axis, so measure the offset directly.
  function dcOffset(analyser) {
    const buf = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(buf);
    let sum = 0;
    for (let i = 0; i < buf.length; i++) sum += buf[i];
    return sum / buf.length;
  }

  // RMS in dBFS over one analyser frame. null for digital silence.
  function rmsDb(analyser) {
    const buf = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(buf);
    let sum = 0;
    for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
    const rms = Math.sqrt(sum / buf.length);
    return rms > 0 ? 20 * Math.log10(rms) : null;
  }

  async function addChannel({ streamId, tabId, title }) {
    if (channels.has(tabId)) return { ok: true, already: true, tabId };

    // Legacy mandatory-constraint form is required for chromeMediaSource: 'tab'.
    // Audio AND video in one stream: a tab cannot be captured twice, so this is the
    // only chance to get the picture.
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId } },
      video: { mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId, ...QUALITY[quality] } },
    });

    const c = await ensureAudio();
    const source = c.createMediaStreamSource(stream);
    const gain = c.createGain();
    gain.gain.value = 1;
    const panner = c.createStereoPanner();
    panner.pan.value = 0;
    const analyser = c.createAnalyser();
    analyser.fftSize = 2048;

    // Capturing a tab suppresses its own playback, so this graph is the only path to
    // the speakers — not a duplicate of it.
    source.connect(gain);
    gain.connect(analyser); // metering tap, pre-pan so the meter reads the fader
    gain.connect(panner);
    panner.connect(master);

    // level/muted/soloed are the intent; gain.gain is the computed result.
    channels.set(tabId, {
      stream, source, gain, panner, analyser, title,
      level: 1, muted: false, soloed: false,
      // Until the page-side script reports otherwise, assume there is a picture.
      wantsVideo: true,
    });
    applyGains();
    setVideoEnabled(videoWanted); // respect whatever mode we are in

    return {
      ok: true,
      tabId,
      title,
      channelCount: channels.size,
      sampleRate: c.sampleRate,
      hasVideo: stream.getVideoTracks().length > 0,
      trackSettings: stream.getAudioTracks()[0]?.getSettings?.() ?? null,
    };
  }

  function dropChannel(tabId) {
    const ch = channels.get(tabId);
    if (!ch) return { ok: false, reason: 'no such channel' };
    ch.stream.getTracks().forEach((t) => t.stop());
    try {
      ch.source.disconnect();
      ch.gain.disconnect();
      ch.panner.disconnect();
    } catch {}
    channels.delete(tabId);
    applyGains(); // dropping the soloed channel must un-duck the rest
    return { ok: true, channelCount: channels.size };
  }

  // The title is snapshotted from the tab at capture time, and a tab outlives the
  // video that was in it — autoplay walks on to the next one. Whoever notices the
  // new title says so here, so the record stops describing a video that stopped
  // playing an hour ago.
  function setTitle(tabId, title) {
    const ch = channels.get(tabId);
    if (!ch || !title || ch.title === title) return { ok: false };
    ch.title = title;
    return { ok: true, tabId, title };
  }

  // Solo is a property of the whole mixer, not of one channel, so effective gain is
  // always recomputed across every channel rather than poked per-channel.
  function applyGains() {
    if (!ready) return;
    const anySolo = [...channels.values()].some((c) => c.soloed);
    for (const ch of channels.values()) {
      const target = ch.muted || (anySolo && !ch.soloed) ? 0 : ch.level;
      ch.gain.gain.setTargetAtTime(target, ctx.currentTime, 0.01); // ramp, no click
    }
  }

  function setLevel(tabId, value) {
    const ch = channels.get(tabId);
    if (!ch) return { ok: false, reason: 'no such channel' };
    ch.level = Math.max(0, value);
    applyGains();
    return { ok: true, tabId, level: ch.level };
  }

  function setMute(tabId, muted) {
    const ch = channels.get(tabId);
    if (!ch) return { ok: false, reason: 'no such channel' };
    ch.muted = muted === undefined ? !ch.muted : !!muted;
    applyGains();
    return { ok: true, tabId, muted: ch.muted };
  }

  function setSolo(tabId, soloed, exclusive) {
    const ch = channels.get(tabId);
    if (!ch) return { ok: false, reason: 'no such channel' };
    const next = soloed === undefined ? !ch.soloed : !!soloed;
    // Exclusive by default: soloing one clears the others, which is what a single
    // click on a mixer means. Pass exclusive:false to build a multi-channel solo.
    if (next && exclusive !== false) {
      for (const other of channels.values()) other.soloed = false;
    }
    ch.soloed = next;
    applyGains();
    return {
      ok: true, tabId, soloed: ch.soloed,
      soloing: [...channels.entries()].filter(([, c]) => c.soloed).map(([id]) => id),
    };
  }

  function setPan(tabId, pan) {
    const ch = channels.get(tabId);
    if (!ch) return { ok: false, reason: 'no such channel' };
    const v = Math.max(-1, Math.min(1, pan));
    ch.panner.pan.setTargetAtTime(v, ctx.currentTime, 0.01);
    return { ok: true, tabId, pan: v };
  }

  // ---- video ---------------------------------------------------------------

  // Frames are only wanted in video mode. Disabling the track stops delivery rather
  // than tearing down the capture, so switching modes costs nothing and never risks
  // losing a capture we could not re-acquire while the tab is still captured.
  let videoWanted = false;

  // A channel can also opt out for itself. An audio-only source — SoundCloud,
  // Bandcamp, a podcast page — has a video track carrying the whole webpage, which is
  // both a waste of decode and the thing that was putting Brendan's inbox on screen.
  // The panel draws a waveform for those instead and switches the frames off here, so
  // the page is genuinely not arriving rather than merely hidden by CSS.
  function channelVideoWanted(ch) {
    return videoWanted && ch.wantsVideo !== false;
  }

  function applyVideoEnabled() {
    for (const ch of channels.values()) {
      const on = channelVideoWanted(ch);
      for (const t of ch.stream.getVideoTracks()) t.enabled = on;
    }
  }

  function setVideoEnabled(on) {
    videoWanted = !!on;
    applyVideoEnabled();
    return { ok: true, videoWanted };
  }

  function setChannelVideo(tabId, on) {
    const ch = channels.get(tabId);
    if (!ch) return { ok: false, reason: 'no such channel' };
    if (ch.wantsVideo === !!on) return { ok: true, tabId, wantsVideo: ch.wantsVideo, already: true };
    ch.wantsVideo = !!on;
    applyVideoEnabled();
    return { ok: true, tabId, wantsVideo: ch.wantsVideo };
  }

  // Change capture quality on the live tracks. applyConstraints avoids re-acquiring,
  // which matters because a tab cannot be captured twice — re-acquiring would mean
  // dropping the channel and gapping its audio.
  async function setQuality(next) {
    if (!QUALITY[next]) return { ok: false, reason: 'unknown quality ' + next };
    quality = next;
    const q = QUALITY[next];
    const applied = [];
    for (const [tabId, ch] of channels) {
      for (const t of ch.stream.getVideoTracks ? ch.stream.getVideoTracks() : []) {
        try {
          await t.applyConstraints({
            width: { max: q.maxWidth },
            height: { max: q.maxHeight },
            frameRate: { max: q.maxFrameRate },
          });
          const s = t.getSettings();
          applied.push({ tabId, width: s.width, height: s.height, frameRate: s.frameRate });
        } catch (e) {
          applied.push({ tabId, error: String((e && e.message) || e) });
        }
      }
    }
    return { ok: true, quality, applied };
  }

  const getQuality = () => quality;

  const getStream = (tabId) => {
    const ch = channels.get(tabId);
    return ch ? ch.stream : null;
  };

  // ---- test seams ----------------------------------------------------------

  // A channel fed by an oscillator instead of a captured stream, so pan/mute/solo are
  // testable without the toolbar click tabCapture requires.
  // `withVideo` gives the synthetic channel a real video track, from a canvas rather
  // than a tab. Everything downstream of "this channel has a picture" — attaching the
  // stream, frameSize reading real dimensions, applyCrop mapping against them, the
  // tile choosing picture over waveform — is otherwise unreachable from a test,
  // because the only source of a real one is a toolbar click that cannot be
  // automated. Off by default: a plain testChannel stays exactly what it was.
  async function testChannel({ tabId, hz = 440, withVideo = false }) {
    const c = await ensureAudio();
    if (channels.has(tabId)) return { ok: true, already: true, tabId };
    const osc = c.createOscillator();
    osc.frequency.value = hz;
    const gain = c.createGain();
    const panner = c.createStereoPanner();
    const analyser = c.createAnalyser();
    analyser.fftSize = 2048;
    osc.connect(gain);
    gain.connect(analyser);
    gain.connect(panner);
    panner.connect(master);
    osc.start();

    let stream = { getTracks: () => [], getAudioTracks: () => [], getVideoTracks: () => [] };
    if (withVideo) {
      const cv = document.createElement('canvas');
      cv.width = 640; cv.height = 360;
      const g2 = cv.getContext('2d');
      g2.fillStyle = '#333'; g2.fillRect(0, 0, cv.width, cv.height);
      // A real MediaStream, because the tile assigns it to video.srcObject and only a
      // MediaStream is allowed there. The audio track comes from this channel's own
      // gain so the stream reads as live, the way a capture does.
      const dest = c.createMediaStreamDestination();
      gain.connect(dest);
      stream = new MediaStream([
        ...cv.captureStream(5).getVideoTracks(),
        ...dest.stream.getAudioTracks(),
      ]);
      stream.__canvas = cv; // keep the frame source alive with the stream
    }

    channels.set(tabId, {
      stream,
      source: osc, gain, panner, analyser, title: 'test ' + hz + 'Hz',
      level: 1, muted: false, soloed: false, synthetic: true, wantsVideo: true,
    });
    applyGains();
    setVideoEnabled(videoWanted);
    return { ok: true, tabId, hz, channelCount: channels.size, withVideo: !!withVideo };
  }

  let testOsc = null;
  async function testTone({ on, hz = 440 }) {
    const c = await ensureAudio();
    if (on === false) {
      if (testOsc) {
        try { testOsc.stop(); testOsc.disconnect(); } catch {}
        testOsc = null;
      }
      return { ok: true, tone: 'off' };
    }
    if (testOsc) { try { testOsc.stop(); testOsc.disconnect(); } catch {} }
    testOsc = c.createOscillator();
    const g = c.createGain();
    g.gain.value = 0.3;
    testOsc.frequency.value = hz;
    testOsc.connect(g).connect(master);
    testOsc.start();
    return { ok: true, tone: 'on', hz, sampleRate: c.sampleRate };
  }

  // ---- reporting -----------------------------------------------------------

  function state() {
    return {
      ok: true,
      contextState: ctx ? ctx.state : 'none',
      sampleRate: ctx ? ctx.sampleRate : null,
      tapeReady: !!tape,
      videoWanted,
      quality,
      channels: [...channels.entries()].map(([tabId, ch]) => ({
        tabId,
        title: ch.title,
        level: ch.level,
        muted: ch.muted,
        soloed: ch.soloed,
        synthetic: !!ch.synthetic,
        hasVideo: ch.stream.getVideoTracks().length > 0,
        wantsVideo: ch.wantsVideo !== false,
        pan: ch.panner.pan.value,
        gain: ch.gain.gain.value, // computed from level/mute/solo
        live: ch.stream.getAudioTracks()[0]?.readyState ?? 'unknown',
      })),
    };
  }

  function levels() {
    if (!ready) return { ok: false, reason: 'no context' };
    return {
      ok: true,
      masterPreTape: rmsDb(masterAnalyser),
      out: rmsDb(outAnalyser),
      outL: rmsDb(outL),
      outR: rmsDb(outR),
      channels: [...channels.entries()].map(([tabId, ch]) => ({
        tabId,
        title: (ch.title || '').slice(0, 40),
        gain: ch.gain.gain.value,
        db: rmsDb(ch.analyser),
      })),
    };
  }

  // Time-domain frame for one channel, for the audio-only visualiser.
  function waveform(tabId, points = 128) {
    const ch = channels.get(tabId);
    if (!ch) return null;
    const buf = new Float32Array(ch.analyser.fftSize);
    ch.analyser.getFloatTimeDomainData(buf);
    const step = Math.floor(buf.length / points);
    const out = new Array(points);
    for (let i = 0; i < points; i++) {
      let peak = 0;
      for (let k = 0; k < step; k++) {
        const v = Math.abs(buf[i * step + k]);
        if (v > peak) peak = v;
      }
      out[i] = peak;
    }
    return out;
  }

  // Dominant frequency by parabolic-interpolated peak bin. Used to prove varispeed.
  function peakHz(analyser) {
    const bins = new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatFrequencyData(bins);
    let peak = 1;
    for (let i = 2; i < bins.length - 1; i++) if (bins[i] > bins[peak]) peak = i;
    const binHz = ctx.sampleRate / analyser.fftSize;
    const [l, c, r] = [bins[peak - 1], bins[peak], bins[peak + 1]];
    const denom = l - 2 * c + r;
    const shift = denom !== 0 ? (0.5 * (l - r)) / denom : 0;
    return (peak + shift) * binHz;
  }

  // Independent of the FFT: count zero crossings over one time-domain frame.
  function zeroCrossHz(analyser) {
    const buf = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(buf);
    let crossings = 0;
    for (let i = 1; i < buf.length; i++) {
      if ((buf[i - 1] < 0 && buf[i] >= 0) || (buf[i - 1] >= 0 && buf[i] < 0)) crossings++;
    }
    return (crossings / 2) * (ctx.sampleRate / buf.length);
  }

  // dBFS at a specific frequency — used to measure interpolation imaging.
  function dbAt(analyser, hz) {
    const bins = new Float32Array(analyser.frequencyBinCount);
    analyser.getFloatFrequencyData(bins);
    const binHz = ctx.sampleRate / analyser.fftSize;
    const c = Math.round(hz / binHz);
    let peak = -Infinity;
    for (let i = Math.max(0, c - 1); i <= c + 1 && i < bins.length; i++) {
      if (bins[i] > peak) peak = bins[i];
    }
    return Number.isFinite(peak) ? peak : null;
  }

  const probeTones = (hzList) => (!ready
    ? { ok: false, reason: 'no context' }
    : { ok: true, out: hzList.map((hz) => ({ hz, db: dbAt(outAnalyser, hz) })) });

  const probe = () => (!ready ? { ok: false, reason: 'no context' } : {
    ok: true,
    inHz: peakHz(masterAnalyser),
    outHz: peakHz(outAnalyser),
    inZcHz: zeroCrossHz(masterAnalyser),
    outZcHz: zeroCrossHz(outAnalyser),
    inDb: rmsDb(masterAnalyser),
    outDb: rmsDb(outAnalyser),
    outDc: dcOffset(outAnalyser),
  });

  // ---- tape ----------------------------------------------------------------

  function tapeSet(msg) {
    if (!tape) return { ok: false, reason: 'tape not ready' };
    if (msg.rate !== undefined) {
      const p = tape.parameters.get('rate');
      // Ramp rather than jump so varispeed glides, per the tape feel.
      p.setTargetAtTime(msg.rate, ctx.currentTime, msg.glide ?? 0.05);
    }
    const fwd = {};
    for (const k of ['mode', 'loopEnabled', 'latencySec', 'interp']) {
      if (msg[k] !== undefined) fwd[k] = msg[k];
    }
    if (Object.keys(fwd).length) tape.port.postMessage({ type: 'set', ...fwd });
    return { ok: true, applied: { ...fwd, rate: msg.rate } };
  }

  function tapeCmd(msg) {
    if (!tape) return { ok: false, reason: 'tape not ready' };
    tape.port.postMessage({
      type: msg.cmd, seconds: msg.seconds, on: msg.on, catchUp: msg.catchUp,
    });
    return { ok: true, cmd: msg.cmd, on: msg.on, seconds: msg.seconds };
  }

  function tapeQuery() {
    if (!tape) return Promise.resolve({ ok: false, reason: 'tape not ready' });
    return new Promise((resolve) => {
      const to = setTimeout(() => resolve({ ok: false, reason: 'tape query timeout' }), 2000);
      const onMsg = (e) => {
        if (e.data && e.data.type === 'state') {
          clearTimeout(to);
          tape.port.removeEventListener('message', onMsg);
          resolve({ ok: true, ...e.data });
        }
      };
      tape.port.addEventListener('message', onMsg);
      tape.port.start();
      tape.port.postMessage({ type: 'query' });
    });
  }

  return {
    ensureAudio, addChannel, dropChannel, setTitle,
    setLevel, setMute, setSolo, setPan,
    setVideoEnabled, setChannelVideo, getStream, setQuality, getQuality,
    state, levels, waveform, probe, probeTones,
    // For the recorder. Null until ensureAudio has run.
    outputNode: () => outNode,
    context: () => ctx,
    testChannel, testTone,
    tapeSet, tapeCmd, tapeQuery,
  };
})();

// The service worker hands over a stream id after the toolbar click grants capture.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'panel') return false;
  (async () => {
    try {
      if (msg.type === 'PING') sendResponse({ ok: true, ready: true });
      else if (msg.type === 'ADD_STREAM') sendResponse(await Mixer.addChannel(msg));
      else sendResponse({ ok: false, reason: 'unknown ' + msg.type });
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e), name: e && e.name });
    }
  })();
  return true; // async response
});
