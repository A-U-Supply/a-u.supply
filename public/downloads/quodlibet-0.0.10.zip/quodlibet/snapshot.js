// Mix snapshot: write down what is playing, and put it back.
//
// A mix here is not a file — it is four tabs, each at some position, blended at some
// levels, through a tape at some speed. Close the window and the whole thing is gone,
// and there is no way to find it again: you cannot bookmark "these four, at those
// moments." That is what this records.
//
// ONE FILE THAT IS BOTH THINGS. It opens in any text editor, or under Quick Look, and
// reads as prose you will still understand in six months. Below a marker line sits the
// JSON `restore` reads back. Brendan chose this over a folder or a zip: one artifact
// you can move, send or drop somewhere, with the notes travelling WITH the data rather
// than sitting on a clipboard that the next copy wipes.
//
// It is saved through a real Save-As dialog, so it goes where you want it rather than
// into ~/Downloads. Where that dialog is unavailable — or where the click that asked
// for it has gone stale, which an await can do — it falls back to an ordinary download
// rather than losing the snapshot.
//
// WHAT RESTORE CAN AND CANNOT DO. It reopens the tabs and, once a tab is captured,
// puts its level, pan, mute, solo, speed and position back. It cannot capture the
// audio for you: `tabCapture.getMediaStreamId` needs a real click on the toolbar
// button, per tab, and no API substitutes for that gesture. So a restore is a
// half-automatic thing by construction — Chrome opens the tabs, you click the icon,
// and each channel snaps into place as it arrives. The pending list is what waits in
// between, and it says how many are still owed.
//
// Depends on globals from panel.js (toContent, tabTitleOf) and audio.js (Mixer).
// Classic scripts, shared scope.

// SCOPED, unlike its neighbours. These are classic scripts sharing one global scope,
// and two of the names below (`fmtPan`, `pending`) were already taken by panel.js and
// midi.js. A repeated top-level `const` is a SyntaxError that takes the WHOLE file with
// it — every seam here silently undefined, while the panel itself carried on looking
// fine. A test caught it; a person would have seen a dead button. So this file keeps
// its names to itself and hands out only what the others need, by name, at the bottom.
(() => {
const SNAP_FORMAT = 1;
// Deliberately verbose and deliberately ugly. Someone will open this file to read the
// list, and the line has to say plainly that the half below it is not prose.
const MARKER = '── quodlibet data, do not edit below ──';
const PENDING_STORE = 'pendingRestore';

// Survives a panel reload on purpose. A restore of four tabs is four trips to the
// toolbar; reloading the panel in the middle of that should not lose the levels.
let pending = []; // [{ url, at, rate, preservesPitch, level, pan, muted, soloed, title }]

function pendingCount() {
  return pending.length;
}

async function savePending() {
  try { await chrome.storage.local.set({ [PENDING_STORE]: pending }); } catch {}
}

async function loadPending() {
  try {
    const got = await chrome.storage.local.get(PENDING_STORE);
    if (Array.isArray(got[PENDING_STORE])) pending = got[PENDING_STORE];
  } catch {}
  paintMix();
}

// ---------------------------------------------------------------- gather

const fmtClock = (s) => {
  if (s == null || !Number.isFinite(s)) return null;
  const t = Math.max(0, Math.round(s));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const sec = t % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(sec)}` : `${m}:${pad(sec)}`;
};

const fmtPan = (p) => {
  if (p == null) return 'centre';
  const n = Math.round(Math.abs(p) * 100);
  if (n < 3) return 'centre';
  return (p < 0 ? 'L' : 'R') + n;
};

// One channel's worth of the snapshot. `reachable` is kept rather than dropped: a
// channel whose page has gone quiet still belongs in the list — you were playing it —
// but its position is a guess and the text says so instead of printing a wrong time.
async function snapChannel(ch) {
  // A synthetic channel is an oscillator in this page — there is no tab behind it to
  // ask, and asking costs a failed injection round trip per poll.
  const info = ch.synthetic ? null : await toContent(ch.tabId, { type: 'INFO' });
  const ok = !!(info && info.ok);
  const tab = ch.synthetic ? null : await chrome.tabs.get(ch.tabId).catch(() => null);
  return {
    title: (ok && info.title) || tabTitleOf(ch.tabId) || ch.title || null,
    url: (ok && info.href) || (tab && tab.url) || null,
    reachable: ok,
    at: ok ? info.currentTime : null,
    duration: ok ? info.duration : null,
    paused: ok ? info.paused : null,
    rate: ok ? info.playbackRate : null,
    preservesPitch: ok ? !!info.preservesPitch : null,
    synthetic: !!ch.synthetic,
    level: ch.level,
    pan: ch.pan,
    muted: !!ch.muted,
    soloed: !!ch.soloed,
  };
}

async function gatherSnapshot() {
  const st = Mixer.state();
  // Test channels are listed too. They have no URL, so restore skips them and says
  // so — which is better than a snapshot that quietly disagrees with the deck list
  // you were looking at when you took it.
  const channels = [];
  for (const ch of st.channels || []) channels.push(await snapChannel(ch));

  const t = await Mixer.tapeQuery();
  const tape = t && t.ok
    ? {
        mode: t.mode,
        rate: t.rate,
        interp: t.interp,
        loopEnabled: !!t.loopEnabled,
        loopLenSec: t.loopEnabled ? t.loopLenSec : null,
      }
    : null;

  return {
    app: 'quodlibet',
    snapshot: SNAP_FORMAT,
    version: chrome.runtime.getManifest().version,
    takenAt: new Date().toISOString(),
    channels,
    tape,
  };
}

// ---------------------------------------------------------------- text

function snapshotText(snap) {
  const when = new Date(snap.takenAt);
  const stamp =
    when.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) +
    ' ' +
    when.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

  const lines = [`quodlibet mix — ${stamp}`, ''];

  if (!snap.channels.length) lines.push('(no channels)');

  snap.channels.forEach((c, i) => {
    lines.push(`${i + 1}. ${c.title || '(untitled)'}`);
    if (c.url) lines.push(`   ${c.url}`);

    const bits = [];
    const at = fmtClock(c.at);
    if (at) bits.push(c.duration ? `at ${at} of ${fmtClock(c.duration)}` : `at ${at}`);
    else if (!c.reachable) bits.push('position unknown — page not answering');
    bits.push(`lvl ${Number(c.level ?? 1).toFixed(2)}`);
    bits.push(fmtPan(c.pan));
    if (c.rate != null && Math.abs(c.rate - 1) > 0.005) bits.push(`${c.rate.toFixed(2)}x`);
    if (c.muted) bits.push('MUTED');
    if (c.soloed) bits.push('SOLO');
    if (c.paused) bits.push('paused');
    lines.push('   ' + bits.join(' · '));
    lines.push('');
  });

  if (snap.tape) {
    const t = snap.tape;
    const dir = t.rate < 0 ? 'reverse' : t.rate === 0 ? 'stopped' : 'forward';
    lines.push(
      `tape: ${t.mode} · ${Number(t.rate).toFixed(2)}x ${dir} · ${t.interp}` +
        (t.loopEnabled ? ` · loop ${Number(t.loopLenSec).toFixed(2)}s` : ''),
    );
  }

  lines.push(`quodlibet ${snap.version}`);
  return lines.join('\n');
}

// What is actually written to disk: the readable list, then the marker, then the data.
function snapshotFile(snap) {
  return snapshotText(snap) + '\n\n' + MARKER + '\n' + JSON.stringify(snap);
}

// ---------------------------------------------------------------- take one

const snapName = (snap) =>
  'quodlibet-mix-' + snap.takenAt.slice(0, 16).replace(/[:T]/g, '-') + '.qlmix';

// Ask where it goes. showSaveFilePicker needs a live user gesture, and gathering the
// snapshot involves a round trip per channel — so this can legitimately fail on a slow
// page even though the user did click. Falling back to a plain download keeps the
// snapshot rather than the dialog.
async function saveFile(snap) {
  const name = snapName(snap);
  const body = snapshotFile(snap);

  if (window.showSaveFilePicker) {
    try {
      const handle = await showSaveFilePicker({
        suggestedName: name,
        types: [{ description: 'Quodlibet mix', accept: { 'text/plain': ['.qlmix'] } }],
      });
      const w = await handle.createWritable();
      await w.write(body);
      await w.close();
      return { name: handle.name || name, where: 'picked' };
    } catch (e) {
      // A cancelled dialog is not a failure and must not then download a file behind
      // the user's back — that is the one case where doing nothing is correct.
      if (e && e.name === 'AbortError') return null;
    }
  }

  const url = URL.createObjectURL(new Blob([body], { type: 'text/plain' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  return { name, where: 'downloads' };
}

let lastSnapshot = null; // for the console and the drivers

async function takeSnapshot({ file = true } = {}) {
  const snap = await gatherSnapshot();
  lastSnapshot = snap;
  const text = snapshotText(snap);
  console.log('[quodlibet mix]\n' + text); // so a take is never only in a file

  const n = snap.channels.length;
  const saved = file ? await saveFile(snap) : null;

  setMixStatus(
    !file
      ? `${n} channel${n === 1 ? '' : 's'} — not saved`
      : !saved
        ? 'Not saved — you cancelled the dialog.'
        : `${n} channel${n === 1 ? '' : 's'} saved as ${saved.name}` +
          (saved.where === 'downloads' ? ' — in your downloads.' : '.'),
  );
  return { snap, text, file: saved && saved.name, where: saved && saved.where };
}

// ---------------------------------------------------------------- put it back

// Accepts the file we write (prose, marker, JSON) and bare JSON, because a snapshot
// pasted out of the console is a legitimate thing to hand back.
function parseSnapshot(text) {
  const s = String(text || '');
  const cut = s.lastIndexOf(MARKER);
  const body = cut >= 0 ? s.slice(cut + MARKER.length) : s;

  let o;
  try { o = JSON.parse(body.trim()); } catch { return { ok: false, reason: 'not a snapshot file — could not find the data in it' }; }
  if (!o || o.app !== 'quodlibet' || !Array.isArray(o.channels))
    return { ok: false, reason: 'not a quodlibet snapshot' };
  if (Number(o.snapshot) > SNAP_FORMAT)
    return { ok: false, reason: `that snapshot was written by a newer Quodlibet (format ${o.snapshot})` };
  return { ok: true, snap: o };
}

// Matching an open tab to a saved channel. Exact URL first; then origin + path, because
// a site will happily add its own tracking or autoplay parameters to the URL it lands
// on, and a YouTube link carries the timestamp we ourselves put on it.
function urlKeys(u) {
  try {
    const p = new URL(u);
    return [p.href, p.origin + p.pathname + (p.searchParams.get('v') ? '?v=' + p.searchParams.get('v') : '')];
  } catch {
    return [String(u || '')];
  }
}

const sameTrack = (a, b) => {
  const ka = urlKeys(a);
  const kb = urlKeys(b);
  return ka.some((x) => kb.includes(x));
};

// Put the position into the URL where the site understands it, so a restored tab is
// already near the right moment before it is ever captured. Only YouTube is honoured:
// every site spells this differently and a wrong parameter is worse than none.
function urlWithTime(url, at) {
  if (!at || at < 5) return url;
  try {
    const u = new URL(url);
    if (/(^|\.)youtube\.com$/.test(u.hostname) && u.pathname === '/watch') {
      u.searchParams.set('t', String(Math.floor(at)));
      return u.href;
    }
  } catch {}
  return url;
}

async function restoreSnapshot(text) {
  const parsed = parseSnapshot(text);
  if (!parsed.ok) { setMixStatus(parsed.reason); return parsed; }

  const wanted = parsed.snap.channels.filter((c) => c.url);
  const skipped = parsed.snap.channels.length - wanted.length;

  pending = wanted.map((c) => ({
    url: c.url,
    at: c.at, rate: c.rate, preservesPitch: c.preservesPitch,
    level: c.level, pan: c.pan, muted: c.muted, soloed: c.soloed,
    title: c.title,
  }));
  await savePending();

  for (const c of pending) {
    try { await chrome.tabs.create({ url: urlWithTime(c.url, c.at), active: false }); } catch {}
  }

  if (parsed.snap.tape) {
    const t = parsed.snap.tape;
    try {
      Mixer.tapeSet({ mode: t.mode, interp: t.interp, rate: t.rate });
      if (t.loopEnabled && t.loopLenSec) Mixer.tapeCmd({ cmd: 'loopSecondsBack', seconds: t.loopLenSec });
    } catch {}
  }

  paintMix();
  return { ok: true, opened: pending.length, skipped };
}

// Called from refresh() on every poll: a channel that has just been captured gets its
// saved settings, then leaves the pending list. Position is applied last and only if
// the page is drivable — a protected stream refuses a seek, and that refusal must not
// cost the channel its levels.
async function applyPending(liveChannels, tabById) {
  if (!pending.length || !liveChannels || !liveChannels.length) return 0;
  let applied = 0;

  for (const ch of liveChannels) {
    if (ch.synthetic) continue;
    const tab = tabById ? tabById.get(ch.tabId) : null;
    const url = tab && tab.url;
    if (!url) continue;
    const i = pending.findIndex((p) => sameTrack(p.url, url));
    if (i < 0) continue;

    const p = pending[i];
    pending.splice(i, 1);
    applied++;

    try {
      if (p.level != null) Mixer.setLevel(ch.tabId, p.level);
      if (p.pan != null) Mixer.setPan(ch.tabId, p.pan);
      if (p.muted) Mixer.setMute(ch.tabId, true);
      if (p.soloed) Mixer.setSolo(ch.tabId, true, false);
    } catch {}

    if (p.rate != null && Math.abs(p.rate - 1) > 0.005) {
      await toContent(ch.tabId, { type: 'SET_RATE', rate: p.rate, preservesPitch: !!p.preservesPitch });
    }
    if (p.at != null && p.at > 1) {
      await toContent(ch.tabId, { type: 'SEEK', absolute: p.at });
    }
  }

  if (applied) { await savePending(); paintMix(); }
  return applied;
}

async function clearPending() {
  pending = [];
  await savePending();
  paintMix();
  setMixStatus('Restore cancelled.');
}

// ---------------------------------------------------------------- ui

function setMixStatus(text) {
  const el = document.getElementById('mix-status');
  if (el) el.textContent = text || '';
}

// The waiting list is the whole reason restore is comprehensible: without it, opening
// four tabs and having nothing happen looks like a failure rather than a queue.
function paintMix() {
  const el = document.getElementById('mix-pending');
  if (!el) return;
  if (!pending.length) { el.innerHTML = ''; el.hidden = true; return; }
  el.hidden = false;
  el.innerHTML =
    `<p class="hint"><strong>Waiting for ${pending.length} tab${pending.length === 1 ? '' : 's'}.</strong> ` +
    `Bring each one to the front and click the Quodlibet button in your toolbar — ` +
    `its level, pan and position go back on as it arrives.</p><ul class="mix-wait">` +
    pending.map((p) => `<li>${escapeHtml(p.title || p.url)}</li>`).join('') +
    `</ul><p><button id="mix-cancel">forget the rest</button></p>`;
  const cancel = document.getElementById('mix-cancel');
  if (cancel) cancel.addEventListener('click', clearPending);
}

const escapeHtml = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

function initMix() {
  const snap = document.getElementById('mix-snap');
  const restore = document.getElementById('mix-restore');
  const fileEl = document.getElementById('mix-file');
  if (!snap || !restore || !fileEl) return;

  snap.addEventListener('click', () => takeSnapshot());
  restore.addEventListener('click', () => fileEl.click());
  fileEl.addEventListener('change', async () => {
    const f = fileEl.files && fileEl.files[0];
    fileEl.value = ''; // so choosing the same file twice fires again
    if (!f) return;
    const r = await restoreSnapshot(await f.text());
    if (r.ok) {
      setMixStatus(
        `Opened ${r.opened} tab${r.opened === 1 ? '' : 's'}` +
          (r.skipped ? `, skipped ${r.skipped} with no link` : '') +
          '. Click the toolbar button on each.',
      );
    }
  });

  loadPending();
}

Object.assign(window, {
  // panel.js's refresh() calls this by bare name on every poll, and keys.js binds the
  // snapshot to `y`. Both read it off window as a global, which is why they are here.
  applyPending,
  takeSnapshot,
  mixSnapshot: takeSnapshot,
  mixGather: gatherSnapshot,
  mixText: snapshotText,
  mixFile: snapshotFile,
  mixParse: parseSnapshot,
  mixRestore: restoreSnapshot,
  mixPending: () => pending.slice(),
  mixPendingCount: pendingCount,
  mixClearPending: clearPending,
  mixLast: () => lastSnapshot,
  mixSameTrack: sameTrack,
  mixUrlWithTime: urlWithTime,
});

// Video mode has its own bar; the snapshot is exactly the thing you want during a
// performance, so it is reachable from both without a second implementation.
function initMixVideo() {
  const b = document.getElementById('video-snap');
  if (b) b.addEventListener('click', () => takeSnapshot());
}

initMix();
initMixVideo();
})();
