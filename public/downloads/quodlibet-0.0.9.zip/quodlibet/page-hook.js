// Main-world hook: reaches media elements that are not in the document.
//
// Measured on soundcloud.com, 2026-08-18: `document.querySelectorAll('video,audio')`
// returns 0, no shadow root holds one, and no same-origin frame holds one either —
// while the element the page is actually driving reports `isConnected: false` with a
// real duration. SoundCloud plays through an `new Audio()` that is never inserted into
// the page. querySelectorAll cannot see such an element and nothing enumerates
// detached nodes, so the only way to get a reference is to be there when the page
// touches one.
//
// Hence a prototype patch, and hence the MAIN world: an isolated content script has
// its own HTMLMediaElement.prototype, and patching that one intercepts nothing,
// because the page never calls through it.
//
// This file is the fallback, not the main road. content.js still drives an element it
// can find in the document, which keeps YouTube on exactly the path it has always
// been on; the bridge below is only asked when that search comes back empty.

(() => {
  // Bumped when this file's behaviour changes, and reported by the probe. Not
  // cosmetic: it is how a stale copy becomes visible instead of inferred. A Netflix
  // report showed `driving.drm` present and `hook.best.drm` missing — two halves of
  // one build disagreeing, because the guard below used to refuse to upgrade.
  const BUILD = '0.0.9-hook-2';

  // Upgrade in place rather than refusing to run.
  //
  // The first version returned early when it found itself already installed, so a
  // newer file injected into a tab that already had an older one did nothing at all
  // until the tab happened to navigate. The prototype patches genuinely must only
  // happen once — patching a patch grows the call chain on a hot path — but the
  // handler must be replaceable, and what has been seen must survive the swap.
  const KEY = '__quodlibetHook';
  const prev = window[KEY] && typeof window[KEY] === 'object' ? window[KEY] : null;
  if (prev && prev.listener) document.removeEventListener('quodlibet-req', prev.listener);

  // WeakRefs, because this outlives every element it sees. A Set of media elements on
  // a page that starts a new one per track is a leak with a long session behind it.
  // The array is carried across upgrades: the old patches close over it, so reusing
  // the same object is what keeps an already-registered element registered.
  const MARK = Symbol.for('quodlibet.seen');
  const state0 = prev || { refs: [], contexts: 0, patched: false };
  const refs = state0.refs;

  function remember(el) {
    if (!el || el[MARK]) return;
    try { el[MARK] = true; } catch { return; }
    refs.push(new WeakRef(el));
    if (refs.length > 24) refs.splice(0, refs.length - 24);
  }

  function best() {
    const pool = [];
    for (const r of refs) {
      const el = r.deref();
      // Not merely alive: an element the page has finished with reports readyState 0
      // with no source, and picking it would drive nothing while looking like success.
      if (el && (el.currentSrc || el.src || el.readyState > 0)) pool.push(el);
    }
    if (!pool.length) return null;
    const playing = pool.filter((el) => !el.paused && el.readyState >= 2);
    const from = playing.length ? playing : pool;
    return from.sort((a, b) => (b.duration || 0) - (a.duration || 0))[0];
  }

  // Registration hangs off the `currentTime` getter, not off play().
  //
  // A player UI reads currentTime continuously to draw its own progress bar, so an
  // element that was already playing when we arrived registers within a frame. Off
  // play() alone it would register only when you next pressed pause and play in the
  // tab — the controls would sit there dead until you performed a ritual nobody told
  // you about. play/pause/load are patched too, for a page that is paused when we
  // arrive and reads nothing until it starts.
  const desc = state0.patched
    ? null
    : Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'currentTime');
  if (desc && desc.get && desc.set) {
    Object.defineProperty(HTMLMediaElement.prototype, 'currentTime', {
      configurable: desc.configurable,
      enumerable: desc.enumerable,
      get() { remember(this); return desc.get.call(this); },
      set(v) { remember(this); return desc.set.call(this, v); },
    });
  }
  if (!state0.patched) {
    for (const name of ['play', 'pause', 'load']) {
      const orig = HTMLMediaElement.prototype[name];
      if (typeof orig !== 'function') continue;
      HTMLMediaElement.prototype[name] = function (...args) {
        remember(this);
        return orig.apply(this, args);
      };
    }
  }

  // Whether the page has a Web Audio graph at all. This is the discriminator for the
  // one cause nothing can fix: a page playing through an AudioContext with no media
  // element behind it has nothing to set playbackRate on, and no amount of hooking
  // will produce one. Counting constructions is the only way to know from here.
  if (!state0.patched) {
    for (const name of ['AudioContext', 'webkitAudioContext']) {
      const Orig = window[name];
      if (typeof Orig !== 'function') continue;
      const Wrapped = function (...args) { state0.contexts++; return new Orig(...args); };
      Wrapped.prototype = Orig.prototype;
      try { Object.defineProperty(window, name, { value: Wrapped, writable: true, configurable: true }); }
      catch { /* frozen window, not worth failing over */ }
    }
  }

  // What the panel is allowed to know and do. Deliberately the same verbs content.js
  // already answers, so the caller does not care which side of the world it reached.
  function state(el) {
    return {
      ok: true,
      kind: el.tagName.toLowerCase(),
      connected: el.isConnected,
      playbackRate: el.playbackRate,
      preservesPitch: el.preservesPitch,
      volume: el.volume,
      muted: el.muted,
      currentTime: el.currentTime,
      duration: Number.isFinite(el.duration) ? el.duration : null,
      paused: el.paused,
      readyState: el.readyState,
      drm: !!el.mediaKeys,
    };
  }

  function handle(msg) {
    // The probe answers whether or not there is anything to drive — its job is to
    // explain the empty case.
    if (msg.type === 'PROBE') {
      const el = best();
      let live = 0;
      for (const r of refs) if (r.deref()) live++;
      return {
        ok: true,
        build: BUILD,
        seen: refs.length,
        live,
        audioContexts: state0.contexts,
        best: el ? { kind: el.tagName.toLowerCase(), connected: el.isConnected,
                     duration: Number.isFinite(el.duration) ? el.duration : null,
                     paused: el.paused, readyState: el.readyState,
                     drm: !!el.mediaKeys } : null,
      };
    }

    const el = best();
    if (!el) return { ok: false, reason: 'no media element' };
    try {
      switch (msg.type) {
        case 'INFO':
          break;
        case 'SET_RATE':
          if (msg.preservesPitch !== undefined) el.preservesPitch = !!msg.preservesPitch;
          el.playbackRate = msg.rate;
          break;
        case 'SET_VOLUME':
          if (msg.volume !== undefined) el.volume = Math.max(0, Math.min(1, msg.volume));
          if (msg.muted !== undefined) el.muted = !!msg.muted;
          break;
        case 'SEEK':
          // Same refusal as content.js: an EME player manages its own buffer and a
          // seek written underneath it can put the page into an unrecoverable error.
          if (el.mediaKeys) return { ...state(el), seekRefused: 'protected stream' };
          if (msg.absolute !== undefined) el.currentTime = msg.absolute;
          else if (msg.delta !== undefined) el.currentTime = el.currentTime + msg.delta;
          break;
        case 'PLAY':
          el.play().catch(() => {});
          break;
        case 'PAUSE':
          el.pause();
          break;
        default:
          return { ok: false, reason: 'unknown ' + msg.type };
      }
      return state(el);
    } catch (e) {
      return { ok: false, error: String((e && e.message) || e) };
    }
  }

  // Events, because they are the one thing both worlds genuinely share. Dispatch is
  // synchronous, so the reply has already been written by the time dispatchEvent
  // returns and the caller needs no request ids and no waiting.
  const listener = (e) => {
    let msg;
    try { msg = JSON.parse(e.detail); } catch { return; }
    let reply;
    try { reply = handle(msg); } catch (err) { reply = { ok: false, error: String(err) }; }
    document.dispatchEvent(new CustomEvent('quodlibet-res', { detail: JSON.stringify(reply) }));
  };
  document.addEventListener('quodlibet-req', listener);

  state0.listener = listener;
  state0.patched = true;
  state0.build = BUILD;
  window[KEY] = state0;
})();
