// Content script: direct control of the native <video> or <audio> in a captured tab.
//
// This is where continuous varispeed comes from. YouTube's own UI offers discrete
// rates, but the underlying HTMLMediaElement accepts any float, so `playbackRate`
// takes 1.037 exactly. `preservesPitch = false` makes pitch ride with speed, which
// is tape behaviour; true time-stretches instead. None of that is YouTube-specific —
// it is HTMLMediaElement, so it works on anything with a media element in it.
//
// Until 0.0.9 this ran on youtube.com alone, because that is all the manifest
// declared. Everywhere else the panel's `chrome.tabs.sendMessage` threw "could not
// establish connection", `toContent` swallowed it, and every consequence of a reply
// silently did not happen: no crop rect, so the tile showed the whole page; no
// SET_RATE/SEEK/PLAY, so speed, scrub and transport were dead; no title, so the tile
// kept the name the tab had at capture time. One missing script, four symptoms.
// Now the service worker injects this on the toolbar click as well. See the guard on
// the listener at the foot of the file for what that means for YouTube.
//
// A page is an SPA and swaps the media element on navigation, so never cache it.
//
// NOTE: top-level declarations here must stay `function`. This file can be evaluated
// twice in the same isolated world (declared + injected on a YouTube tab), and a
// repeated top-level `const`/`let` is a SyntaxError that takes the whole re-run with
// it. Function declarations simply overwrite themselves.

// Every media element this document can see, shadow roots included.
//
// Deep only when the shallow sweep finds nothing. `querySelectorAll('*')` on a large
// page is a couple of milliseconds and this runs on a 250ms poll, so the common case —
// a player sitting in the light DOM — must not pay for the uncommon one.
function allMedia() {
  const shallow = [...document.querySelectorAll('video, audio')];
  if (shallow.length) return shallow;

  const out = [];
  const walk = (root) => {
    out.push(...root.querySelectorAll('video, audio'));
    for (const el of root.querySelectorAll('*')) if (el.shadowRoot) walk(el.shadowRoot);
  };
  walk(document);
  return out;
}

function media() {
  const els = allMedia();
  if (!els.length) return null;

  // Prefer something with a rendered box, largest first. That is exactly the old
  // YouTube rule and it stays the rule wherever a picture exists: ads and hover
  // previews add their own <video>s, and the main player is the big one.
  const area = (e) => (e.clientWidth || 0) * (e.clientHeight || 0);
  const sized = els.filter((e) => area(e) > 0);
  if (sized.length) return sized.sort((a, b) => area(b) - area(a))[0];

  // Nothing is drawn, so this is an audio-only page — SoundCloud and Bandcamp drive a
  // 0x0 <audio>. Area cannot rank these, so take whatever is actually playing.
  const playing = els.filter((e) => !e.paused && e.readyState >= 2);
  if (playing.length) {
    const chosen = playing.sort((a, b) => (b.duration || 0) - (a.duration || 0))[0];
    try { globalThis.__quodlibetLastPlaying = new WeakRef(chosen); } catch {}
    return chosen;
  }

  // Nothing is playing, so remember what was.
  //
  // A Bandcamp Daily article carries eight <audio> elements, one per album it writes
  // about. While one is playing this is easy. Paused, the old rule fell back to the
  // longest track on the page — so pressing play in the mixer would start some other
  // album entirely, which is a strange thing for a transport button to do. Whatever
  // was last playing is the thing you paused, and it is what play should resume.
  const last = globalThis.__quodlibetLastPlaying && globalThis.__quodlibetLastPlaying.deref();
  if (last && els.includes(last)) return last;

  // Never played anything: the longest is the better guess, since a preview clip is
  // shorter than a track.
  return els.sort((a, b) => (b.duration || 0) - (a.duration || 0))[0];
}

// Ask the main-world hook, for a page whose player is not in the document at all.
//
// SoundCloud drives an `new Audio()` it never inserts, so `media()` above comes back
// null on a tab that is plainly playing. page-hook.js holds the reference; this is how
// we borrow it. Dispatch is synchronous, so the reply is already in hand by the time
// dispatchEvent returns — no ids, no waiting, no chance of two polls crossing.
//
// Returns null when the hook is not there (it is injected on the toolbar click, same
// as this file, and a YouTube tab that got only the declared script has no hook — and
// does not need one, having a real element in its document).
function fromHook(msg) {
  let raw = null;
  const onRes = (e) => { raw = e.detail; };
  document.addEventListener('quodlibet-res', onRes);
  try {
    document.dispatchEvent(new CustomEvent('quodlibet-req', { detail: JSON.stringify(msg) }));
  } catch {
    return null;
  } finally {
    document.removeEventListener('quodlibet-res', onRes);
  }
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

// The hook's answer in the shape the panel already reads.
//
// `picture: false` is not a guess. A detached element is not rendered anywhere in the
// tab, so there is no rectangle of the capture that contains it — the tile is right to
// draw the waveform, whether the element is an <audio> or a <video>.
function hookInfo(r) {
  return {
    ok: true,
    detached: true,
    crop: null,
    picture: false,
    kind: r.kind,
    vw: window.innerWidth,
    vh: window.innerHeight,
    playbackRate: r.playbackRate,
    preservesPitch: r.preservesPitch,
    volume: r.volume,
    muted: r.muted,
    currentTime: r.currentTime,
    duration: r.duration,
    paused: r.paused,
    readyState: r.readyState,
    drm: !!r.drm,
    videoId: null,
    isAd: false,
    title: trimSiteName(document.title),
    href: location.href,
  };
}

// Why this tab cannot be driven — the whole answer in one object.
//
// This exists because finding out took a twenty-minute console session with Brendan
// pasting blocks into soundcloud.com, and there are four different causes that look
// identical from the panel: an element in the light DOM, one in a shadow root, one in
// a frame we do not run in, one detached from the document entirely, or no element at
// all behind a Web Audio graph. Each needs a different fix. Guessing between them is
// how you build the wrong one.
function probe() {
  const frames = [...document.querySelectorAll('iframe')].map((f, i) => {
    let media = 'cross-origin';
    try { if (f.contentDocument) media = f.contentDocument.querySelectorAll('video, audio').length; }
    catch { media = 'cross-origin'; }
    return { i, src: (f.src || '(empty src)').slice(0, 90), media };
  });

  const shallow = document.querySelectorAll('video, audio').length;
  const deep = allMedia().length;
  const hook = fromHook({ type: 'PROBE' });
  const chosen = media();

  return {
    ok: true,
    probe: true,
    // Which code is actually running in this page, as opposed to which is installed
    // in the browser. They are not the same thing: a tab keeps whatever was injected
    // into it, so a mismatch here means reload the tab, not reinstall the extension.
    // Guarded: `chrome.runtime` throws "Extension context invalidated" in a script
    // whose extension has been reloaded underneath it — which is exactly the stale
    // copy this field exists to reveal. A probe that dies on the case it diagnoses is
    // worth nothing. (It is also what lets this file be evaluated on a plain page by
    // the tests, with no extension APIs at all.)
    contentBuild: (() => {
      try { return chrome.runtime.getManifest().version; } catch { return null; }
    })(),
    href: location.href,
    title: document.title,
    inDocument: shallow,
    inShadowRoots: deep - shallow,
    frames,
    framesWithMedia: frames.filter((f) => typeof f.media === 'number' && f.media > 0).length,
    crossOriginFrames: frames.filter((f) => f.media === 'cross-origin').length,
    // What the main-world hook can see. `hook: null` means it was never injected —
    // a YouTube tab that only got the declared content script, or an injection Chrome
    // refused. Anything else is its own report.
    hook,
    // What we would actually drive, if anything.
    // `drm` is here because the seek refusal hangs off it. Without it in the report
    // there is no way to know whether the refusal is armed on a given site short of
    // scrubbing and seeing whether the page survives, which is the experiment this
    // whole file exists to avoid.
    driving: chosen
      ? { kind: chosen.tagName.toLowerCase(), connected: chosen.isConnected, drm: !!chosen.mediaKeys }
      : null,
    mediaSession: (() => {
      try {
        const ms = navigator.mediaSession;
        return ms ? { playbackState: ms.playbackState, hasMetadata: !!ms.metadata } : null;
      } catch { return null; }
    })(),
  };
}

// The site's name from its hostname — the registrable label, not the first one.
//
// Taking the first label is what a first draft does and Bandcamp is why it is wrong:
// it gives every artist a subdomain, so `lavendercountry.bandcamp.com` made the brand
// "lavendercountry", and "Album | Artist" then looked like a title with the site's
// name on the end. Stripping it would have removed the artist — the exact failure the
// rule below is written to avoid.
function siteBrand(host) {
  const parts = String(host || '').replace(/^www\./, '').split('.').filter(Boolean);
  if (parts.length < 2) return parts[0] || '';
  parts.pop(); // the TLD
  // ...and the second-level suffix in the likes of `example.co.uk`.
  if (parts.length > 1 && ['co', 'com', 'net', 'org', 'ac', 'gov'].includes(parts[parts.length - 1])) {
    parts.pop();
  }
  return parts[parts.length - 1] || '';
}

// The tab's title without the site's name tacked on the end.
//
// Crunchyroll ships "…The Secret of Dressrosa! - Watch on Crunchyroll" and SoundCloud
// "… | Free Listening on SoundCloud". In a tile three inches wide that furniture costs
// the part you actually need to read.
//
// The brand comes from the hostname rather than a list of sites, and a trailing
// segment is only removed if it names the site — so "Cleanfeed test 3 by
// Custom-Recordings" keeps its hyphen and its label. Anything this rule is not sure
// about, it leaves alone: a title that reads oddly is a nuisance, a title with the
// artist chopped off is a lie.
//
// YouTube is deliberately exempt. Its titles are already what the tiles have always
// shown and Brendan asked for no change there; lifting the exemption is one line.
function trimSiteName(title, host = location.hostname) {
  const t = String(title || '').trim();
  if (!t || /(^|\.)youtube\.com$/.test(host)) return t;

  const brand = siteBrand(host);
  if (!brand || brand.length < 3) return t;

  // Split on the LAST separator, and only when what follows carries no separator of
  // its own — a tail is a label, not a phrase with structure.
  const m = t.match(/^(.*\S)\s*[-–—|·:]\s*([^-–—|·:]{1,40})$/);
  if (!m) return t;

  const tail = m[2].toLowerCase().replace(/[^a-z0-9]/g, '');
  return tail.includes(brand.toLowerCase()) ? m[1] : t;
}

// Whether this element will ever have a picture to show, as opposed to not having one
// yet. The panel needs the difference: "audio-only, draw the waveform and switch the
// video track off" is a permanent verdict, while "metadata has not landed" is a wait.
function hasPicture(el) {
  if (el.tagName === 'AUDIO') return false;
  // Metadata is in and it still reports no dimensions: an audio-only stream in a
  // <video> element, which is how more than one player handles its audio.
  if (el.readyState >= 1) return el.videoWidth > 0;
  return true; // too early to say; assume a picture is coming
}

// Where the player sits within the tab, as fractions of the viewport.
//
// Video mode crops the captured tab down to just this rectangle. Fractions rather
// than pixels because the capture is scaled to whatever size we asked for, so pixel
// coordinates would be wrong; fractions survive any scaling.
//
// Fractions of the VIEWPORT, though — not of the captured frame. Those are only the
// same thing when the frame has no padding, so `info()` also reports the viewport
// these were measured against and the panel maps them across. See applyCrop.
//
// Region Capture (CropTarget.fromElement + track.cropTo) is the purpose-built API for
// this and cannot be used: CropTarget is not serialisable through extension messaging
// and arrives as a blank object. A plain rectangle serialises fine.
function cropRect(v) {
  const r = v.getBoundingClientRect();
  const vw = window.innerWidth || 1;
  const vh = window.innerHeight || 1;
  if (!r.width || !r.height) return null;

  // Crop to the PICTURE, not the element. The <video> box is often larger than the
  // image inside it — the browser letterboxes when the video's aspect does not match
  // the element's — and on light-theme YouTube the page behind is white, so cropping
  // to the element box catches white strips above and below. Same maths as
  // `object-fit: contain`.
  //
  // With no videoWidth there is no picture to crop to, only the element box, and
  // cropping to that is the pre-0.0.6 bug — white strips and all. That happens
  // whenever metadata has not loaded yet, and whenever an ad <video> wins the
  // largest-element sort. Report nothing instead: the panel keeps the last good
  // rectangle, which is a far better guess than the element box.
  const iw = v.videoWidth;
  const ih = v.videoHeight;
  if (!iw || !ih) return null;

  let { left, top, width, height } = r;
  const scale = Math.min(width / iw, height / ih);
  const cw = iw * scale;
  const chh = ih * scale;
  left += (width - cw) / 2;
  top += (height - chh) / 2;
  width = cw;
  height = chh;

  // And a hair in from that, so rounding between the page and the scaled capture can
  // never reach the page behind. Proportional, not a flat pixel: at the default low
  // quality the capture is 426px wide, so one CSS px of a 1500px viewport is about a
  // quarter of a captured pixel and guards nothing.
  const insetX = Math.max(1, width * 0.004);
  const insetY = Math.max(1, height * 0.004);
  if (width > insetX * 4 && height > insetY * 4) {
    left += insetX; top += insetY; width -= insetX * 2; height -= insetY * 2;
  }

  return {
    x: Math.max(0, left / vw),
    y: Math.max(0, top / vh),
    w: Math.min(1, width / vw),
    h: Math.min(1, height / vh),
  };
}

function info(v) {
  return {
    ok: true,
    crop: cropRect(v),
    // Whether there is a picture at all. `crop: null` is ambiguous on its own — it
    // means "no rectangle to report", which covers both an audio-only source and a
    // video whose metadata has not arrived. The panel treats those differently.
    picture: hasPicture(v),
    kind: v.tagName.toLowerCase(),
    // The viewport `crop` is a fraction of. The captured frame is this viewport
    // fitted into a 16:9 box, so unless the window happens to be 16:9 the frame
    // carries padding and these two coordinate spaces are not the same one.
    vw: window.innerWidth,
    vh: window.innerHeight,
    playbackRate: v.playbackRate,
    preservesPitch: v.preservesPitch,
    volume: v.volume,
    muted: v.muted,
    currentTime: v.currentTime,
    duration: Number.isFinite(v.duration) ? v.duration : null,
    paused: v.paused,
    readyState: v.readyState,
    // Protected playback: the page attached a MediaKeys, so an EME/MSE player is
    // managing its own buffer. Netflix and Crunchyroll are the ones we know of.
    drm: !!v.mediaKeys,
    videoId: new URLSearchParams(location.search).get('v'),
    // A pre-roll ad puts a different <video> in front of the content one; callers
    // should not trust rate/seek while this is true.
    isAd: !!document.querySelector('.ad-showing, .ytp-ad-player-overlay'),
    // document.title, deliberately. navigator.mediaSession.metadata is the media's
    // own declaration of itself and would often be cleaner — but it also renames
    // YouTube tiles from the video's title to "song — artist", and Brendan asked for
    // the tab's own name. Do not reintroduce it without asking him again.
    title: trimSiteName(document.title),
    // Where this tab actually is, for the panel to show and for snapshotting a mix.
    href: location.href,
  };
}

// Registered once per frame, however many times this file is evaluated.
//
// A YouTube tab now gets this script twice: once from the declared content_scripts
// entry, once from the injection on the toolbar click. Two listeners would both call
// sendResponse for the same message, and the second call is an error — so the guard
// is not tidiness, it is the difference between working and intermittently not.
if (!globalThis.__quodlibetContent) {
  globalThis.__quodlibetContent = true;

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.target !== 'content') return false;

    // Asked before anything else, because the whole point of it is to explain a tab
    // where nothing else works.
    if (msg.type === 'PROBE') {
      sendResponse(probe());
      return true;
    }

    const v = media();
    if (!v) {
      // Nothing in the document. Before giving up, ask the main-world hook — a
      // detached element is invisible to every selector but perfectly drivable.
      const r = fromHook(msg);
      if (r && r.ok) {
        sendResponse(hookInfo(r));
        return true;
      }
      // The panel shows this: a tab can be captured and audible with nothing this
      // script can drive — a page built on Web Audio with no media element at all, or
      // a player inside a cross-origin iframe.
      sendResponse({ ok: false, reason: 'no media element', href: location.href });
      return true;
    }

    try {
      switch (msg.type) {
        case 'INFO':
          break;

        case 'SET_RATE':
          // preservesPitch first, so the rate change lands with the intended mode.
          if (msg.preservesPitch !== undefined) v.preservesPitch = !!msg.preservesPitch;
          v.playbackRate = msg.rate;
          break;

        case 'SET_VOLUME':
          if (msg.volume !== undefined) v.volume = Math.max(0, Math.min(1, msg.volume));
          if (msg.muted !== undefined) v.muted = !!msg.muted;
          break;

        case 'SEEK':
          // Not on a protected stream.
          //
          // Netflix threw its own error page — M7375, "Pardon the interruption",
          // recoverable only by reloading — the first time a scrub reached it. An EME
          // player fetches and decrypts around a buffer it manages itself, and writing
          // currentTime moves the head out from under all of that. The page has no way
          // to tell our seek from a corrupt one, so it does the safe thing and gives
          // up. Speed and transport do not have this problem: they are things the
          // element does, not places it is asked to be.
          if (v.mediaKeys) {
            sendResponse({ ...info(v), seekRefused: 'protected stream' });
            return true;
          }
          if (msg.absolute !== undefined) v.currentTime = msg.absolute;
          else if (msg.delta !== undefined) v.currentTime = v.currentTime + msg.delta;
          break;

        case 'PLAY':
          // Rejects when the page has never been interacted with and autoplay policy
          // says no. Nothing to do about it here, but an unhandled rejection would
          // spray the page console on every click of a dead play button.
          v.play().catch(() => {});
          break;

        case 'PAUSE':
          v.pause();
          break;

        default:
          sendResponse({ ok: false, reason: 'unknown ' + msg.type });
          return true;
      }
      sendResponse(info(v));
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
    return true;
    });
}
