// Tape: a rolling stereo ring buffer sitting between the channel sum and output.
//
// It is always recording. `thru` mode passes input straight out (zero latency) while
// still filling the ring, so engaging the tape is seamless. `tape` mode plays from a
// read head that runs at `rate` — continuous, signed, so 0.5 is half speed, -1 is
// reverse, 0 is a full stop.
//
// Positions are absolute sample counts (safe to 2^53) and mapped into the ring by
// modulo, which keeps loop points and scrubbing simple.

class TapeProcessor extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [
      // a-rate so varispeed and scrub move smoothly rather than in block steps.
      { name: 'rate', defaultValue: 1, minValue: -4, maxValue: 4, automationRate: 'a-rate' },
    ];
  }

  constructor(options) {
    super();
    const opts = options.processorOptions || {};
    const seconds = opts.seconds || 60;
    this.len = Math.floor(sampleRate * seconds);
    this.ring = [new Float32Array(this.len), new Float32Array(this.len)];

    this.writePos = 0; // absolute samples written
    this.readPos = 0; // absolute, fractional
    this.mode = 'thru'; // 'thru' | 'tape'
    this.latency = Math.floor(sampleRate * (opts.latencySec || 0.25));

    this.loopEnabled = false;
    this.loopStart = 0;
    this.loopEnd = 0;
    this.lastRate = 1;
    this.interp = opts.interp || 'linear'; // 'linear' | 'cubic'
    this.stutterPrev = null; // loop state saved for the duration of a stutter

    // A stopped transport must make no sound. Holding the read head still returns the
    // same sample forever, which is a DC offset that buzzes; and once the buffer is
    // full the oldest-clamp starts dragging the head one jump per block, which is a
    // ~375Hz staircase of unrelated samples. Both were audible as "dissonant
    // crackling that won't stop". Fading out near zero rate fixes both, and is what a
    // real tape does anyway.
    this.stopGain = 1;
    // ~20ms ramp, so it reads as a stop rather than a click.
    this.fadeCoeff = 1 - Math.exp(-1 / (0.02 * sampleRate));

    this.port.onmessage = (e) => this.onMessage(e.data || {});
  }

  onMessage(m) {
    switch (m.type) {
      case 'set':
        if (m.mode !== undefined && m.mode !== this.mode) {
          // Entering tape: drop the read head to the standing latency behind live so
          // there is rope to scrub backwards into.
          if (m.mode === 'tape') this.readPos = this.writePos - this.latency;
          this.mode = m.mode;
        }
        if (m.latencySec !== undefined) {
          this.latency = Math.floor(sampleRate * m.latencySec);
        }
        if (m.loopEnabled !== undefined) this.loopEnabled = !!m.loopEnabled;
        if (m.interp === 'linear' || m.interp === 'cubic') this.interp = m.interp;
        break;

      // Loop points are marked live, relative to the read head.
      case 'loopIn':
        this.loopStart = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
        break;
      case 'loopOut':
        this.loopEnd = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
        break;
      // Momentary: grab the last `seconds` and loop it, then put the previous loop
      // state back. Held, it repeats; released, it stops pretending it never
      // happened — by default it snaps back to live, since stuttering spends time.
      case 'stutter': {
        if (m.on) {
          if (!this.stutterPrev) {
            this.stutterPrev = {
              enabled: this.loopEnabled, start: this.loopStart, end: this.loopEnd,
            };
          }
          const end = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
          const len = Math.max(64, Math.floor(sampleRate * (m.seconds || 0.125)));
          this.loopStart = end - len;
          this.loopEnd = end;
          this.loopEnabled = true;
        } else if (this.stutterPrev) {
          this.loopEnabled = this.stutterPrev.enabled;
          this.loopStart = this.stutterPrev.start;
          this.loopEnd = this.stutterPrev.end;
          this.stutterPrev = null;
          if (m.catchUp !== false) this.readPos = this.writePos - this.latency;
        }
        break;
      }

      // Jump the read head without changing rate — used to return to live.
      case 'toLive':
        this.readPos = this.writePos - this.latency;
        break;

      case 'loopSecondsBack': {
        const end = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
        this.loopStart = end - Math.floor(sampleRate * (m.seconds || 2));
        this.loopEnd = end;
        this.loopEnabled = true;
        break;
      }
      case 'query':
        this.port.postMessage({
          type: 'state',
          mode: this.mode,
          rate: this.lastRate,
          interp: this.interp,
          sampleRate,
          bufferSeconds: this.len / sampleRate,
          latencySec: this.latency / sampleRate,
          loopEnabled: this.loopEnabled,
          loopLenSec: (this.loopEnd - this.loopStart) / sampleRate,
          behindLiveSec: (this.writePos - this.readPos) / sampleRate,
          secondsRecorded: Math.min(this.writePos, this.len) / sampleRate,
        });
        break;
    }
  }

  at(chan, i) {
    const len = this.len;
    return this.ring[chan][((i % len) + len) % len];
  }

  sample(chan, pos) {
    const i0 = Math.floor(pos);
    const t = pos - i0;

    if (this.interp === 'cubic') {
      // Catmull-Rom. Four taps instead of two; markedly less imaging at non-unity
      // rates, where linear alternates exact samples with midpoints and leaves a
      // strong image at the source frequency.
      const y0 = this.at(chan, i0 - 1);
      const y1 = this.at(chan, i0);
      const y2 = this.at(chan, i0 + 1);
      const y3 = this.at(chan, i0 + 2);
      const a = -0.5 * y0 + 1.5 * y1 - 1.5 * y2 + 0.5 * y3;
      const b = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3;
      const c = -0.5 * y0 + 0.5 * y2;
      return ((a * t + b) * t + c) * t + y1;
    }

    const a = this.at(chan, i0);
    const b = this.at(chan, i0 + 1);
    return a + (b - a) * t;
  }

  process(inputs, outputs, params) {
    const input = inputs[0];
    const output = outputs[0];
    const n = output[0].length;

    // Always record.
    for (let c = 0; c < 2; c++) {
      const src = (input && (input[c] || input[0])) || null;
      const ring = this.ring[c];
      for (let i = 0; i < n; i++) {
        ring[(this.writePos + i) % this.len] = src ? src[i] : 0;
      }
    }

    if (this.mode === 'thru') {
      for (let c = 0; c < output.length; c++) {
        const src = (input && (input[c] || input[0])) || null;
        if (src) output[c].set(src);
        else output[c].fill(0);
      }
      this.writePos += n;
      this.readPos = this.writePos - this.latency;
      return true;
    }

    const rateArr = params.rate;
    const newest = this.writePos + n - 1;
    const oldest = newest - this.len + 2;

    for (let i = 0; i < n; i++) {
      const rate = rateArr.length > 1 ? rateArr[i] : rateArr[0];
      this.lastRate = rate;

      if (this.loopEnabled && this.loopEnd > this.loopStart) {
        const loopLen = this.loopEnd - this.loopStart;
        if (this.readPos >= this.loopEnd) this.readPos -= loopLen;
        else if (this.readPos < this.loopStart) this.readPos += loopLen;
      } else {
        // Never read ahead of what has been written, or off the back of the ring.
        if (this.readPos > newest - 1) this.readPos = newest - 1;
        if (this.readPos < oldest) this.readPos = oldest;
      }

      // Full level from |rate| = RATE_FADE upwards, so genuine slow speeds (0.25 and
      // below are still well clear of it) are untouched.
      const RATE_FADE = 0.02;
      const target = Math.min(1, Math.abs(rate) / RATE_FADE);
      this.stopGain += (target - this.stopGain) * this.fadeCoeff;

      for (let c = 0; c < output.length; c++) {
        output[c][i] = this.sample(c, this.readPos) * this.stopGain;
      }
      this.readPos += rate;
    }

    this.writePos += n;
    return true;
  }
}

registerProcessor('tape', TapeProcessor);
