// Action click -> make sure the panel is up -> get a stream id -> hand it to the
// panel, which owns the audio graph. getMediaStreamId requires the extension to have
// been invoked on the target tab, which the action click satisfies. Adding a second
// tab = click the action on it.

// Show the panel, reusing the existing one rather than stacking up duplicates.
// Querying by URL rather than remembering a tab id means there is no stale id to
// invalidate when the user closes it — single instance by construction.
//
// Note this is also the only reliable way to get an extension page open under
// automation: top-level navigation to chrome-extension:// is blocked, but an
// extension-initiated tabs.create is not.
async function openOrFocusPanel() {
  const url = chrome.runtime.getURL('panel.html');
  const [existing] = await chrome.tabs.query({ url });
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    await chrome.windows.update(existing.windowId, { focused: true });
    return existing;
  }
  return chrome.tabs.create({ url });
}

// Put the page-side script in a tab, wherever that tab is.
//
// The manifest declares content.js for youtube.com only, and that stays: a declared
// script is re-run by the browser on every navigation, so YouTube keeps working
// through a whole session with no help. Everywhere else we have no host permission
// and cannot declare anything — but `activeTab`, which the toolbar click grants, is
// enough to inject by hand. That is the same gesture that already unlocks
// getMediaStreamId, so adding a tab to the mixer now also makes it controllable.
//
// The trade: activeTab lapses when that tab navigates to a new page, and the script
// goes with it. The panel shows when a channel has lost its controls and says to
// click the toolbar button again. Swapping this for `<all_urls>` in host_permissions
// would end that, at the cost of Chrome's "read and change all your data on all
// websites" warning on every install and update.
//
// content.js guards its own listener, so injecting into a YouTube tab that already
// has the declared copy is a no-op rather than a duplicate responder.
async function injectContent(tabId) {
  // The main-world hook first, so it is patched in before anything asks it. Its own
  // failure is not the content script's: a page can be perfectly drivable without it,
  // and every page was until 0.0.9.
  try {
    await chrome.scripting.executeScript({
      target: { tabId }, files: ['page-hook.js'], world: 'MAIN',
    });
  } catch (e) {
    console.warn('[mixer] hook inject failed', tabId, e.message);
  }

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    return true;
  } catch (e) {
    // chrome://, the Web Store and the PDF viewer refuse injection outright, and so
    // does any tab we were never invoked on. Not fatal: the capture still works, and
    // the channel arrives with level, pan, mute and solo but no transport.
    console.warn('[mixer] inject failed', tabId, e.message);
    return false;
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  await openOrFocusPanel();
  // Declared content scripts only run on navigation, so inject into YouTube tabs
  // that were already open when the extension loaded.
  const tabs = await chrome.tabs.query({ url: '*://*.youtube.com/*' });
  for (const t of tabs) await injectContent(t.id);
});

// Ping the panel until its listener is up. createTarget resolves before the page has
// run its scripts, and a stream id expires within seconds — so the panel must be ready
// BEFORE we take the id, not after.
async function panelReady(tries = 40) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await chrome.runtime.sendMessage({ target: 'panel', type: 'PING' });
      if (r && r.ready) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  return false;
}

chrome.action.onClicked.addListener(async (tab) => {
  try {
    // Panel first. It owns the audio graph now, so there is nowhere else to put a
    // capture, and the stream id would expire while the page was still loading.
    await openOrFocusPanel();
    const ready = await panelReady();
    if (!ready) throw new Error('mixer panel did not come up');

    // Before the capture, while the activeTab grant from this click is certainly
    // still live.
    await injectContent(tab.id);

    const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });

    const res = await chrome.runtime.sendMessage({
      target: 'panel',
      type: 'ADD_STREAM',
      streamId,
      tabId: tab.id,
      title: tab.title || String(tab.id),
    });
    console.log('[mixer] ADD_STREAM result', res);
  } catch (e) {
    console.error('[mixer] add channel failed', e);
    await openOrFocusPanel(); // the panel explains a failure better than a silent click
  }
});

globalThis.mixerOpenPanel = openOrFocusPanel;
