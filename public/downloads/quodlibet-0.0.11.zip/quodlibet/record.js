// The recorder: a take of the finished mix.
//
// It taps the LAST node before the speakers, after the tape and after the DC blocker,
// so what lands in the file is exactly what you heard — a reverse pass, a stutter, a
// speed ride, all baked in. Brendan chose that over the raw pre-tape blend: the
// recording is the performance, not the ingredients.
//
// WebM/Opus, because Chrome encodes it itself. That matters more than the format war
// suggests: an encoder in the browser means a long take costs essentially no memory and
// there is no length cap to enforce or warn about. WAV would have to be held whole in
// memory and written at the end, which buys Logic a drag-and-drop and buys us a hard
// twenty-minute ceiling. If converting turns out to be the annoying part, a WAV toggle
// is a later decision made with evidence.
//
// Nothing here touches the audible path. The recorder is a second destination hung off
// the same node, so starting and stopping a take is inaudible — which is the whole
// point of being able to hit record in the middle of something good.
//
// SCOPED, for the reason snapshot.js is: these are classic scripts sharing one global
// scope, and a repeated top-level name is a SyntaxError that silently kills the file.
(() => {

const MIME = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/ogg;codecs=opus',
].find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m)) || '';

let recorder = null;
let chunks = [];
let dest = null;
let startedAt = 0;
let lastTake = null; // { name, bytes, seconds }
// True between asking a recorder to stop and its onstop arriving. MediaRecorder.stop()
// flips state to 'inactive' SYNCHRONOUSLY but delivers onstop a turn or more later, so
// without this flag `recording()` reads false in the gap and a second click starts a
// SECOND take on top of the one still finishing.
let stopping = false;
// The in-flight stop, shared. Two callers asking the same recorder to stop must get
// the SAME promise: the second call used to re-arm `onstop`, which overwrote the first
// caller's handler and left that promise unable to ever settle. One take, one stop,
// one answer for everyone who asked.
let stopPromise = null;

const recording = () => !!recorder && recorder.state === 'recording';

const fmtDur = (s) => {
  const t = Math.max(0, Math.floor(s));
  const m = Math.floor(t / 60);
  return `${m}:${String(t % 60).padStart(2, '0')}`;
};

const fmtBytes = (b) =>
  b > 1024 * 1024 ? (b / 1024 / 1024).toFixed(1) + ' MB' : Math.round(b / 1024) + ' kB';

function takeName() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `quodlibet-take-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.webm`;
}

async function startRecording() {
  if (recording()) return { ok: false, reason: 'already recording' };
  if (!MIME) return fail('this Chrome cannot record audio — no supported format');

  // Ask about CHANNELS, not about the graph. The first version of this guard tested
  // `Mixer.outputNode()` — but ensureAudio() builds the whole chain whether or not
  // anything is feeding it, so an empty mixer passed the check and recorded a
  // beautifully encoded ten minutes of silence. Finding that out at the end of a take
  // is the worst possible moment to find it out.
  const st = Mixer.state();
  if (!st.channels || !st.channels.length)
    return fail('nothing to record yet — add a channel first');

  await Mixer.ensureAudio().catch(() => {});
  const out = Mixer.outputNode();
  const ctx = Mixer.context();
  if (!out || !ctx) return fail('the audio graph is not running');

  dest = ctx.createMediaStreamDestination();
  out.connect(dest); // a tap; the speakers keep their own connection

  chunks = [];
  recorder = new MediaRecorder(dest.stream, { mimeType: MIME, audioBitsPerSecond: 192000 });
  recorder.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
  // Without this an encoder failure leaves a recorder that is neither recording nor
  // ever going to call onstop — the exact shape of "the button still says stop".
  recorder.onerror = (e) => {
    const why = (e && e.error && e.error.name) || 'unknown error';
    teardown(recorder);
    setStatus(`Recording stopped — ${why}. Anything already captured was not saved.`);
  };
  // A timeslice rather than one blob at the end: the recorder hands over a chunk a
  // second, so the elapsed size on screen is real and a crashed tab loses a second
  // rather than the take.
  recorder.start(1000);
  startedAt = Date.now();
  paint();
  return { ok: true, mimeType: MIME };
}

// Releasing the tap and forgetting the take, from wherever it went wrong.
//
// The IDENTITY CHECK is the point. A stale onstop — from a take that was already
// superseded — must not null out the recorder belonging to a NEWER one, which would
// orphan a live MediaRecorder: still encoding, no longer reachable, its audio going
// into a blob nobody will ever be handed.
function teardown(which) {
  if (which && recorder !== which) return false;
  try { Mixer.outputNode()?.disconnect(dest); } catch {}
  dest = null;
  recorder = null;
  chunks = [];
  stopping = false;
  stopPromise = null;
  paintButtons();
  return true;
}

function stopRecording() {
  if (stopping && stopPromise) return stopPromise;
  if (!recorder) return Promise.resolve({ ok: false, reason: 'not recording' });
  const r = recorder;
  stopping = true;
  paintButtons();

  stopPromise = new Promise((resolve) => {
    r.onstop = () => {
      const seconds = (Date.now() - startedAt) / 1000;
      const blob = new Blob(chunks, { type: MIME });
      if (!teardown(r)) { resolve({ ok: false, reason: 'superseded' }); return; }

      const name = takeName();
      lastTake = { name, bytes: blob.size, seconds };
      download(blob, name);
      setStatus(`Saved ${name} — ${fmtDur(seconds)}, ${fmtBytes(blob.size)}.`);
      resolve({ ok: true, name, bytes: blob.size, seconds });
    };

    // stop() throws InvalidStateError on a recorder that is already inactive, and an
    // uncaught throw inside a Promise executor means the promise NEVER SETTLES and
    // onstop never comes — a stop button that stays a stop button for good.
    try {
      r.stop();
    } catch (e) {
      teardown(r);
      setStatus('The recording ended on its own; nothing was saved.');
      resolve({ ok: false, reason: String((e && e.message) || e) });
    }
  });
  return stopPromise;
}

// One click, one decision. Refusing during the stop gap is what stops a fast second
// click starting a take underneath the one still being written.
function toggleRecording() {
  if (stopping) return Promise.resolve({ ok: false, reason: 'still finishing the last take' });
  return recording() ? stopRecording() : startRecording();
}

function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

function fail(reason) {
  setStatus(reason);
  return { ok: false, reason };
}

// ---------------------------------------------------------------- ui

function setStatus(text) {
  const el = document.getElementById('rec-status');
  if (el) el.textContent = text || '';
}

// A recording you have forgotten about is the failure mode, so the elapsed time and the
// size are on screen the whole time, in both modes.
//
// THIS TICK NEVER STOPS, and that is the fix for the bug Brendan found: the button used
// to be repaintable only from inside onstop, so any path where onstop did not arrive
// left it reading "stop recording" with nothing able to correct it. Now the UI is
// RECONCILED against the recorder twice a second no matter what happened, so the worst
// a missed callback can cost is half a second of wrong label. A steady interval that
// does almost nothing is a small price for a control that cannot lie.
function paint() {
  paintButtons();
  if (!recording()) return;
  const seconds = (Date.now() - startedAt) / 1000;
  const bytes = chunks.reduce((n, c) => n + c.size, 0);
  setStatus(`Recording — ${fmtDur(seconds)}, ${fmtBytes(bytes)}. It stops when you say so.`);
}

function paintButtons() {
  const on = recording();
  for (const id of ['rec-toggle', 'video-rec']) {
    const b = document.getElementById(id);
    if (!b) continue;
    b.setAttribute('aria-pressed', String(on));
    b.classList.toggle('rec-on', on);
    b.disabled = stopping;
    b.textContent = stopping
      ? 'finishing…'
      : on
        ? id === 'video-rec' ? '■ stop' : '■ stop recording'
        : id === 'video-rec' ? '● rec' : '● record';
  }
}

function initRecord() {
  for (const id of ['rec-toggle', 'video-rec']) {
    const b = document.getElementById(id);
    if (b) b.addEventListener('click', () => toggleRecording());
  }
  paintButtons();
  setInterval(paint, 500);
  if (!MIME) setStatus('This Chrome cannot record audio.');
}

Object.assign(window, {
  recStart: startRecording,
  recStop: stopRecording,
  recToggle: toggleRecording,
  recIsRecording: recording,
  recMime: () => MIME,
  recLastTake: () => lastTake,
  recElapsed: () => (recording() ? (Date.now() - startedAt) / 1000 : 0),
  recIsStopping: () => stopping,
  recBytes: () => chunks.reduce((n, c) => n + c.size, 0),
  // The suite needs to stop a take without a file landing in ~/Downloads on every run.
  recSetDownload: (fn) => { download = fn; },
});

initRecord();
})();
