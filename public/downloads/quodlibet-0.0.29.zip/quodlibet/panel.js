// Extension page: the mixer UI.
//
// The deck list is a direct rendering of the audio graph's channels — nothing
// else is ever listed. That is deliberate: v0.0.1 also listed merely-audible tabs,
// which rendered a full deck whose level and pan were disabled (they need a capture)
// while rate and pos worked (they come from the content script and don't). It looked
// like two broken sliders. Now, if a deck is on screen it is captured, so all of its
// controls work.
//
// Two control surfaces per deck, with different reach:
//   - level / pan / mute / solo -> the audio graph in audio.js (any captured tab)
//   - rate / transport / seek   -> content script on the media element, in the tab
//
// The second used to be YouTube-only, and a deck decided which it was by looking for
// 'youtube.com/watch' in the tab's URL once, when it was built. That was wrong twice
// over: it called YouTube Music and /shorts uncontrollable when they are not, and it
// never changed its mind when a tab navigated. Since 0.0.9 the content script goes
// into any tab added from the toolbar, so the question is answered by asking — a deck
// is controllable while the page side keeps replying, and says so when it stops.

// ---------------------------------------------------------------- plumbing

// What happened last time we tried to put the script back into a tab. Read by the
// probe: "we could not reach the page" and "Chrome would not let us back in" are
// different problems with different fixes, and only the second one costs a permission.
const revived = new Map(); // tabId -> { at, ok, error }

// Put the scripts back into a tab that has lost them.
//
// Measured on netflix.com: the channel worked, then the tab navigated — into a title,
// or auto-advancing to the next episode — and the injected script went with the old
// page, because `activeTab` is granted per page, not per tab. The probe came back
// "Receiving end does not exist" while the tab sat there plainly playing.
//
// So: try again rather than making the user re-click. Where Chrome still permits it
// this heals in one poll and nothing is ever shown. Where it refuses, the reason is
// kept and the probe reports it — that error is exactly the evidence for whether
// `<all_urls>` in host_permissions is genuinely needed, or whether re-injection is
// enough. Rate-limited so a tab that can never be re-entered is not hammered four
// times a second.
async function reviveContent(tabId) {
  const last = revived.get(tabId);
  const now = Date.now();
  if (last && now - last.at < 3000) return false;
  revived.set(tabId, { at: now, ok: false, error: 'in progress' });

  try {
    await chrome.scripting.executeScript({
      target: { tabId }, files: ['page-hook.js'], world: 'MAIN',
    });
  } catch { /* the hook is a fallback; content.js is what matters */ }

  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    revived.set(tabId, { at: now, ok: true, error: null });
    return true;
  } catch (e) {
    revived.set(tabId, { at: now, ok: false, error: String(e.message || e) });
    return false;
  }
}

// Talks to the content script in a captured tab. A throw here means the message found
// no receiver — almost always a tab that navigated — so put the script back and send
// it again before reporting failure. {ok:false} with a `reason` is different: that is
// the page answering that it has nothing to drive.
async function toContent(tabId, msg) {
  const send = () => chrome.tabs.sendMessage(tabId, { target: 'content', ...msg });
  try {
    return await send();
  } catch (e) {
    if (await reviveContent(tabId)) {
      try { return await send(); } catch (e2) { return { ok: false, error: String(e2.message || e2) }; }
    }
    const r = revived.get(tabId);
    return { ok: false, error: String(e.message || e), revive: (r && r.error) || null };
  }
}

// Titles seen on the last poll. Video mode reads this when a tile's content script
// has gone quiet, so a tile still follows a tab that navigated rather than naming
// whatever was playing when it was captured. One poll, both modes.
const tabTitles = new Map();
const tabTitleOf = (tabId) => tabTitles.get(tabId) || null;

// One report you can send instead of a console session.
//
// Finding out why soundcloud.com could not be driven took twenty minutes of pasting
// blocks into its console, and the answer was a single fact (a detached element) among
// four causes that look identical from here. This gathers all four at once. It is
// wired to the note a dead channel shows, so the thing that tells you something is
// wrong is also the thing that explains it.
async function probeTab(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const page = await toContent(tabId, { type: 'PROBE' });
  return {
    quodlibet: chrome.runtime.getManifest().version,
    tabId,
    url: tab ? tab.url : null,
    audible: tab ? !!tab.audible : null,
    // false means the content script is not in that tab at all — a different problem
    // from a page it cannot find a player in, and the two are easy to confuse.
    reachedPage: !!(page && page.ok),
    // Why we could not get back in, when we could not. A permission error here is the
    // case that `<all_urls>` would fix; anything else is a bug on our side.
    revive: revived.get(tabId) || null,
    page,
  };
}

async function copyProbe(tabId) {
  const text = JSON.stringify(await probeTab(tabId), null, 2);
  let copied = false;
  try { await navigator.clipboard.writeText(text); copied = true; } catch {}
  console.log('[quodlibet probe]\n' + text); // the console is the fallback clipboard
  return copied;
}

const listTabs = async () =>
  (await chrome.tabs.query({})).map((t) => ({
    id: t.id,
    audible: !!t.audible,
    title: (t.title || '').slice(0, 80),
    url: t.url || '',
  }));

// The audio graph is in this same context now (audio.js), so these are direct calls.
// There is no message boundary left to drop a message across — which is what emptied
// the deck list in v0.0.1.
async function addChannel(tabId) {
  let streamId;
  try {
    streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  } catch (e) {
    return { ok: false, stage: 'getMediaStreamId', error: String(e.message || e) };
  }
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  return Mixer.addChannel({
    streamId, tabId, title: (tab && tab.title) || 'tab ' + tabId,
  });
}

const getState = () => Mixer.state();
const getLevels = () => Mixer.levels();
const setGain = (tabId, value) => Mixer.setLevel(tabId, value);
const setMute = (tabId, muted) => Mixer.setMute(tabId, muted);
const setSolo = (tabId, soloed, exclusive) => Mixer.setSolo(tabId, soloed, exclusive);
const setPan = (tabId, pan) => Mixer.setPan(tabId, pan);
const dropChannel = (tabId) => Mixer.dropChannel(tabId);
const tapeSet = (msg) => Mixer.tapeSet(msg);
const tapeCmd = (cmd, seconds) => Mixer.tapeCmd({ cmd, seconds });
const tapeQuery = () => Mixer.tapeQuery();

// ---------------------------------------------------------------- ui state

const decks = new Map(); // tabId -> { el, parts }
let dragging = null; // control the user is moving; never overwrite it from a poll

// Channel order as rendered. MIDI binds to POSITION, never to a tab id: tab ids are
// regenerated every session, so "fader 1 -> tabId 1250602118" would be dead by
// morning. Deck 1 is deck 1 tomorrow, which is also how a hardware mixer behaves.
let deckOrder = [];

// Last KNOWN-GOOD channel list. A failed message must never be read as "no
// channels" — refresh() runs every 700ms, so treating one dropped message as an
// empty mixer wiped every deck on screen. That was the v0.0.1 bug that made paused
// tracks look permanently lost.
let lastChannels = [];

const fmtTime = (s) =>
  Number.isFinite(s)
    ? `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`
    : '--:--';
const fmtPan = (v) =>
  Math.abs(v) < 0.02 ? 'C' : (v < 0 ? 'L' : 'R') + Math.round(Math.abs(v) * 100);
const fmtDb = (db) => (db === null || db === undefined ? '  -inf' : db.toFixed(1).padStart(6));

function trackDrag(el) {
  el.addEventListener('pointerdown', () => (dragging = el));
  el.addEventListener('pointerup', () => (dragging = null));
  el.addEventListener('blur', () => { if (dragging === el) dragging = null; });
}

// ---------------------------------------------------------------- decks

// Rate, position and transport all run on the media element in the tab, through the
// content script. A tab can be captured and audible with no way in — one that has
// navigated since it was added, a chrome:// page, a player whose media sits in an
// iframe — and a slider that looks live and does nothing is worse than one that
// admits it. Same treatment the tiles get; see setControllable in video.js.
function setDeckControllable(parts, on, reason) {
  if (parts.controllable === on) return;
  parts.controllable = on;
  parts.rateRow.classList.toggle('idle', !on);
  parts.rateRow.querySelectorAll('input,button').forEach((n) => (n.disabled = !on));
  // The seek row has two reasons to be idle and both must hold for it to come back.
  const seekOn = on && parts.scrubbable;
  parts.seekRow.classList.toggle('idle', !seekOn);
  parts.seekRow.querySelectorAll('input,button').forEach((n) => (n.disabled = !seekOn));
  parts.note.textContent = on
    ? ''
    : reason === 'no media element'
      ? 'nothing to drive'
      : 'no page control';
}

// Protected streams are drivable but not seekable; see the refusal in content.js.
function setDeckScrubbable(parts, on) {
  if (parts.scrubbable === on) return;
  parts.scrubbable = on;
  parts.seekRow.classList.toggle('idle', !on || !parts.controllable);
  parts.seekRow.querySelectorAll('input,button').forEach((n) => {
    n.disabled = !on || !parts.controllable;
  });
  if (parts.controllable) parts.note.textContent = on ? '' : 'no scrub — protected';
}

function buildDeck(tabId) {
  const el = document.createElement('div');
  el.className = 'deck';
  // So a test can name one deck among several — the same reason the video tiles carry
  // it. Without it there is no way to ask WHICH deck holds a given position, and a
  // check about MIDI's positional mappings had to settle for asking whether the
  // position existed at all, which was true of the deck on its way out too.
  el.dataset.tab = String(tabId);

  el.innerHTML = `
    <div class="deck__head">
      <span class="deck__title"></span>
      <span class="deck__tag" data-help="This channel's state. 'captured' means audio is flowing. 'paused' means it is still in the mixer but the tab is silent. 'ad playing' means YouTube is running an advert, which has its own player, so rate and position apply to the advert until it ends."></span>
      <span class="deck__meter" data-help="Live level of this channel in dBFS, measured after the fader and before the pan."></span>
      <span class="deck__note"></span>
      <button class="deck__probe" data-help="Copy a report of what this tab actually contains — which player it has and where, and what this extension can and cannot reach. Paste it into a bug report. Works whether or not the channel is behaving.">probe</button>
      <button class="deck__x" title="Remove from mixer"
        data-help="Take this tab out of the mixer and stop capturing it. Add it back with the toolbar button.">&times;</button>
    </div>
    <div class="srcwave" data-help="What this channel has been contributing, on the same timeline as the tape below — so the white line is the tape's play head, and scrubbing the tape shows what this source was doing at that moment rather than what it is doing now.">
      <canvas class="srcwave__c"></canvas>
    </div>
    <div class="row">
      <label>level</label>
      <input type="range" class="level" min="0" max="1.5" step="0.01" value="1"
        data-help="Channel fader. Runs to 1.5 so you can push a quiet source past unity. Works on any captured tab, including one this extension cannot otherwise reach into." />
      <span class="val lvlv">1.00</span>
      <span class="btns">
        <button class="mute hot" aria-pressed="false"
          data-help="Silence this channel without moving its fader.">mute</button>
        <button class="solo" aria-pressed="false"
          data-help="Hear only this channel. Ducks the others without touching their faders, so unsoloing restores your mix exactly. Shift-click to solo several at once.">solo</button>
      </span>
    </div>
    <div class="row pan-row">
      <label>pan</label>
      <input type="range" class="pan" min="-1" max="1" step="0.01" value="0"
        data-help="Position in the stereo field, hard left through centre to hard right." />
      <span class="val panv">C</span>
      <span class="btns"><button class="pancenter"
        data-help="Return this channel to dead centre.">centre</button></span>
    </div>
    <div class="row rate-row">
      <label>rate</label>
      <input type="range" class="rate" min="0.25" max="2.5" step="0.001" value="1"
        data-help="Playback speed of the media itself, continuously variable — 1.037 is a real setting, not rounded to a preset. Needs the page-side script, so it idles on a tab that has none." />
      <span class="val ratev">1.000</span>
      <span class="btns">
        <button class="rate1" data-help="Snap the speed back to normal.">1.0</button>
        <button class="pitch" aria-pressed="true"
          data-help="On: speed changes without changing pitch (time-stretch). Off: pitch rides with speed, the way tape behaves.">keep pitch</button>
      </span>
    </div>
    <div class="row seek-row">
      <label>pos</label>
      <input type="range" class="seek" min="0" max="1000" step="1" value="0"
        data-help="Scrub the media. Needs the page-side script, so it idles on a tab that has none. A live stream has no length to scrub." />
      <span class="val time">--:--</span>
      <span class="btns">
        <button class="play" data-help="Resume this video.">play</button>
        <button class="pause" data-help="Pause this video. It stays in the mixer — the channel is not removed.">pause</button>
      </span>
    </div>`;

  const q = (s) => el.querySelector(s);
  const parts = {
    title: q('.deck__title'), tag: q('.deck__tag'), meter: q('.deck__meter'),
    wave: q('.srcwave__c'),
    x: q('.deck__x'),
    level: q('.level'), lvlv: q('.lvlv'), mute: q('.mute'), solo: q('.solo'),
    pan: q('.pan'), panv: q('.panv'), pancenter: q('.pancenter'), panRow: q('.pan-row'),
    rate: q('.rate'), ratev: q('.ratev'), rate1: q('.rate1'), pitch: q('.pitch'),
    seek: q('.seek'), time: q('.time'), play: q('.play'), pause: q('.pause'),
    rateRow: q('.rate-row'), seekRow: q('.seek-row'), note: q('.deck__note'),
    probe: q('.deck__probe'), scrubbable: true,
    duration: 0,
    // Set from whether the page side answers, on every pass. Starts optimistic so a
    // deck does not flash idle in the gap before its first reply.
    controllable: true,
  };

  [parts.level, parts.pan, parts.rate, parts.seek].forEach(trackDrag);

  parts.level.addEventListener('input', () => {
    const v = Number(parts.level.value);
    parts.lvlv.textContent = v.toFixed(2);
    setGain(tabId, v);
  });

  parts.pan.addEventListener('input', () => {
    const v = Number(parts.pan.value);
    parts.panv.textContent = fmtPan(v);
    setPan(tabId, v);
  });
  parts.pancenter.addEventListener('click', () => {
    parts.pan.value = '0';
    parts.panv.textContent = 'C';
    setPan(tabId, 0);
  });

  // Mute and solo are mixer-wide state, so the audio graph owns them; the UI only
  // states intent and reflects whatever comes back.
  parts.mute.addEventListener('click', () => setMute(tabId));
  // Shift-click builds a multi-channel solo instead of replacing it.
  parts.solo.addEventListener('click', (e) => setSolo(tabId, undefined, !e.shiftKey));

  // Always there, not only when the channel already looks dead — the case you most
  // want to report is not always the case that looks broken.
  parts.probe.addEventListener('click', async () => {
    const was = parts.probe.textContent;
    parts.probe.textContent = (await copyProbe(tabId)) ? 'copied' : 'console';
    setTimeout(() => { parts.probe.textContent = was; }, 2500);
  });

  parts.x.addEventListener('click', async () => {
    await dropChannel(tabId);
    refresh();
  });

  const applyRate = () => {
    const v = Number(parts.rate.value);
    parts.ratev.textContent = v.toFixed(3);
    toContent(tabId, {
      type: 'SET_RATE',
      rate: v,
      preservesPitch: parts.pitch.getAttribute('aria-pressed') === 'true',
    });
  };
  parts.rate.addEventListener('input', applyRate);
  parts.rate1.addEventListener('click', () => { parts.rate.value = '1'; applyRate(); });
  parts.pitch.addEventListener('click', () => {
    const on = parts.pitch.getAttribute('aria-pressed') !== 'true';
    parts.pitch.setAttribute('aria-pressed', String(on));
    applyRate();
  });

  parts.seek.addEventListener('change', () => {
    if (!parts.duration) return;
    toContent(tabId, {
      type: 'SEEK', absolute: (Number(parts.seek.value) / 1000) * parts.duration,
    });
  });
  parts.play.addEventListener('click', () => toContent(tabId, { type: 'PLAY' }));
  parts.pause.addEventListener('click', () => toContent(tabId, { type: 'PAUSE' }));

  if (typeof scopeAttachSource === 'function') scopeAttachSource(parts.wave, tabId);
  decks.set(tabId, { el, parts });
  document.getElementById('decks').appendChild(el);
  return decks.get(tabId);
}

async function refresh() {
  const st = await getState();
  const fresh = !!(st && st.ok && Array.isArray(st.channels));
  if (fresh) lastChannels = st.channels;
  const channels = fresh ? st.channels : lastChannels;

  const lv = await getLevels();
  const levelBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.db]));
  const stateBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.state]));

  // Tabs are consulted only for titles and to notice one that has closed — never to
  // decide what belongs in the mixer.
  let tabById = null;
  try {
    tabById = new Map((await listTabs()).map((t) => [t.id, t]));
    for (const [id, t] of tabById) if (t.title) tabTitles.set(id, t.title);
  } catch {
    tabById = null; // a failed query must not be read as "every tab closed"
  }

  // A closed tab's capture is dead, so retire the channel with it. Only act when the
  // tab list is trustworthy AND the channel list is fresh.
  if (fresh && tabById) {
    for (const ch of channels) {
      if (!ch.synthetic && !tabById.has(ch.tabId)) dropChannel(ch.tabId);
    }
  }

  const live = channels.filter(
    (ch) => ch.synthetic || !tabById || tabById.has(ch.tabId),
  );

  for (const [tabId, d] of decks) {
    if (!live.some((c) => c.tabId === tabId)) { d.el.remove(); decks.delete(tabId); }
  }

  deckOrder = live.map((c) => c.tabId);

  // A restore in progress: a channel that has just been captured gets its saved
  // level, pan and position here, because this is the poll that first sees it.
  // Guarded because snapshot.js loads after this file and the first refresh runs
  // before it does.
  if (typeof applyPending === 'function') applyPending(live, tabById).catch(() => {});

  for (const [i, ch] of live.entries()) {
    const tab = tabById ? tabById.get(ch.tabId) : null;
    const d = decks.get(ch.tabId) || buildDeck(ch.tabId);
    const p = d.parts;

    // Re-stamp every pass: a deck's position shifts when one above it is removed,
    // and MIDI is bound to position.
    p.level.dataset.midi = `deck:${i}:level`;
    p.pan.dataset.midi = `deck:${i}:pan`;
    p.rate.dataset.midi = `deck:${i}:rate`;
    p.mute.dataset.midi = `deck:${i}:mute`;
    p.solo.dataset.midi = `deck:${i}:solo`;

    p.title.textContent = (tab && tab.title) || ch.title || 'tab ' + ch.tabId;
    const dead = ch.live && ch.live !== 'live';
    p.tag.textContent = ch.synthetic
      ? 'test'
      : dead
        ? 'stream ended'
        : tab && tab.audible
          ? 'captured'
          : 'paused';

    p.mute.setAttribute('aria-pressed', String(!!ch.muted));
    p.solo.setAttribute('aria-pressed', String(!!ch.soloed));
    if (dragging !== p.level) {
      p.level.value = String(ch.level);
      p.lvlv.textContent = Number(ch.level).toFixed(2);
    }
    if (dragging !== p.pan) {
      p.pan.value = String(ch.pan);
      p.panv.textContent = fmtPan(ch.pan);
    }

    const info = await toContent(ch.tabId, { type: 'INFO' });
    setDeckControllable(p, !!(info && info.ok), info && info.reason);
    if (info && info.ok) {
      p.duration = info.duration || 0;
      if (dragging !== p.rate) {
        p.rate.value = String(info.playbackRate);
        p.ratev.textContent = Number(info.playbackRate).toFixed(3);
      }
      p.pitch.setAttribute('aria-pressed', String(!!info.preservesPitch));
      p.paused = !!info.paused; // the keyboard's Space needs to know which way to go
      setDeckScrubbable(p, !info.drm);
      if (dragging !== p.seek && p.duration) {
        p.seek.value = String(Math.round((info.currentTime / p.duration) * 1000));
      }
      p.time.textContent = info.isAd
        ? 'ad…'
        : `${fmtTime(info.currentTime)}/${fmtTime(info.duration)}`;
      if (info.isAd) p.tag.textContent = 'ad playing';
    }
  }

  document.getElementById('decks-empty').style.display = live.length ? 'none' : '';
}

// Every control that engages something ongoing has to show that it is engaged, and it
// has to show it from what the TAPE reports rather than from what was last clicked —
// `off`, a stutter, or another loop button can all change the state underneath a button
// that would otherwise still be lit. Called from refreshTape twice a second and from
// the scope's own push twenty times a second, so it keeps up with a finger.
function tapeLoopPaint(st) {
  // Arming a loop engages the tape, so the transport buttons have to follow it here as
  // well as on the half-second poll — otherwise the panel spends up to half a second
  // claiming to be in thru while the tape is plainly playing a loop.
  if (st.mode) {
    const thru = document.getElementById('t-thru');
    const tape = document.getElementById('t-tape');
    if (thru) thru.setAttribute('aria-pressed', String(st.mode === 'thru'));
    if (tape) tape.setAttribute('aria-pressed', String(st.mode === 'tape'));
  }
  const io = document.getElementById('t-loopio');
  if (io) {
    const arming = !!st.loopArming;
    const looping = !!st.loopEnabled && st.loopSource === 'tap';
    io.classList.toggle('io--in', arming || looping);
    io.classList.toggle('io--out', looping);
    io.setAttribute('aria-pressed', String(arming || looping));
  }
  // Only the button that actually owns the running loop lights. A tapped loop that
  // happens to be four seconds long must not light the 4s button, which would claim a
  // control that is not driving anything.
  for (const b of document.querySelectorAll('[data-loop]')) {
    const mine = !!st.loopEnabled && st.loopSource === 'seconds'
      && Math.abs(Number(b.dataset.loop) - (st.loopSeconds || 0)) < 0.01;
    b.setAttribute('aria-pressed', String(mine));
  }
}

// The manual, in its own window.
//
// It ships in the extension rather than living only on a-u.supply, so it always
// describes the build you are running and works with no access to that site and no
// network at all. Opened as a popup so it can sit beside the mixer while you read it.
//
// Queried by URL and never by a stored id — the openOrFocusPanel rule. Chrome renumbers
// tabs and windows between sessions, so a remembered id eventually focuses something
// else or nothing.
async function openManual() {
  const url = chrome.runtime.getURL('manual.html');
  try {
    const found = await chrome.tabs.query({ url });
    if (found && found.length) {
      await chrome.windows.update(found[0].windowId, { focused: true });
      await chrome.tabs.update(found[0].id, { active: true });
      return { ok: true, focused: true };
    }
  } catch {}
  try {
    await chrome.windows.create({ url, type: 'popup', width: 900, height: 940 });
    return { ok: true, opened: true };
  } catch (e) {
    return { ok: false, reason: String((e && e.message) || e) };
  }
}

// ---------------------------------------------------------------- tape ui

function buildTape() {
  const el = document.getElementById('tape');
  el.innerHTML = `
    <!-- The master strip is a child of #tape rather than a sibling, so it travels into
         video mode with the tape and cannot drift out of step with it — the same
         reasoning that moves the tape itself rather than rebuilding it. The fader sits
         BETWEEN the two meter bars, which is where a master fader lives on a desk. -->
    <div id="master-strip" data-help="The master: left and right output level either side of the fader that sets it. This is where clipping actually happens, because it is the SUM that runs out of headroom — three channels can each look fine and still drive this into the red.">
      <div class="vmeter mmeter"><div class="vmeter__fill" id="mm-l"></div></div>
      <div class="vfader" id="master-fader" data-help="Master level. Double-click to return to unity.">
        <div class="vfader__fill" id="master-fill"></div><span class="vfader__lab">mst</span>
      </div>
      <div class="vmeter mmeter"><div class="vmeter__fill" id="mm-r"></div></div>
    </div>
    <div id="scope-box" data-help="The last twelve seconds the tape recorded, scrolling right to left — the right edge is this instant. The white line is the play head, so the gap between it and the right edge is how far behind live you are. The coloured lines mark where each loop button would START its loop: watch a phrase arrive at one and press that button then.">
      <canvas id="scope"></canvas>
      <p class="hint" id="t-state"
        data-help="Tape mode, how far behind live the tape head is, and how much of the 60 second buffer has been filled."></p>
    </div>
    <div class="row row--pair">
      <label>engage</label>
      <span class="btns">
        <button id="t-thru" aria-pressed="true"
          data-help="Audio passes straight through with no delay. The tape keeps recording underneath, so switching to it is seamless.">thru</button>
        <button id="t-tape" aria-pressed="false"
          data-help="Play from the tape head instead of live. It sits a quarter second behind, which is the room you have to scrub back into.">tape</button>
        <button id="t-rev" aria-pressed="false" data-help="Play the tape backwards at normal speed. This latches, and holding it opens the gap to live at two seconds per second — click it again to return to forward speed. That leaves the head where it landed, in the past; use 'to live' to come back.">reverse</button>
        <button id="t-stop" aria-pressed="false" data-help="Halt the tape head. Sources keep playing underneath; the tape simply stops moving.">stop</button>
        <button id="t-play" aria-pressed="false" data-help="Return the tape to normal forward SPEED. This does not move the head — if you have reversed, you carry on playing forwards from wherever you are in the past. Use 'to live' for that.">1.0</button>
        <button id="t-live" data-help="Jump the tape head back to the present. Reverse leaves you behind live and normal speed never catches up, so this is how you come back.">to live</button>
      </span>
      <span class="tape-gap"></span>
      <span class="btns">
        <button id="t-rew" data-help="Hold to run backwards at 4x. Release and it resumes normal speed where it landed, like a real transport.">&#9664;&#9664; rew</button>
        <button id="t-ff" data-help="Hold to run forwards at 4x. It will reach live and stop there.">ff &#9654;&#9654;</button>
      </span>
      <span class="tape-gap"></span>
      <label class="tape-sublabel">speed</label>
      <input type="range" id="t-rate" class="tape-rate" min="-2" max="2" step="0.001" value="1"
        data-help="Tape speed, continuously variable. Negative is reverse, zero is a dead stop. Held above 1 it will catch up to live and stay there — you cannot play faster than the tabs are recording." />
      <span class="val" id="t-ratev">1.000</span>
      <span class="btns"><button id="t-interp" aria-pressed="false"
        data-help="Interpolation quality for off-speed playback. Cubic is smoother and costs slightly more CPU; the difference shows most at odd speeds.">cubic</button></span>
    </div>

    <div class="row row--pair">
      <label>stutter</label>
      <span class="btns">
        <button data-stut="0.06" data-help="Hold to loop the last 60ms. Release and it snaps back to live.">60ms</button>
        <button data-stut="0.125" data-help="Hold to loop the last 125ms. Release and it snaps back to live.">125ms</button>
        <button data-stut="0.25" data-help="Hold to loop the last 250ms. Release and it snaps back to live.">250ms</button>
        <button data-stut="0.5" data-help="Hold to loop the last 500ms. Release and it snaps back to live.">500ms</button>
      </span>
      <span class="tape-gap"></span>
      <label class="tape-sublabel">loop</label>
      <span class="btns">
        <button data-loop="1" data-help="Grab the last second and repeat it until you press off. The blue line on the waveform is where that second starts, so you can watch a phrase reach it and press then.">1s</button>
        <button data-loop="2" data-help="Grab the last two seconds and repeat them until you press off. Its line on the waveform marks where they start.">2s</button>
        <button data-loop="4" data-help="Grab the last four seconds and repeat them until you press off. Its line on the waveform marks where they start.">4s</button>
        <button data-loop="8" data-help="Grab the last eight seconds and repeat them until you press off. Its line on the waveform marks where they start.">8s</button>
        <button id="t-loopio" class="io" data-help="Tap a loop, in one button. Press once and the IN half lights: the start is marked and nothing changes yet, so you can listen on. Press again and OUT lights too — the loop closes there and repeats. Press a third time to drop it and mark a new start straight away. Off at any point.">
          <span class="io__in">in</span><span class="io__out">out</span>
        </button>
        <button id="t-loopoff" data-help="Stop looping and carry on from where the tape is.">off</button>
      </span>
    </div>`;

  // A local drag rather than video.js's `draggable`: that file loads AFTER this one, so
  // its function does not exist while this runs. Same behaviour, including the pointer
  // capture that keeps a drag tracking when it leaves the strip.
  const mfader = el.querySelector('#master-fader');
  const mfill = el.querySelector('#master-fill');
  let mdrag = false;
  const setMasterFromY = (e) => {
    const r = mfader.getBoundingClientRect();
    const frac = Math.max(0, Math.min(1, (r.bottom - e.clientY) / r.height));
    mfill.style.height = (frac * 100) + '%';
    Mixer.setMasterLevel(frac * 1.5);
  };
  mfader.addEventListener('pointerdown', (e) => {
    try { mfader.setPointerCapture(e.pointerId); } catch {}
    mdrag = true;
    setMasterFromY(e);
  });
  mfader.addEventListener('pointermove', (e) => { if (mdrag) setMasterFromY(e); });
  const mrel = () => { mdrag = false; };
  mfader.addEventListener('pointerup', mrel);
  mfader.addEventListener('pointercancel', mrel);
  // Unity is the position you want back most often, and it is not a place you can hit
  // reliably by dragging.
  mfader.addEventListener('dblclick', () => {
    Mixer.setMasterLevel(1);
    mfill.style.height = (100 / 1.5) + '%';
  });
  masterUi = {
    fill: mfill, l: el.querySelector('#mm-l'), r: el.querySelector('#mm-r'),
    dragging: () => mdrag,
  };
  mfill.style.height = (100 / 1.5) + '%';

  const rate = el.querySelector('#t-rate');
  const ratev = el.querySelector('#t-ratev');
  trackDrag(rate);
  const setRate = (v, glide) => {
    rate.value = String(v);
    ratev.textContent = Number(v).toFixed(3);
    tapeSet({ rate: Number(v), glide });
  };
  rate.addEventListener('input', () => setRate(rate.value, 0.01));

  const mode = (m) => {
    el.querySelector('#t-thru').setAttribute('aria-pressed', String(m === 'thru'));
    el.querySelector('#t-tape').setAttribute('aria-pressed', String(m === 'tape'));
    tapeSet({ mode: m });
  };
  el.querySelector('#t-thru').addEventListener('click', () => mode('thru'));
  el.querySelector('#t-tape').addEventListener('click', () => mode('tape'));

  // These only mean anything with the tape engaged, so engage it for them.
  //
  // The three of them are lit by refreshTape from the rate the tape reports, so
  // `aria-pressed` is both the light and the state — the same arrangement thru/tape
  // use. Set it here as well as there: refreshTape runs every 500ms, and a second
  // click inside that window would otherwise read the button as still off and
  // re-engage reverse instead of releasing it.
  const lit = (id, on) => el.querySelector(id).setAttribute('aria-pressed', String(on));

  // Reverse latches — that is the whole trap. It is the one transport state you
  // cannot see and cannot guess your way out of, so it toggles: a second click
  // returns to forward speed. It deliberately does NOT move the head. Reverse
  // changed the rate, so releasing it changes the rate back; you stay where you are
  // in the past, with `to live` still pulsing, because playing forwards from the
  // past is a real move and not something to undo behind someone's back.
  el.querySelector('#t-rev').addEventListener('click', () => {
    const on = el.querySelector('#t-rev').getAttribute('aria-pressed') !== 'true';
    mode('tape');
    lit('#t-rev', on); lit('#t-stop', false); lit('#t-play', !on);
    setRate(on ? -1 : 1, 0.02);
  });
  el.querySelector('#t-stop').addEventListener('click', () => {
    mode('tape');
    lit('#t-rev', false); lit('#t-stop', true); lit('#t-play', false);
    setRate(0, 0.02);
  });
  el.querySelector('#t-play').addEventListener('click', () => {
    mode('tape');
    lit('#t-rev', false); lit('#t-stop', false); lit('#t-play', true);
    setRate(1, 0.05);
  });

  el.querySelectorAll('[data-loop]').forEach((b) =>
    b.addEventListener('click', () => {
      mode('tape');
      tapeCmd('loopSecondsBack', Number(b.dataset.loop));
    }));
  el.querySelector('#t-loopio').addEventListener('click', () => tapeCmd('loopTap'));
  el.querySelector('#t-loopoff').addEventListener('click', () => tapeSet({ loopEnabled: false }));

  // Shuttle and stutter are momentary: held down they act, released they restore.
  const shuttle = (btn, rate) => {
    // Lit while held, like the stutter buttons beside them. A momentary control that
    // gives no sign it is doing anything is one you cannot tell you are still holding.
    const start = () => {
      mode('tape'); tapeSet({ rate, glide: 0.02 });
      btn.setAttribute('aria-pressed', 'true');
    };
    const stop = () => {
      tapeSet({ rate: 1, glide: 0.06 });
      btn.setAttribute('aria-pressed', 'false');
    };
    btn.addEventListener('pointerdown', start);
    btn.addEventListener('pointerup', stop);
    btn.addEventListener('pointerleave', stop);
    btn.addEventListener('pointercancel', stop);
  };
  el.querySelector('#t-rew').setAttribute('aria-pressed', 'false');
  el.querySelector('#t-ff').setAttribute('aria-pressed', 'false');
  shuttle(el.querySelector('#t-rew'), -4);
  shuttle(el.querySelector('#t-ff'), 4);
  el.querySelector('#t-live').addEventListener('click', () => tapeCmd('toLive'));

  el.querySelectorAll('[data-stut]').forEach((b) => {
    const seconds = Number(b.dataset.stut);
    const on = () => {
      mode('tape');
      Mixer.tapeCmd({ cmd: 'stutter', on: true, seconds });
      b.setAttribute('aria-pressed', 'true');
    };
    const off = () => {
      Mixer.tapeCmd({ cmd: 'stutter', on: false });
      b.setAttribute('aria-pressed', 'false');
    };
    b.addEventListener('pointerdown', on);
    b.addEventListener('pointerup', off);
    b.addEventListener('pointerleave', off);
    b.addEventListener('pointercancel', off);
  });

  const interp = el.querySelector('#t-interp');
  interp.addEventListener('click', () => {
    const cubic = interp.getAttribute('aria-pressed') !== 'true';
    interp.setAttribute('aria-pressed', String(cubic));
    tapeSet({ interp: cubic ? 'cubic' : 'linear' });
  });

  return { rate, ratev, state: el.querySelector('#t-state') };
}

// How far behind live counts as "you are in the past and may not have noticed".
// The standing tape latency is 0.25s, so this has to clear it comfortably without
// waiting for a gap big enough to be obvious on its own.
const LAG_WARN_SEC = 0.5;

let tapeUi = null;
// METERS MOVE AT ANIMATION RATE, AND THEY HAVE BALLISTICS.
//
// They used to be painted on whatever poll happened to own them — 700ms for a deck,
// 250ms for a tile, 500ms for the master — which is four or fourteen updates a second
// where the eye wants sixty. Beside a waveform redrawing at 60 the stepping is obvious,
// which is how Brendan noticed it.
//
// Rate alone would not have fixed it. A level reading jumps about by nature; a meter
// looks smooth because it RISES INSTANTLY and FALLS SLOWLY, which is what every physical
// meter does and what makes the motion readable rather than a flicker. Release is a time
// constant rather than a step per frame, so it falls at the same speed whatever the
// frame rate.
const RELEASE_MS = 320;
const meterHold = new Map();   // key -> the dB currently being shown
let meterLast = 0;

function ballistic(key, db, dtMs) {
  const target = db === null || db === undefined ? -60 : db;
  const prev = meterHold.get(key);
  if (prev === undefined || target >= prev) { meterHold.set(key, target); return target; }
  const k = Math.exp(-dtMs / RELEASE_MS);
  const v = target + (prev - target) * k;
  meterHold.set(key, v);
  return v;
}

const meterFrac = (db) => Math.max(0, Math.min(1, (db + 60) / 60));

// Looking an element up is not free sixty times a second, and neither is writing one
// that has not changed. Both were measured: reading every analyser every frame costs
// 1.5% of a core, and WRITING the meters cost 8.6% — so the cache and the change test
// below are where the saving is, not in the measuring.
const meterEls = new Map();   // tabId -> { deck, tile }
const meterShown = new Map(); // element key -> what was last written

// Cached, but with a short life. The first version kept whatever it found for ever and
// treated a MISS as a valid answer — so a lookup that ran before the deck was built
// cached `null` and that channel never got a meter again, and a tile built later when
// video mode opened was never picked up at all. A caught test, not a caught bug report.
//
// Half a second means at worst one stale frame after an element appears, at the cost of
// two queries per channel twice a second instead of sixty times.
const ELS_TTL_MS = 500;

function elsFor(tabId, now) {
  const e = meterEls.get(tabId);
  const live = (el) => !el || el.isConnected;
  if (e && now - e.at < ELS_TTL_MS && live(e.deck) && live(e.tile)) return e;
  const next = {
    at: now,
    deck: document.querySelector(`.deck[data-tab="${tabId}"] .deck__meter`),
    tile: document.querySelector(`.tile[data-tab="${tabId}"] .vmeter__fill`),
  };
  meterEls.set(tabId, next);
  return next;
}

// A meter is a few hundred pixels tall at most, so a change smaller than a tenth of a
// percent cannot be seen and is not worth writing at all.
//
// And it is written as a TRANSFORM, not a height: a height change forces style and
// layout, a transform is composited. Measured on four real captures, that one difference
// was 13.7% of a core.
function setHeight(el, key, pct) {
  if (!el) return;
  const prev = meterShown.get(key);
  if (prev !== undefined && Math.abs(prev - pct) < 0.1) return;
  meterShown.set(key, pct);
  el.style.transform = `scaleY(${(pct / 100).toFixed(4)})`;
}

function setText(el, key, text) {
  if (!el) return;
  if (meterShown.get(key) === text) return;
  meterShown.set(key, text);
  el.textContent = text;
}

function setLevel(el, key, state) {
  if (!el) return;
  if (meterShown.get(key) === state) return;
  meterShown.set(key, state);
  el.dataset.level = state;
}

// 'off' | 'read' | 'full'. Kept because it is how the cost of this was measured and how
// it would be measured again: it separates reading every analyser from writing what the
// reading says, which turned out to be 1.0% of a core against 8.6% before the cache and
// the change test below.
function paintMeters(now) {
  if (window.__meterMode === 'off') return;
  const dt = meterLast ? Math.min(100, now - meterLast) : 16;
  meterLast = now;
  const lv = Mixer.levels();
  if (!lv || !lv.ok) return;
  if (window.__meterMode === 'read') return;

  for (const c of lv.channels || []) {
    const shown = ballistic('ch' + c.tabId, c.db, dt);
    // Both layouts, found by the tab they belong to rather than through whichever
    // module happens to own the element — so there is ONE painter and no chance of two
    // of them fighting over the same pixels at different rates.
    const e = elsFor(c.tabId, now);
    const st = c.state || 'ok';
    setText(e.deck, 'dt' + c.tabId, fmtDb(shown) + ' dB');
    setLevel(e.deck, 'dl' + c.tabId, st);
    setHeight(e.tile, 'th' + c.tabId, +(meterFrac(shown) * 100).toFixed(1));
    setLevel(e.tile, 'tl' + c.tabId, st);
  }

  if (masterUi) {
    setHeight(masterUi.l, 'ml', +(meterFrac(ballistic('outL', lv.outL, dt)) * 100).toFixed(1));
    setHeight(masterUi.r, 'mr', +(meterFrac(ballistic('outR', lv.outR, dt)) * 100).toFixed(1));
    setLevel(masterUi.l, 'mll', lv.outLState || 'ok');
    setLevel(masterUi.r, 'mrl', lv.outRState || 'ok');
  }
}

// Thirty a second, like the waveform. Sixty was chosen because meters are the one thing
// smoothness is the whole point of — but with ballistics doing the smoothing, thirty is
// indistinguishable and halves whatever this costs.
const METER_MS = 33;
let meterFrame = 0;
function meterLoop(now) {
  if (now - meterFrame >= METER_MS) { meterFrame = now; paintMeters(now); }
  requestAnimationFrame(meterLoop);
}
requestAnimationFrame(meterLoop);

// Set from buildTape, read by refreshTape. The master strip is part of the tape, so it
// is repainted on the tape's clock rather than the deck list's.
let masterUi = null;

function refreshMaster() {
  if (!masterUi) return;
  const st = Mixer.state();
  // The meters either side of it are painted by paintMeters at animation rate; this
  // only has to keep the FADER in step with the graph.
  // Never fight a finger that is on it.
  if (!masterUi.dragging() && typeof st.masterLevel === 'number') {
    masterUi.fill.style.height = ((st.masterLevel / 1.5) * 100) + '%';
  }
}

async function refreshTape() {
  refreshMaster();
  const q = await tapeQuery();
  const ready = !!(q && q.ok);

  // Don't let the tape look engaged before there is anything to tape.
  const el = document.getElementById('tape');
  el.classList.toggle('idle', !ready);
  el.querySelectorAll('input,button').forEach((n) => (n.disabled = !ready));
  if (!ready) {
    el.querySelectorAll('[aria-pressed]').forEach((n) =>
      n.setAttribute('aria-pressed', String(n.id === 't-thru')));
    el.classList.remove('lagged');
    el.querySelector('#t-live').classList.remove('urgent');
    tapeUi.state.textContent = 'Tape idle — add a channel first.';
    return;
  }

  // Reflect the worklet's actual state — the tape can be driven from the console
  // or by a gesture, so the buttons must follow it rather than only their own clicks.
  el.querySelector('#t-thru').setAttribute('aria-pressed', String(q.mode === 'thru'));
  el.querySelector('#t-tape').setAttribute('aria-pressed', String(q.mode === 'tape'));
  el.querySelector('#t-interp').setAttribute('aria-pressed', String(q.interp === 'cubic'));
  tapeLoopPaint(q);

  // Which way the transport is running, as a light rather than as a number you have
  // to read. Reverse in particular latched invisibly: a tape running at -1 looked
  // exactly like one running at +1, so the only way out was to already know that
  // '1.0' would do it.
  //
  // Driven by the reported rate, not by which button was last clicked, so the
  // console, MIDI and the speed slider all keep it honest. At an in-between speed
  // none of the three light — the slider owns the rate and should look like it.
  // Gated on tape mode because these are tape-only states, and because the worklet
  // only updates its reported rate inside the tape branch.
  const at = (v) => q.mode === 'tape' && Math.abs(q.rate - v) < 0.02;
  el.querySelector('#t-rev').setAttribute('aria-pressed', String(at(-1)));
  el.querySelector('#t-stop').setAttribute('aria-pressed', String(at(0)));
  el.querySelector('#t-play').setAttribute('aria-pressed', String(at(1)));

  if (dragging !== tapeUi.rate) {
    tapeUi.rate.value = String(q.rate);
    tapeUi.ratev.textContent = Number(q.rate).toFixed(3);
  }
  // Being behind live is the tape's most confusing state, because nothing about the
  // sound says so — you just hear the mix as it was N seconds ago, and changes you
  // make now arrive later. Reverse opens the gap at 2s per second held (the head
  // walks back while live runs on) and NORMAL SPEED NEVER CLOSES IT: at rate 1.0 the
  // heads move in lockstep. Only 'to live', 'thru', a stutter release or a speed
  // above 1 bring you back. So say so loudly rather than in the status line.
  const lagged = q.mode === 'tape' && q.behindLiveSec > LAG_WARN_SEC;
  el.classList.toggle('lagged', lagged);
  el.querySelector('#t-live').classList.toggle('urgent', lagged);

  tapeUi.state.textContent =
    `${q.mode} · ${q.interp} · ${q.behindLiveSec.toFixed(2)}s behind live · ` +
    `${q.secondsRecorded.toFixed(0)}/${q.bufferSeconds}s recorded` +
    (q.loopEnabled ? ` · loop ${q.loopLenSec.toFixed(2)}s` : '');
}

// ---------------------------------------------------------------- midi targets

// Everything MIDI can drive, in one table so midi.js needs no knowledge of the UI.
// `set` takes a normalised 0..1 and does the range mapping; `type` tells the learn
// UI whether a control expects a continuous value or a press.
const MIDI_TARGETS = {
  'deck:level': {
    type: 'range', label: 'level',
    set: (tabId, v, p) => { const x = v * 1.5; setGain(tabId, x); if (p) { p.level.value = String(x); p.lvlv.textContent = x.toFixed(2); } },
  },
  'deck:pan': {
    type: 'range', label: 'pan',
    set: (tabId, v, p) => { const x = v * 2 - 1; setPan(tabId, x); if (p) { p.pan.value = String(x); p.panv.textContent = fmtPan(x); } },
  },
  'deck:rate': {
    type: 'range', label: 'rate',
    set: (tabId, v, p) => {
      const x = 0.25 + v * 2.25;
      toContent(tabId, {
        type: 'SET_RATE', rate: x,
        preservesPitch: !p || p.pitch.getAttribute('aria-pressed') === 'true',
      });
      if (p) { p.rate.value = String(x); p.ratev.textContent = x.toFixed(3); }
    },
  },
  'deck:mute': { type: 'press', label: 'mute', press: (tabId) => setMute(tabId) },
  'deck:solo': { type: 'press', label: 'solo', press: (tabId) => setSolo(tabId, undefined, true) },
  'tape:rate': {
    type: 'range', label: 'tape speed',
    set: (_t, v) => {
      const x = -2 + v * 4;
      tapeSet({ rate: x, glide: 0.01 });
      const s = document.getElementById('t-rate');
      if (s && dragging !== s) {
        s.value = String(x);
        document.getElementById('t-ratev').textContent = x.toFixed(3);
      }
    },
  },
};

// Apply a normalised value to a target id like "deck:2:level" or "tape:rate".
// Returns false when the target does not currently exist (deck removed, say), which
// is not an error — a mapping simply does nothing until that deck is back.
function midiApply(targetId, value01, isPress) {
  const bits = targetId.split(':');
  if (bits[0] === 'tape') {
    const t = MIDI_TARGETS['tape:' + bits[1]];
    if (!t) return false;
    if (t.type === 'press') { if (isPress) t.press(null); } else t.set(null, value01);
    return true;
  }
  const index = Number(bits[1]);
  const tabId = deckOrder[index];
  if (tabId === undefined) return false;
  const t = MIDI_TARGETS['deck:' + bits[2]];
  if (!t) return false;
  const d = decks.get(tabId);
  const p = d && d.parts;
  // Don't fight the mouse: a control being dragged wins over incoming MIDI.
  if (t.type === 'press') { if (isPress) t.press(tabId); return true; }
  if (p && dragging === p[bits[2]]) return true;
  t.set(tabId, value01, p);
  return true;
}

function midiTargetLabel(targetId) {
  const bits = targetId.split(':');
  if (bits[0] === 'tape') return 'tape ' + (MIDI_TARGETS['tape:' + bits[1]]?.label || bits[1]);
  const t = MIDI_TARGETS['deck:' + bits[2]];
  return `deck ${Number(bits[1]) + 1} ${t ? t.label : bits[2]}`;
}

// ---------------------------------------------------------------- help switch

function initHelp() {
  const manual = document.getElementById('manual-btn');
  if (manual) manual.addEventListener('click', () => openManual());

  const btn = document.getElementById('help-switch');
  const tip = document.getElementById('help-tip');
  let on = localStorage.getItem('ym-help') === '1';

  const apply = () => {
    btn.setAttribute('aria-pressed', String(on));
    document.body.classList.toggle('help-on', on);
    if (!on) tip.classList.remove('on');
  };

  btn.addEventListener('click', () => {
    on = !on;
    localStorage.setItem('ym-help', on ? '1' : '0');
    apply();
  });

  const show = (target) => {
    if (!on) return;
    const el = target && target.closest && target.closest('[data-help]');
    if (!el) { tip.classList.remove('on'); return; }
    tip.textContent = el.getAttribute('data-help');
    tip.classList.add('on');

    // Sit under the element, nudged back inside the viewport if it would overflow.
    const r = el.getBoundingClientRect();
    const t = tip.getBoundingClientRect();
    let left = r.left;
    let top = r.bottom + 6;
    if (left + t.width > window.innerWidth - 8) left = window.innerWidth - t.width - 8;
    if (top + t.height > window.innerHeight - 8) top = r.top - t.height - 6;
    tip.style.left = Math.max(8, left) + 'px';
    tip.style.top = Math.max(8, top) + 'px';
  };

  // Delegated, so controls built later (decks appear and disappear) are covered
  // without rebinding. focusin as well as hover keeps it reachable by keyboard.
  document.addEventListener('pointerover', (e) => show(e.target));
  document.addEventListener('focusin', (e) => show(e.target));
  document.addEventListener('pointerleave', () => tip.classList.remove('on'), true);

  apply();
}

// ---------------------------------------------------------------- boot

// Straight from the manifest, so the number on screen is always the build actually
// running. Chrome keeps an unpacked extension loaded from its original folder, so a
// stale copy is easy to be running without knowing — this is how you tell.
document.getElementById('app-version').textContent =
  chrome.runtime.getManifest().version;

tapeUi = buildTape();
initHelp();
refresh();
refreshTape();
setInterval(refresh, 700);
setInterval(refreshTape, 500);

// Kept for console use and the CDP drivers.
Object.assign(window, {
  openManual,
  manualUrl: () => chrome.runtime.getURL('manual.html'),
  // Ask any channel what it is made of. Returns the same report the note copies.
  quodlibetProbe: probeTab,
  quodlibetRevive: (tabId) => revived.get(tabId) || null,
  mixerTabs: listTabs, mixerAdd: addChannel, mixerState: getState,
  mixerLevels: getLevels, mixerGain: setGain, mixerDrop: dropChannel,
  mixerMute: setMute, mixerSolo: setSolo, mixerPan: setPan,
  mixerRefresh: refresh,
  mixerSetTitle: (tabId, title) => Mixer.setTitle(tabId, title),
  tapeSet, tapeCmd, tapeQuery,
  tapeOn: () => tapeSet({ mode: 'tape' }),
  tapeThru: () => tapeSet({ mode: 'thru' }),
  tapeRate: (rate, glide) => tapeSet({ rate, glide }),
  tapeLoop: (seconds) => tapeCmd('loopSecondsBack', seconds),
  tapeLoopIn: () => tapeCmd('loopIn'),
  tapeLoopOut: () => tapeCmd('loopOut'),
  tapeLoopTap: () => tapeCmd('loopTap'),
  tapeLoopPaint,
  meterPaintMode: (m) => { window.__meterMode = m; return m; },
  tapeLoopOff: () => tapeSet({ loopEnabled: false }),
  tapeInterp: (interp) => tapeSet({ interp }),
  tapeStutter: (on, seconds) => Mixer.tapeCmd({ cmd: 'stutter', on, seconds }),
  tapeToLive: () => tapeCmd('toLive'),
  testTone: (on, hz) => Mixer.testTone({ on, hz }),
  probe: () => Mixer.probe(),
  probeTones: (hz) => Mixer.probeTones(hz),
  deckInfo: (tabId) => toContent(tabId, { type: 'INFO' }),
  deckRate: (tabId, rate, preservesPitch) =>
    toContent(tabId, { type: 'SET_RATE', rate, preservesPitch }),
  deckVolume: (tabId, volume, muted) => toContent(tabId, { type: 'SET_VOLUME', volume, muted }),
  deckSeek: (tabId, absolute, delta) => toContent(tabId, { type: 'SEEK', absolute, delta }),
  deckPlay: (tabId) => toContent(tabId, { type: 'PLAY' }),
  deckPause: (tabId) => toContent(tabId, { type: 'PAUSE' }),
  testChannel: (o) => Mixer.testChannel(o),
  mixerVideo: (on) => Mixer.setVideoEnabled(on),
  mixerStream: (tabId) => Mixer.getStream(tabId),
  mixerReady: true,
});
