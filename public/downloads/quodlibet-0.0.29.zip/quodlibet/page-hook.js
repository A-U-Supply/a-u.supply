// Main-world hook: reaches media elements that are not in the document.
//
// Measured on soundcloud.com, 2026-08-18: `document.querySelectorAll('video,audio')`
// returns 0, no shadow root holds one, and no same-origin frame holds one either —
// while the element the page is actually driving reports `isConnected: false` with a
// real duration. SoundCloud plays through an `new Audio()` that is never inserted into
// the page. querySelectorAll cannot see such an element and nothing enumerates
// detached nodes, so the only way to get a reference is to be there when the page
// touches one.
//
// Hence a prototype patch, and hence the MAIN world: an isolated content script has
// its own HTMLMediaElement.prototype, and patching that one intercepts nothing,
// because the page never calls through it.
//
// This file is the fallback, not the main road. content.js still drives an element it
// can find in the document, which keeps YouTube on exactly the path it has always
// been on; the bridge below is only asked when that search comes back empty.

(() => {
  // Bumped when this file's behaviour changes, and reported by the probe. Not
  // cosmetic: it is how a stale copy becomes visible instead of inferred. A Netflix
  // report showed `driving.drm` present and `hook.best.drm` missing — two halves of
  // one build disagreeing, because the guard below used to refuse to upgrade.
  const BUILD = '0.0.28-hook-9';

  // Upgrade in place rather than refusing to run.
  //
  // The first version returned early when it found itself already installed, so a
  // newer file injected into a tab that already had an older one did nothing at all
  // until the tab happened to navigate. The prototype patches genuinely must only
  // happen once — patching a patch grows the call chain on a hot path — but the
  // handler must be replaceable, and what has been seen must survive the swap.
  const KEY = '__quodlibetHook';
  const prev = window[KEY] && typeof window[KEY] === 'object' ? window[KEY] : null;
  if (prev && prev.listener) document.removeEventListener('quodlibet-req', prev.listener);

  // WeakRefs, because this outlives every element it sees. A Set of media elements on
  // a page that starts a new one per track is a leak with a long session behind it.
  // The array is carried across upgrades: the old patches close over it, so reusing
  // the same object is what keeps an already-registered element registered.
  const MARK = Symbol.for('quodlibet.seen');
  const state0 = prev || { refs: [], contexts: 0, patched: false };
  const refs = state0.refs;

  function remember(el) {
    if (!el || el[MARK]) return;
    try { el[MARK] = true; } catch { return; }
    refs.push(new WeakRef(el));
    if (refs.length > 24) refs.splice(0, refs.length - 24);
  }

  function best() {
    const pool = [];
    for (const r of refs) {
      const el = r.deref();
      // Not merely alive: an element the page has finished with reports readyState 0
      // with no source, and picking it would drive nothing while looking like success.
      if (el && (el.currentSrc || el.src || el.readyState > 0)) pool.push(el);
    }
    if (!pool.length) return null;
    // THE SAME RULE `content.js` USES, and it has to stay the same rule: two pickers
    // that can disagree about which element the tab IS will disagree, and then half the
    // extension drives one and half reads the other.
    //
    // MEASURED in the field: a YouTube watch page carries TWO
    // <video class="html5-main-video">, both connected, both readyState 4, both
    // duration 2558 — the real one, and a decoy parked at currentTime 0 with 5.9s
    // buffered. Sorting by duration TIES between them, so the decoy won whenever
    // nothing was playing, which is precisely what pausing a tab does. The lookahead
    // then anchored its block to the decoy's buffered end of 5.9s while the real head
    // sat at 29.9s, and drew 90s of real audio 24s adrift and marching on wall-clock
    // time. The main player is the one with a picture, so rank by rendered area.
    const area = (el) => (el.clientWidth || 0) * (el.clientHeight || 0);
    const sized = pool.filter((el) => area(el) > 0);
    if (sized.length) return sized.sort((a, b) => area(b) - area(a))[0];
    // Nothing is drawn at all, so this is an audio-only page — SoundCloud and Bandcamp
    // drive a 0x0 element and area cannot rank them. Take what is playing, then the
    // longest, which is the old rule and still the right one here.
    const playing = pool.filter((el) => !el.paused && el.readyState >= 2);
    const from = playing.length ? playing : pool;
    return from.sort((a, b) => (b.duration || 0) - (a.duration || 0))[0];
  }

  // Registration hangs off the `currentTime` getter, not off play().
  //
  // A player UI reads currentTime continuously to draw its own progress bar, so an
  // element that was already playing when we arrived registers within a frame. Off
  // play() alone it would register only when you next pressed pause and play in the
  // tab — the controls would sit there dead until you performed a ritual nobody told
  // you about. play/pause/load are patched too, for a page that is paused when we
  // arrive and reads nothing until it starts.
  const desc = state0.patched
    ? null
    : Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'currentTime');
  if (desc && desc.get && desc.set) {
    Object.defineProperty(HTMLMediaElement.prototype, 'currentTime', {
      configurable: desc.configurable,
      enumerable: desc.enumerable,
      get() { remember(this); return desc.get.call(this); },
      set(v) { remember(this); return desc.set.call(this, v); },
    });
  }
  if (!state0.patched) {
    for (const name of ['play', 'pause', 'load']) {
      const orig = HTMLMediaElement.prototype[name];
      if (typeof orig !== 'function') continue;
      HTMLMediaElement.prototype[name] = function (...args) {
        remember(this);
        return orig.apply(this, args);
      };
    }
  }

  // Whether the page has a Web Audio graph at all. This is the discriminator for the
  // one cause nothing can fix: a page playing through an AudioContext with no media
  // element behind it has nothing to set playbackRate on, and no amount of hooking
  // will produce one. Counting constructions is the only way to know from here.
  if (!state0.patched) {
    for (const name of ['AudioContext', 'webkitAudioContext']) {
      const Orig = window[name];
      if (typeof Orig !== 'function') continue;
      const Wrapped = function (...args) { state0.contexts++; return new Orig(...args); };
      Wrapped.prototype = Orig.prototype;
      try { Object.defineProperty(window, name, { value: Wrapped, writable: true, configurable: true }); }
      catch { /* frozen window, not worth failing over */ }
    }
  }

  // What the panel is allowed to know and do. Deliberately the same verbs content.js
  // already answers, so the caller does not care which side of the world it reached.
  function state(el) {
    return {
      ok: true,
      kind: el.tagName.toLowerCase(),
      connected: el.isConnected,
      playbackRate: el.playbackRate,
      preservesPitch: el.preservesPitch,
      volume: el.volume,
      muted: el.muted,
      currentTime: el.currentTime,
      duration: Number.isFinite(el.duration) ? el.duration : null,
      paused: el.paused,
      readyState: el.readyState,
      drm: !!el.mediaKeys,
    };
  }

  function handle(msg) {
    // The probe answers whether or not there is anything to drive — its job is to
    // explain the empty case.
    if (msg.type === 'PROBE') {
      const el = best();
      let live = 0;
      for (const r of refs) if (r.deref()) live++;
      return {
        ok: true,
        build: BUILD,
        seen: refs.length,
        live,
        audioContexts: state0.contexts,
        best: el ? { kind: el.tagName.toLowerCase(), connected: el.isConnected,
                     duration: Number.isFinite(el.duration) ? el.duration : null,
                     paused: el.paused, readyState: el.readyState,
                     drm: !!el.mediaKeys } : null,
      };
    }

    // Arming patches MediaSource; it has nothing to do with having found an element
    // yet, and refusing it because one has not been seen means arming fails in exactly
    // the moment it matters — right after injection, before the page has next read
    // currentTime and registered itself.
    if (msg.type === 'AHEAD_ARM') { armLookahead(); return { ok: true, armed: ahead.armed }; }
    if (msg.type === 'AHEAD') return aheadReply();

    const el = best();
    if (!el) return { ok: false, reason: 'no media element' };
    try {
      switch (msg.type) {
        case 'INFO':
          break;
        case 'SET_RATE':
          if (msg.preservesPitch !== undefined) el.preservesPitch = !!msg.preservesPitch;
          el.playbackRate = msg.rate;
          break;
        case 'SET_VOLUME':
          if (msg.volume !== undefined) el.volume = Math.max(0, Math.min(1, msg.volume));
          if (msg.muted !== undefined) el.muted = !!msg.muted;
          break;
        case 'SEEK':
          // Same refusal as content.js: an EME player manages its own buffer and a
          // seek written underneath it can put the page into an unrecoverable error.
          if (el.mediaKeys) return { ...state(el), seekRefused: 'protected stream' };
          if (msg.absolute !== undefined) el.currentTime = msg.absolute;
          else if (msg.delta !== undefined) el.currentTime = el.currentTime + msg.delta;
          break;
        case 'PLAY':
          el.play().catch(() => {});
          break;
        case 'PAUSE':
          el.pause();
          break;
        default:
          return { ok: false, reason: 'unknown ' + msg.type };
      }
      return state(el);
    } catch (e) {
      return { ok: false, error: String((e && e.message) || e) };
    }
  }

  // ---- LOOKAHEAD -----------------------------------------------------------------
  //
  // What a source is ABOUT to play. A tab capture can only ever give us audio that has
  // already been heard, but YouTube streams over MSE and hands the player twenty to
  // thirty seconds of audio before it is due — measured 22-34s across runs. That is a
  // real future and it is already in the page.
  //
  // Measured facts this rests on, all from spikes rather than assumption:
  //   * the audio SourceBuffer is `audio/webm; codecs="opus"`; decodeAudioData reads the
  //     accumulated bytes with no demuxer and no init-segment surgery
  //   * JOINING LATE IS FATAL on its own: without the init segment nothing decodes, and
  //     Quodlibet always joins late because capture starts from a toolbar click on a tab
  //     that is already playing. A re-init is the only recovery.
  //   * a re-init costs one `waiting`/`seeking`/`playing`, measured at 0.34s — AND IS
  //     ALREADY BEING PAID, because setting a captured tab's decode quality triggers it.
  //     This rides on that rather than adding a second interruption.
  //   * the decoded block places onto the media timeline to within 10ms: the media time
  //     of the first chunk kept, plus the decoded duration, equals `buffered.end`.
  //
  // The envelope is computed HERE and only the envelope crosses to the panel. The bytes
  // are megabytes; a peak per 10ms is a few kilobytes, and the bridge is a JSON string.
  const AHEAD_HZ = 100;
  // NINETY SECONDS OF AUDIO, not twelve minutes. This was 12e6 — about twelve minutes
  // of Opus — and every three seconds the whole lot was concatenated and decoded, which
  // is ~280MB of float32 per decode. MEASURED in the wild: one captured tab at 82.6%
  // CPU and climbing through half a gigabyte while three others doing the same job sat
  // at 5%. The lookahead only ever needs the ~30s the player has buffered; the rest was
  // being decoded over and over so it could be thrown away.
  const AHEAD_MAX_BYTES = 1.5e6;

  // WHICH BUFFER IS THE AUDIO ONE, WHEN WE NEVER SAW IT BEING MADE.
  //
  // Tagging inside a patched `addSourceBuffer` only works if we were patched in before
  // the player built its buffers — and Quodlibet is NEVER patched in first. It joins a
  // tab that is already playing, by design, because capture starts from a toolbar click
  // on something you are already listening to. So every SourceBuffer on a real capture
  // is one we did not see created, carries no tag, and every append on it was ignored.
  // MEASURED in the field: armed true, appends flowing, `chunks: 0`.
  //
  // (The spike that proved all this worked precisely because the hook went in before
  // the video started. That is the difference between a spike and the real path, and it
  // is the half of "does joining late still work?" that went unanswered.)
  //
  // So the tag comes from the BYTES. An init segment names its own codec: WebM carries
  // a CodecID string like `A_OPUS` or `V_VP9`, fragmented MP4 an `hdlr` of `soun` or
  // `vide`. Once a buffer has identified itself, every cluster after it is known.
  function hasAscii(u8, str, limit) {
    const n = Math.min(u8.length, limit) - str.length;
    outer: for (let i = 0; i <= n; i++) {
      for (let j = 0; j < str.length; j++) if (u8[i + j] !== str.charCodeAt(j)) continue outer;
      return true;
    }
    return false;
  }

  function sniffKind(u8) {
    if (!looksLikeInit(u8)) return null;
    const L = 8192;   // the codec is named in the header, near the front
    if (hasAscii(u8, 'A_OPUS', L) || hasAscii(u8, 'A_VORBIS', L) || hasAscii(u8, 'A_AAC', L)) return 'audio';
    if (hasAscii(u8, 'V_VP8', L) || hasAscii(u8, 'V_VP9', L) || hasAscii(u8, 'V_AV1', L)) return 'video';
    if (hasAscii(u8, 'soun', L)) return 'audio';
    if (hasAscii(u8, 'vide', L)) return 'video';
    return null;
  }

  // An init segment, which is the only thing that makes any of the rest decodable.
  // WebM opens with the EBML header; fragmented MP4 opens with an `ftyp` box.
  function looksLikeInit(u8) {
    if (u8.length >= 4 && u8[0] === 0x1a && u8[1] === 0x45 && u8[2] === 0xdf && u8[3] === 0xa3) return true;
    return u8.length >= 8 && u8[4] === 0x66 && u8[5] === 0x74 && u8[6] === 0x79 && u8[7] === 0x70;
  }
  const ahead = (state0.ahead = prev && prev.ahead ? prev.ahead : {
    armed: false, types: new Map(), chunks: [], startMedia: null,
    env: null, envStartMedia: null, decoding: false, lastDecode: 0, err: null,
  });

  function armLookahead() {
    if (ahead.armed) return;
    ahead.armed = true;
    // PATCH ONCE, EVER. The flag above makes arming idempotent, but the flag lives on a
    // state object and the patched prototypes live on the realm — so anything that
    // resets the one without the other wraps a wrapper, and every append is then
    // recorded twice. That reads as twice as much buffered audio and decodes to
    // nonsense. The mark goes on the function, because the function is what would be
    // doubled. (Caught by a test that reset the flag; the same shape as content.js's
    // listener guard, and there for the same reason.)
    if (SourceBuffer.prototype.appendBuffer.__qlAhead) return;
    try {
      const origAdd = MediaSource.prototype.addSourceBuffer;
      MediaSource.prototype.addSourceBuffer = function (type) {
        const sb = origAdd.apply(this, arguments);
        try { if (/audio/i.test(type)) sb.__qlAudio = true; } catch {}
        return sb;
      };
      const origAppend = SourceBuffer.prototype.appendBuffer;
      SourceBuffer.prototype.appendBuffer = function (data) {
        try {
          const u0 = data instanceof ArrayBuffer
            ? new Uint8Array(data)
            : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
          // Every append, tagged or not — so a report can tell "this tab is not
          // streaming that way at all" apart from "we are not recognising its buffers",
          // which look identical from the panel and need opposite fixes.
          ahead.appends = (ahead.appends || 0) + 1;
          if (this.__qlAudio === undefined) {
            const kind = sniffKind(u0);
            if (kind) {
              this.__qlAudio = kind === 'audio';
              ahead.sniffed = (ahead.sniffed || 0) + 1;
            }
          }
        } catch {}
        try {
          // Nothing to hold: see fmp4Encrypted. `appends` above still counts, so the
          // reply can still say what the tab is doing.
          if (this.__qlAudio && !ahead.encrypted) {
            const u8 = data instanceof ArrayBuffer
              ? new Uint8Array(data)
              : new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
            // THE INIT SEGMENT IS THE ONE CHUNK THAT CANNOT BE DROPPED, and both of
            // the rules below exist because of it.
            //
            // A previous version dropped from the FRONT once it hit its cap — which is
            // the front chunk, which is the init segment, so the buffer went
            // undecodable and STAYED undecodable until the player happened to
            // re-initialise on its own. That is the bug Brendan hit: nothing for
            // minutes, then a future appearing out of nowhere. Before that it dropped
            // from the back, which froze the future instead. Neither end is the answer:
            // the init is pinned and the OLDEST MEDIA chunk goes.
            const init = looksLikeInit(u8);
            let kept = true;
            if (init) {
              // A fresh one supersedes everything: the player has re-initialised and
              // the clusters that follow belong to this header, not the last.
              ahead.chunks = [u8.slice()];
              ahead.sawInit = true;
            } else if (!ahead.sawInit) {
              // JOINING LATE NEVER DECODES. Clusters with no header in front of them
              // are not audio we can read, and keeping them only spends memory and
              // decode time to fail. Wait for a header instead.
              //
              // A FLAG RATHER THAN AN EARLY RETURN: the real appendBuffer is called
              // below, OUTSIDE this try, so that a genuine SourceBuffer error still
              // reaches the page's own error handling instead of being swallowed here.
              ahead.waiting = true;
              kept = false;
            } else {
              ahead.chunks.push(u8.slice());
            }
            if (kept) {
              ahead.waiting = false;
              ahead.appended = (ahead.appended || 0) + u8.length;
            }

            let held = 0;
            for (const c of ahead.chunks) held += c.byteLength;
            // From index 1, so chunks[0] — the header — always survives. Keeps at
            // least one media chunk with it, so there is always something to decode.
            while (held > AHEAD_MAX_BYTES && ahead.chunks.length > 2) {
              held -= ahead.chunks.splice(1, 1)[0].byteLength;
              ahead.trimmed = true;
            }
          }
        } catch {}
        return origAppend.apply(this, arguments);
      };
      SourceBuffer.prototype.appendBuffer.__qlAhead = true;
      MediaSource.prototype.addSourceBuffer.__qlAhead = true;
    } catch (e) { ahead.err = String((e && e.message) || e); }
  }

  // ---- FRAGMENTED MP4 / AAC, VIA WEBCODECS -----------------------------------------
  //
  // YouTube does not always serve Opus in WebM. Some tabs get AAC in fragmented MP4 —
  // and `decodeAudioData` WILL NOT READ IT. Measured 2026-08-25 on a real captured tab:
  // not the whole held buffer, not one complete `moof`+`mdat` pair, not the header
  // alone, all "Unable to decode audio data", with the bytes provably intact (a
  // top-level box walk ran ftyp/moov/9x(moof+mdat) and landed exactly on the final
  // byte) and rebasing every `tfdt` to zero making no difference either. It is not
  // truncation and not the fragment start time: that decoder simply will not take this
  // shape of file.
  //
  // WebCodecs will, but only frame by frame — so the fragments have to be taken apart
  // here: the AAC config out of `moov`, then each sample out of `mdat` per the `trun`
  // table, handed to an `AudioDecoder` as an `EncodedAudioChunk`.
  const u32be = (b, p) => ((b[p] << 24) >>> 0) + (b[p + 1] << 16) + (b[p + 2] << 8) + b[p + 3];
  const boxType = (b, p) => String.fromCharCode(b[p + 4], b[p + 5], b[p + 6], b[p + 7]);
  const isBoxName = (t) => /^[a-zA-Z0-9 ]{4}$/.test(t);

  // The children of one box, at one level.
  function childBoxes(b, from, to) {
    const out = [];
    let p = from;
    while (p + 8 <= to) {
      const size = u32be(b, p);
      const type = boxType(b, p);
      if (size < 8 || p + size > to || !isBoxName(type)) break;
      out.push({ type, start: p, size, body: p + 8, end: p + size });
      p += size;
    }
    return out;
  }
  // Follow a path of box names down from a range, e.g. ['moov','trak','mdia'].
  function descend(b, from, to, path) {
    let range = { body: from, end: to };
    for (const name of path) {
      const hit = childBoxes(b, range.body, range.end).find((x) => x.type === name);
      if (!hit) return null;
      range = hit;
    }
    return range;
  }
  function findAscii(b, str, from) {
    outer: for (let i = from; i <= b.length - str.length; i++) {
      for (let j = 0; j < str.length; j++) if (b[i + j] !== str.charCodeAt(j)) continue outer;
      return i;
    }
    return -1;
  }

  // The AudioSpecificConfig, which is what AudioDecoder needs as its `description`, and
  // which lives at the bottom of a chain of MPEG-4 descriptors inside `esds`.
  function ascFromEsds(b, from, to) {
    let p = from + 4;                       // the esds full box's version and flags
    const len = () => { let v = 0, n = 0, x; do { x = b[p++]; v = (v << 7) | (x & 0x7f); } while ((x & 0x80) && ++n < 4); return v; };
    while (p < to) {
      const tag = b[p++];
      const size = len();
      if (tag === 0x03) {                   // ES_Descriptor: skip its header, keep walking
        p += 2;
        const flags = b[p++];
        if (flags & 0x80) p += 2;
        if (flags & 0x40) p += 1 + b[p];
        if (flags & 0x20) p += 2;
        continue;
      }
      if (tag === 0x04) { p += 13; continue; }   // DecoderConfigDescriptor, then nested
      if (tag === 0x05) return b.slice(p, p + size);   // DecoderSpecificInfo — the ASC
      p += size;
    }
    return null;
  }

  // Sample rate, channel count and codec, from the `moov` that opens the buffer.
  function fmp4Config(b) {
    const moov = childBoxes(b, 0, b.length).find((x) => x.type === 'moov');
    if (!moov) return null;
    const stsd = descend(b, moov.body, moov.end, ['trak', 'mdia', 'minf', 'stbl', 'stsd']);
    const mdhd = descend(b, moov.body, moov.end, ['trak', 'mdia', 'mdhd']);
    if (!stsd || !mdhd) return null;
    const entry = childBoxes(b, stsd.body + 8, stsd.end)[0];   // version/flags + entry count
    if (!entry) return null;
    // AudioSampleEntry: 6 reserved, 2 data ref, 8 reserved, then channels, sample size,
    // 4 predefined/reserved, and the sample rate as 16.16 fixed point.
    const channels = (b[entry.body + 16] << 8) + b[entry.body + 17];
    const sampleRate = (b[entry.body + 24] << 8) + b[entry.body + 25];
    const esds = childBoxes(b, entry.body + 28, entry.end).find((x) => x.type === 'esds');
    const asc = esds ? ascFromEsds(b, esds.body, esds.end) : null;
    if (!asc || !asc.length) return null;
    // The audio object type is the top five bits of the config: 2 is AAC-LC, 5 is HE-AAC.
    const aot = asc[0] >> 3;
    const timescale = u32be(b, mdhd.body + (b[mdhd.body] === 1 ? 20 : 12));
    return { asc, channels: channels || 2, sampleRate: sampleRate || 44100,
             codec: 'mp4a.40.' + (aot > 0 && aot < 31 ? aot : 2), timescale: timescale || sampleRate || 44100 };
  }

  // ENCRYPTED AUDIO, WHICH IS A DIFFERENT ANSWER FROM "WE CANNOT DECODE IT".
  //
  // MEASURED on a real YouTube movie tab, 2026-08-25: sample entry `enca` rather than
  // `mp4a`, a `sinf` beside the `esds`, and two `pssh` boxes in the `moov`. Those samples
  // are ciphertext. No decoder reads them — not decodeAudioData, not WebCodecs, not with
  // any amount of parsing — because the key lives inside the CDM and never comes out.
  // Worth naming rather than reporting as a decode failure: one is a bug to chase, the
  // other is a source that will never have a lookahead, and holding its bytes to retry
  // every three seconds is a megabyte and a decode spent on nothing.
  function fmp4Encrypted(b) {
    const moov = childBoxes(b, 0, b.length).find((x) => x.type === 'moov');
    if (!moov) return false;
    if (childBoxes(b, moov.body, moov.end).some((x) => x.type === 'pssh')) return true;
    const stsd = descend(b, moov.body, moov.end, ['trak', 'mdia', 'minf', 'stbl', 'stsd']);
    if (!stsd) return false;
    const entry = childBoxes(b, stsd.body + 8, stsd.end)[0];
    if (!entry) return false;
    if (entry.type === 'enca' || entry.type === 'encv') return true;
    return childBoxes(b, entry.body + 28, entry.end).some((x) => x.type === 'sinf');
  }

  // Complete moof+mdat pairs, RESYNCHRONISING when the walk hits nonsense.
  //
  // The held chunks are appendBuffer slices, not box boundaries — one media segment
  // arrives as many appends — so the byte cap can and does cut a fragment in half. That
  // leaves a partial box where a header should be, which is fatal to a walk that just
  // gives up. Scanning forward for the next `moof` costs nothing and keeps the ninety
  // seconds behind the cut.
  function fmp4Fragments(b) {
    const frags = [];
    let p = 0;
    while (p + 8 <= b.length) {
      const size = u32be(b, p);
      const type = boxType(b, p);
      if (size < 8 || p + size > b.length || !isBoxName(type)) {
        const at = findAscii(b, 'moof', p + 1);
        if (at < 4) break;
        p = at - 4;
        continue;
      }
      if (type === 'moof' && p + size + 8 <= b.length && boxType(b, p + size) === 'mdat') {
        const mdatSize = u32be(b, p + size);
        const after = p + size + mdatSize;
        // A PARTIAL FRAGMENT IS NOT DECODABLE, and "it fits inside the buffer" is not
        // enough to know it is whole. When the cap cuts a fragment in half, the piece of
        // the NEXT fragment sitting behind it keeps the buffer long enough for the
        // declared mdat size to look satisfiable — so the samples get read out of the
        // wrong bytes and decoded as if they were audio. What actually says a fragment is
        // intact is that a real box begins where it ends.
        const whole = mdatSize >= 8 && after <= b.length &&
          (after === b.length || (after + 8 <= b.length && isBoxName(boxType(b, after)) && u32be(b, after) >= 8));
        if (whole) {
          frags.push({ moof: p, moofSize: size, mdat: p + size, mdatSize });
          p = after;
          continue;
        }
        // Broken here: pick up at the next header rather than trusting this length.
        const next = findAscii(b, 'moof', p + 8);
        if (next < 4) break;
        p = next - 4;
        continue;
      }
      p += size;
    }
    return frags;
  }

  // The sample table of one fragment: where each AAC frame starts, how long it is.
  function fmp4Samples(b, f) {
    const traf = descend(b, f.moof + 8, f.moof + f.moofSize, ['traf']);
    if (!traf) return [];
    const kids = childBoxes(b, traf.body, traf.end);
    const tfhd = kids.find((x) => x.type === 'tfhd');
    const trun = kids.find((x) => x.type === 'trun');
    if (!trun) return [];
    let defDur = 1024, defSize = 0;
    if (tfhd) {
      const flags = (b[tfhd.body + 1] << 16) | (b[tfhd.body + 2] << 8) | b[tfhd.body + 3];
      let q = tfhd.body + 8;                       // version/flags, then track_ID
      if (flags & 0x000001) q += 8;                // base-data-offset
      if (flags & 0x000002) q += 4;                // sample-description-index
      if (flags & 0x000008) { defDur = u32be(b, q); q += 4; }
      if (flags & 0x000010) { defSize = u32be(b, q); q += 4; }
    }
    const flags = (b[trun.body + 1] << 16) | (b[trun.body + 2] << 8) | b[trun.body + 3];
    let q = trun.body + 4;
    const count = u32be(b, q); q += 4;
    // The offset is relative to the START OF THE MOOF under `default-base-is-moof`,
    // which is how YouTube (and ffmpeg's default_base_moof) writes it.
    let off = f.mdat + 8;
    if (flags & 0x000001) { off = f.moof + (u32be(b, q) | 0); q += 4; }
    if (flags & 0x000004) q += 4;                  // first-sample-flags
    const out = [];
    for (let i = 0; i < count; i++) {
      let dur = defDur, size = defSize;
      if (flags & 0x000100) { dur = u32be(b, q); q += 4; }
      if (flags & 0x000200) { size = u32be(b, q); q += 4; }
      if (flags & 0x000400) q += 4;                // sample flags
      if (flags & 0x000800) q += 4;                // composition time offset
      if (!size) break;
      out.push({ off, size, dur });
      off += size;
    }
    return out;
  }

  // Decode the held fMP4 to the same envelope the WebM path produces: one peak per
  // 10ms, computed as the frames arrive so no PCM is ever held whole.
  async function decodeFmp4(b) {
    if (typeof AudioDecoder === 'undefined') throw new Error('no WebCodecs AudioDecoder');
    const cfg = fmp4Config(b);
    if (!cfg) throw new Error('no aac config in moov');
    const frags = fmp4Fragments(b);
    if (!frags.length) throw new Error('no complete fragments');
    const peaks = [];
    let rate = cfg.sampleRate, per = Math.max(1, Math.round(rate / AHEAD_HZ));
    let inBucket = 0, peak = 0, frames = 0, failed = null;
    const dec = new AudioDecoder({
      output: (ad) => {
        try {
          if (ad.sampleRate !== rate) { rate = ad.sampleRate; per = Math.max(1, Math.round(rate / AHEAD_HZ)); }
          const n = ad.numberOfFrames;
          const pcm = new Float32Array(n);
          ad.copyTo(pcm, { planeIndex: 0, format: 'f32-planar' });
          for (let i = 0; i < n; i++) {
            const x = pcm[i] < 0 ? -pcm[i] : pcm[i];
            if (x > peak) peak = x;
            if (++inBucket >= per) { peaks.push(Math.min(255, Math.round(peak * 255))); peak = 0; inBucket = 0; }
          }
          frames += n;
        } catch (e) { failed = String((e && e.message) || e);
        } finally { ad.close(); }     // AudioData holds real memory until it is closed
      },
      error: (e) => { failed = String((e && e.message) || e); },
    });
    dec.configure({ codec: cfg.codec, sampleRate: cfg.sampleRate,
                    numberOfChannels: cfg.channels, description: cfg.asc });
    let ts = 0;
    for (const f of frags) {
      for (const s of fmp4Samples(b, f)) {
        if (s.off < 0 || s.off + s.size > b.length) continue;
        const dur = Math.round((s.dur / cfg.timescale) * 1e6);
        // EVERY AAC FRAME IS A KEY FRAME, so a decoder can be started at any of them —
        // which is the whole reason joining late is survivable on this path.
        dec.decode(new EncodedAudioChunk({ type: 'key', timestamp: ts, duration: dur,
                                           data: b.subarray(s.off, s.off + s.size) }));
        ts += dur;
      }
    }
    await dec.flush();
    dec.close();
    if (failed && !frames) throw new Error(failed);
    return { env: Uint8Array.from(peaks), seconds: frames / rate, frames, fragments: frags.length };
  }

  // Decoding is async and the bridge is synchronous, so it runs on its own clock and
  // the reply hands back whatever was last finished. Every three seconds is ample: the
  // buffer moves in segments of seconds, and a decode of fifty seconds took 370ms.
  async function decodeAhead() {
    if (!ahead.armed || ahead.decoding || ahead.chunks.length < 2) return;
    if (Date.now() - ahead.lastDecode < 3000) return;
    // NOTHING NEW, NOTHING TO DO. Without this the same bytes were decoded again every
    // three seconds for as long as the tab was open, including while it was paused.
    if (ahead.decodedAt === ahead.appended) return;
    ahead.decoding = true;
    try {
      let total = 0;
      for (const c of ahead.chunks) total += c.byteLength;
      const buf = new Uint8Array(total);
      let o = 0;
      for (const c of ahead.chunks) { buf.set(c, o); o += c.byteLength; }
      // ONE CONTEXT, REUSED. A real AudioContext per decode is a hardware stream Chrome
      // has to open and close every three seconds; an OfflineAudioContext decodes just
      // as well and costs nothing at rest.
      // WHICH DECODER, DECIDED BY THE HEADER. WebM/Opus goes through decodeAudioData,
      // which reads it with no demuxer at all; fragmented MP4 goes through WebCodecs,
      // because decodeAudioData will not read that at any size. The container is named
      // by the first bytes of the chunk we pinned as the init segment.
      const fmp4 = buf.length >= 8 && buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79 && buf[7] === 0x70;
      let env, seconds;
      if (fmp4 && (ahead.encrypted || fmp4Encrypted(buf))) {
        // Say so once and stop: the bytes are never going to become audio, and the whole
        // point of holding them was to decode them.
        ahead.encrypted = true;
        ahead.env = null;
        ahead.envEndMedia = null;
        ahead.chunks = [];
        ahead.err = 'encrypted (DRM) — no lookahead for this source';
        return;
      }
      if (fmp4) {
        const r = await decodeFmp4(buf);
        env = r.env; seconds = r.seconds;
        ahead.via = 'webcodecs';
        ahead.fragments = r.fragments;
      } else {
        if (!ahead.ac) ahead.ac = new OfflineAudioContext(1, 1, 48000);
        const d = await ahead.ac.decodeAudioData(buf.buffer.slice(0));
        const pcm = d.getChannelData(0);
        const per = Math.max(1, Math.round(d.sampleRate / AHEAD_HZ));
        const n = Math.floor(pcm.length / per);
        env = new Uint8Array(n);
        for (let b2 = 0; b2 < n; b2++) {
          let pk = 0;
          const s0 = b2 * per;
          for (let i = 0; i < per; i++) { const x = pcm[s0 + i] < 0 ? -pcm[s0 + i] : pcm[s0 + i]; if (x > pk) pk = x; }
          env[b2] = Math.min(255, Math.round(pk * 255));
        }
        seconds = n / AHEAD_HZ;
        ahead.via = 'decodeAudioData';
      }
      if (!env.length) throw new Error('decoded nothing');
      ahead.env = env;
      ahead.envSeconds = seconds;
      // ANCHOR BY THE END, not by where buffering seemed to start.
      //
      // The obvious anchor — the media time when the first chunk arrived — was out by
      // 2.56s in practice, because a re-init makes the player discard and re-buffer
      // while the accumulated bytes still hold audio from before it. The END is
      // directly observable: `buffered.end` is where the download has actually reached,
      // which is also the edge nearest the playhead and the part that gets drawn.
      const v2 = best();
      ahead.envEndMedia = v2 && v2.buffered && v2.buffered.length
        ? v2.buffered.end(v2.buffered.length - 1) : null;
      ahead.err = null;
      ahead.errRuns = 0;
    } catch (e) {
      ahead.err = String((e && e.message) || e).slice(0, 120);
      // A BLOCK THAT CANNOT BE REFRESHED MUST NOT STAY PUBLISHED. Decoding is the only
      // thing that moves `envEndMedia` forward, so once it fails for good the last
      // successful block sits there being reported `ready` while the playhead walks
      // away from it — MEASURED at 247 seconds behind, still `ready: true`, on a tab
      // whose audio is AAC in fragmented MP4 (which decodeAudioData will not read at
      // all: not the whole buffer, not one complete moof+mdat, not the header alone).
      // One failure is a hiccup and the block is still nearly right; two in a row is a
      // source we cannot read, and drawing nothing is the honest picture.
      ahead.errRuns = (ahead.errRuns || 0) + 1;
      if (ahead.errRuns >= 2) { ahead.env = null; ahead.envEndMedia = null; }
    } finally {
      ahead.decoding = false;
      ahead.lastDecode = Date.now();
      ahead.decodedAt = ahead.appended;
    }
  }

  // DECODE ONLY WHILE SOMEBODY IS ASKING. This ran on a one-second timer at first,
  // which meant every captured tab paid a 370ms decode every three seconds forever —
  // in the user's own YouTube tab, whether or not the panel was open, whether or not
  // the scope was even switched on. Asking is the signal, so the request drives it: the
  // reply hands back the last finished block and kicks the next decode on its way out.
  // The three-second gate inside decodeAhead still holds, so a fast poller cannot make
  // it run any oftener than the buffer changes.
  if (prev && prev.aheadTimer) { try { clearInterval(prev.aheadTimer); } catch {} }
  state0.aheadTimer = 0;

  function aheadReply() {
    const v = best();
    if (!ahead.armed) return { ok: true, armed: false };
    // Deliberately not awaited: the bridge is synchronous, and this reply is about what
    // has already been decoded.
    decodeAhead();
    // A BLOCK ENTIRELY IN THE PAST IS NOT A FUTURE. `envEndMedia` is where the decoded
    // audio ends on the media clock; if the playhead is already past it there is
    // nothing to draw right of the head and saying `ready` only invites the panel to
    // draw the past twice, dimmer and wrong. A healthy source is 20-120s ahead, so this
    // fires on breakage, not on a poll landing a moment late.
    const stale = !!(v && ahead.envEndMedia !== null && ahead.envEndMedia <= v.currentTime);
    if (!ahead.env || ahead.envEndMedia === null || !v || stale) {
      return { ok: true, armed: true, ready: false, err: ahead.err, stale,
               endMedia: ahead.envEndMedia, mediaNow: v ? v.currentTime : null,
               paused: v ? !!v.paused : null,
               chunks: ahead.chunks.length, sawInit: !!ahead.sawInit,
               waiting: !!ahead.waiting, trimmed: !!ahead.trimmed,
               appends: ahead.appends || 0, sniffed: ahead.sniffed || 0,
               via: ahead.via || null, encrypted: !!ahead.encrypted,
               bytes: ahead.chunks.reduce((n, c) => n + c.byteLength, 0) };
    }
    let bin = '';
    for (let i = 0; i < ahead.env.length; i++) bin += String.fromCharCode(ahead.env[i]);
    return {
      ok: true, armed: true, ready: true,
      hz: AHEAD_HZ,
      // Where this block ENDS on the media clock, how long it is, and where the media
      // clock is now — enough to place every bucket against anything else.
      endMedia: ahead.envEndMedia,
      seconds: ahead.envSeconds,
      trimmed: !!ahead.trimmed,
      // THE SAME COUNTERS THE NOT-READY REPLY CARRIES. They were on one branch only, so
      // the moment it started working every diagnostic went blank — and a live check
      // reading `bytes` passed on `undefined <= 1.8e6`, which is a check that cannot
      // fail. What a reply says about itself should not depend on the good news.
      sawInit: !!ahead.sawInit, appends: ahead.appends || 0, sniffed: ahead.sniffed || 0,
      // WHICH DECODER THIS SOURCE IS ON. The two paths fail in different ways and the
      // panel cannot tell them apart otherwise.
      via: ahead.via || null,
      encrypted: !!ahead.encrypted,
      chunks: ahead.chunks.length,
      bytes: ahead.chunks.reduce((n, c) => n + c.byteLength, 0),
      mediaNow: v.currentTime,
      rate: v.playbackRate || 1,
      // A PAUSED SOURCE IS NOT APPROACHING THE HEAD. `playbackRate` stays 1 while
      // paused, so a reader that has only the rate advances the block on wall-clock
      // time and claims sound is arriving when none is — his screenshot: a flat past
      // beside a future full of noise that would never come.
      paused: !!v.paused,
      // On the good branch as well. These lived only on the not-ready reply, so every
      // diagnostic went blank the moment the feature started working — and a check that
      // read one of them then passed on `undefined`, which is a check that cannot fail.
      err: ahead.err,
      stale: false,
      bufferedEnd: v.buffered && v.buffered.length ? v.buffered.end(v.buffered.length - 1) : null,
      env: btoa(bin),
    };
  }

  // Events, because they are the one thing both worlds genuinely share. Dispatch is
  // synchronous, so the reply has already been written by the time dispatchEvent
  // returns and the caller needs no request ids and no waiting.
  const listener = (e) => {
    let msg;
    try { msg = JSON.parse(e.detail); } catch { return; }
    let reply;
    try { reply = handle(msg); } catch (err) { reply = { ok: false, error: String(err) }; }
    document.dispatchEvent(new CustomEvent('quodlibet-res', { detail: JSON.stringify(reply) }));
  };
  document.addEventListener('quodlibet-req', listener);

  state0.listener = listener;
  state0.patched = true;
  state0.build = BUILD;
  window[KEY] = state0;
})();
