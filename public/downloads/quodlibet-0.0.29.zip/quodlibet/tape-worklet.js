// Tape: a rolling stereo ring buffer sitting between the channel sum and output.
//
// It is always recording. `thru` mode passes input straight out (zero latency) while
// still filling the ring, so engaging the tape is seamless. `tape` mode plays from a
// read head that runs at `rate` — continuous, signed, so 0.5 is half speed, -1 is
// reverse, 0 is a full stop.
//
// Positions are absolute sample counts (safe to 2^53) and mapped into the ring by
// modulo, which keeps loop points and scrubbing simple.

// Buckets per second of waveform. 100 gives a 10ms resolution — finer than a screen
// pixel at any window this panel will draw, and 6000 numbers for the whole sixty
// seconds, which is nothing to hold or to draw from.
const SCOPE_HZ = 100;
const SCOPE_SEND_MS = 50;

class TapeProcessor extends AudioWorkletProcessor {
  static get parameterDescriptors() {
    return [
      // a-rate so varispeed and scrub move smoothly rather than in block steps.
      { name: 'rate', defaultValue: 1, minValue: -4, maxValue: 4, automationRate: 'a-rate' },
    ];
  }

  constructor(options) {
    super();
    const opts = options.processorOptions || {};
    const seconds = opts.seconds || 60;
    this.len = Math.floor(sampleRate * seconds);
    this.ring = [new Float32Array(this.len), new Float32Array(this.len)];

    this.writePos = 0; // absolute samples written
    this.readPos = 0; // absolute, fractional
    this.mode = 'thru'; // 'thru' | 'tape'
    this.latency = Math.floor(sampleRate * (opts.latencySec || 0.25));

    this.loopEnabled = false;
    this.loopStart = 0;
    this.loopEnd = 0;
    this.loopArming = false;  // `in` marked, `out` not yet
    this.loopBuf = null;      // the loop's own copy; see at()
    this.loopSource = null;   // 'seconds' | 'tap' | 'stutter' — which control owns it
    this.loopSeconds = 0;     // for 'seconds', so only THAT button lights

    // ---- the scope -------------------------------------------------------------
    //
    // The tape already holds sixty seconds of stereo. Drawing it needs no second
    // buffer, only a cheaper summary: peak magnitude over short buckets, which is
    // what a waveform is. Kept at a fixed rate in TIME rather than in pixels, so the
    // panel can draw any window onto it — twelve seconds now, the whole minute when
    // scrubbing wants it, without asking for anything different.
    //
    // Pushed rather than polled, and only the buckets that are new since the last
    // push, so the traffic is a handful of numbers every 50ms instead of a redraw's
    // worth of array every frame.
    this.bucketLen = Math.max(1, Math.round(sampleRate / SCOPE_HZ));
    this.bucketPeak = 0;
    this.bucketFill = 0;
    this.pending = [];      // completed buckets not yet sent
    this.scopeOn = false;
    this.sinceSend = 0;
    this.lastRate = 1;
    this.interp = opts.interp || 'linear'; // 'linear' | 'cubic'
    this.stutterPrev = null; // loop state saved for the duration of a stutter

    // A stopped transport must make no sound. Holding the read head still returns the
    // same sample forever, which is a DC offset that buzzes; and once the buffer is
    // full the oldest-clamp starts dragging the head one jump per block, which is a
    // ~375Hz staircase of unrelated samples. Both were audible as "dissonant
    // crackling that won't stop". Fading out near zero rate fixes both, and is what a
    // real tape does anyway.
    this.stopGain = 1;
    // ~20ms ramp, so it reads as a stop rather than a click.
    this.fadeCoeff = 1 - Math.exp(-1 / (0.02 * sampleRate));

    this.port.onmessage = (e) => this.onMessage(e.data || {});
  }

  onMessage(m) {
    switch (m.type) {
      case 'set':
        if (m.mode !== undefined && m.mode !== this.mode) {
          // Entering tape: drop the read head to the standing latency behind live so
          // there is rope to scrub backwards into.
          if (m.mode === 'tape') this.readPos = this.writePos - this.latency;
          this.mode = m.mode;
        }
        if (m.latencySec !== undefined) {
          this.latency = Math.floor(sampleRate * m.latencySec);
        }
        if (m.loopEnabled !== undefined) {
          this.loopEnabled = !!m.loopEnabled;
          // Switching a loop off drops the copy and lands you back on the ring, which
          // never stopped recording — so `off` still carries on from where the tape is.
          if (!this.loopEnabled) {
            this.loopBuf = null; this.loopArming = false;
            this.loopSource = null; this.loopSeconds = 0;
          }
        }
        if (m.interp === 'linear' || m.interp === 'cubic') this.interp = m.interp;
        break;

      // Loop points are marked live, relative to the read head.
      // Tapped in and out, live. `in` only marks — nothing changes about what you are
      // hearing until `out` closes the loop, which is what makes it usable while
      // something is playing: you can mark, listen, and mark again.
      case 'loopIn':
        this.markIn();
        break;

      // ONE BUTTON, THREE STATES. The worklet decides which, rather than the panel
      // counting presses: a counter in the UI drifts the moment anything else touches
      // the loop — `off`, a stutter, a seconds-back button — and then the button is
      // lying about a state it no longer owns. Asking the thing that holds the state
      // cannot drift.
      case 'loopTap':
        if (this.loopEnabled) {
          // Third press: drop this loop and immediately mark the start of the next, so
          // loops can be chained without a trip to `off` in between.
          this.loopEnabled = false;
          this.loopBuf = null;
          this.markIn();
        } else if (this.loopArming) {
          this.closeLoop();
        } else {
          this.markIn();
        }
        break;
      case 'loopOut':
        this.closeLoop();
        break;
      // Momentary: grab the last `seconds` and loop it, then put the previous loop
      // state back. Held, it repeats; released, it stops pretending it never
      // happened — by default it snaps back to live, since stuttering spends time.
      case 'stutter': {
        if (m.on) {
          if (!this.stutterPrev) {
            // The BUFFER goes in the snapshot too. Without it, releasing a stutter
            // taken over a running loop restored that loop's boundaries onto a null
            // copy — so at() would silently fall through to the ring and the loop
            // would come back as whatever is there now instead of what it held.
            this.stutterPrev = {
              enabled: this.loopEnabled, start: this.loopStart, end: this.loopEnd,
              buf: this.loopBuf, arming: this.loopArming,
            };
          }
          const end = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
          const len = Math.max(64, Math.floor(sampleRate * (m.seconds || 0.125)));
          this.loopStart = end - len;
          this.loopEnd = end;
          this.loopSource = 'stutter';
          this.armLoop();
        } else if (this.stutterPrev) {
          this.loopEnabled = this.stutterPrev.enabled;
          this.loopStart = this.stutterPrev.start;
          this.loopEnd = this.stutterPrev.end;
          this.loopBuf = this.stutterPrev.buf;
          this.loopArming = this.stutterPrev.arming;
          this.stutterPrev = null;
          if (m.catchUp !== false) this.readPos = this.writePos - this.latency;
        }
        break;
      }

      // Jump the read head without changing rate — used to return to live.
      case 'toLive':
        this.readPos = this.writePos - this.latency;
        break;

      case 'scope':
        // Off by default and off whenever nothing is drawing it: a push nobody reads
        // is work the audio thread does for no one.
        this.scopeOn = !!m.on;
        this.pending.length = 0;
        break;

      case 'loopSecondsBack': {
        const end = this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
        this.loopStart = end - Math.floor(sampleRate * (m.seconds || 2));
        this.loopEnd = end;
        this.loopArming = false;
        this.loopSource = 'seconds';
        this.loopSeconds = m.seconds || 2;
        this.armLoop();
        break;
      }
      case 'query':
        this.port.postMessage({
          type: 'state',
          mode: this.mode,
          rate: this.lastRate,
          interp: this.interp,
          sampleRate,
          bufferSeconds: this.len / sampleRate,
          latencySec: this.latency / sampleRate,
          loopEnabled: this.loopEnabled,
          loopArming: this.loopArming,
          loopSource: this.loopSource,
          loopSeconds: this.loopSeconds,
          loopLenSec: (this.loopEnd - this.loopStart) / sampleRate,
          behindLiveSec: (this.writePos - this.readPos) / sampleRate,
          secondsRecorded: Math.min(this.writePos, this.len) / sampleRate,
        });
        break;
    }
  }

  // A LOOP READS FROM ITS OWN COPY, not from the ring it was taken out of.
  //
  // The ring keeps recording underneath — it has to, or there would be nothing to
  // return to when the loop is switched off. But that means a loop left running is
  // overwritten by live audio once the write head laps it, so after sixty seconds it
  // stops being the thing you captured and slowly becomes the present. Invisible for
  // the 1s/2s/4s/8s buttons, because nobody holds one for a minute; fatal for a loop
  // you tap in and out and then leave alone, which is the whole point of tapping it.
  //
  // So arming a loop copies the region out. Stable for as long as you like, and off
  // still drops you back onto a ring that never stopped recording.
  at(chan, i) {
    if (this.loopEnabled && this.loopBuf) {
      const n = this.loopBuf[chan].length;
      const j = i - this.loopStart;
      return this.loopBuf[chan][((j % n) + n) % n];
    }
    const len = this.len;
    return this.ring[chan][((i % len) + len) % len];
  }

  head() {
    return this.mode === 'tape' ? this.readPos : this.writePos - this.latency;
  }

  markIn() {
    this.loopStart = this.head();
    this.loopArming = true;
    this.loopEnabled = false;
    this.loopBuf = null;
    this.loopSource = 'tap';
    this.loopSeconds = 0;
  }

  closeLoop() {
    const end = this.head();
    // Marking `out` before `in` is a reasonable thing to do by accident, and the
    // reasonable answer is the region between them either way.
    if (end < this.loopStart) { this.loopEnd = this.loopStart; this.loopStart = end; }
    else this.loopEnd = end;
    this.loopArming = false;
    this.loopSource = 'tap';
    this.armLoop();
  }

  // Copy [loopStart, loopEnd) out of the ring. Clamped to what the ring still holds:
  // a loop cannot be made out of audio that has already been overwritten.
  armLoop() {
    // FLOOR FIRST. In tape mode the loop bounds come from readPos, which is a FLOAT the
    // moment the rate is anything but exactly 1 — and every rate change is a ramp, so
    // one press of reverse leaves it fractional for ever. Using it as an array index
    // read `ring[3.7]`, which is `undefined`, which a Float32Array stores as NaN. The
    // whole loop buffer became NaN, the tape output NaN, and the DC-blocking biquad
    // downstream took NaN into its state and never came back: silent for good, while
    // still recording and still drawing its waveform. Brendan found it in ten minutes.
    this.loopStart = Math.floor(this.loopStart);
    this.loopEnd = Math.floor(this.loopEnd);
    const oldest = this.writePos - this.len + 2;
    if (this.loopStart < oldest) this.loopStart = oldest;
    const n = Math.floor(this.loopEnd - this.loopStart);
    if (n < 2) { this.loopBuf = null; this.loopEnabled = false; return false; }
    const buf = [new Float32Array(n), new Float32Array(n)];
    for (let c = 0; c < 2; c++) {
      const src = this.ring[c];
      const dst = buf[c];
      for (let i = 0; i < n; i++) {
        const k = this.loopStart + i;
        dst[i] = src[((k % this.len) + this.len) % this.len];
      }
    }
    this.loopBuf = buf;
    this.loopEnabled = true;
    // AND PLAY IT. In thru the process loop returns early and copies the input straight
    // through, so a loop armed from thru is enabled, lit, and completely inaudible —
    // the head sails past it. The seconds-back buttons had always engaged the tape from
    // the panel; the tap button did not, and Brendan hit it within a minute. Doing it
    // HERE covers every route into a loop, including the console and anything mapped to
    // MIDI, rather than each caller having to remember.
    this.mode = 'tape';
    return true;
  }

  sample(chan, pos) {
    const i0 = Math.floor(pos);
    const t = pos - i0;

    if (this.interp === 'cubic') {
      // Catmull-Rom. Four taps instead of two; markedly less imaging at non-unity
      // rates, where linear alternates exact samples with midpoints and leaves a
      // strong image at the source frequency.
      const y0 = this.at(chan, i0 - 1);
      const y1 = this.at(chan, i0);
      const y2 = this.at(chan, i0 + 1);
      const y3 = this.at(chan, i0 + 2);
      const a = -0.5 * y0 + 1.5 * y1 - 1.5 * y2 + 0.5 * y3;
      const b = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3;
      const c = -0.5 * y0 + 0.5 * y2;
      return ((a * t + b) * t + c) * t + y1;
    }

    const a = this.at(chan, i0);
    const b = this.at(chan, i0 + 1);
    return a + (b - a) * t;
  }

  process(inputs, outputs, params) {
    const input = inputs[0];
    const output = outputs[0];
    const n = output[0].length;

    // Always record.
    for (let c = 0; c < 2; c++) {
      const src = (input && (input[c] || input[0])) || null;
      const ring = this.ring[c];
      for (let i = 0; i < n; i++) {
        ring[(this.writePos + i) % this.len] = src ? src[i] : 0;
      }
    }

    // The scope rides along with the write head, so what it draws is what was
    // recorded — not what is being played, which may be somewhere else entirely.
    if (this.scopeOn) {
      const l = (input && input[0]) || null;
      const r = (input && (input[1] || input[0])) || null;
      for (let i = 0; i < n; i++) {
        const a = l ? (l[i] < 0 ? -l[i] : l[i]) : 0;
        const b = r ? (r[i] < 0 ? -r[i] : r[i]) : 0;
        const v = a > b ? a : b;
        if (v > this.bucketPeak) this.bucketPeak = v;
        if (++this.bucketFill >= this.bucketLen) {
          this.pending.push(this.bucketPeak);
          this.bucketPeak = 0;
          this.bucketFill = 0;
        }
      }
    }

    if (this.mode === 'thru') {
      for (let c = 0; c < output.length; c++) {
        const src = (input && (input[c] || input[0])) || null;
        if (src) output[c].set(src);
        else output[c].fill(0);
      }
      this.writePos += n;
      this.readPos = this.writePos - this.latency;
      // thru returns early, so the scope has to be pushed from here as well — and thru
      // is the mode the mixer normally sits in, so forgetting it means a waveform that
      // only appears once you engage the tape.
      this.sendScope(n);
      return true;
    }

    const rateArr = params.rate;
    const newest = this.writePos + n - 1;
    const oldest = newest - this.len + 2;

    for (let i = 0; i < n; i++) {
      const rate = rateArr.length > 1 ? rateArr[i] : rateArr[0];
      this.lastRate = rate;

      if (this.loopEnabled && this.loopEnd > this.loopStart) {
        const loopLen = this.loopEnd - this.loopStart;
        if (this.readPos >= this.loopEnd) this.readPos -= loopLen;
        else if (this.readPos < this.loopStart) this.readPos += loopLen;
      } else {
        // Never read ahead of what has been written, or off the back of the ring.
        if (this.readPos > newest - 1) this.readPos = newest - 1;
        if (this.readPos < oldest) this.readPos = oldest;
      }

      // Full level from |rate| = RATE_FADE upwards, so genuine slow speeds (0.25 and
      // below are still well clear of it) are untouched.
      const RATE_FADE = 0.02;
      const target = Math.min(1, Math.abs(rate) / RATE_FADE);
      this.stopGain += (target - this.stopGain) * this.fadeCoeff;

      for (let c = 0; c < output.length; c++) {
        // THE GUARD. Flooring above fixes the bug that produced NaN; this makes the
        // whole class survivable. A single NaN leaving here enters a biquad whose state
        // never recovers, so the cost is not a glitch but permanent silence — far too
        // much to pay for an arithmetic slip. One comparison a sample is nothing beside
        // that.
        const v = this.sample(c, this.readPos) * this.stopGain;
        output[c][i] = v === v ? v : 0;
      }
      this.readPos += rate;
    }

    this.writePos += n;
    this.sendScope(n);
    return true;
  }

  // One message every SCOPE_SEND_MS carrying whatever buckets completed since the
  // last, plus the positions the panel needs to place a play head, a live edge and a
  // loop region against them. Everything travels together on purpose: a waveform drawn
  // against a head read a frame later lines up wrongly, and the error looks like drift.
  sendScope(n) {
    if (!this.scopeOn) return;
    this.sinceSend += n;
    if (this.sinceSend < (sampleRate * SCOPE_SEND_MS) / 1000) return;
    this.sinceSend = 0;
    const buckets = this.pending.length ? Float32Array.from(this.pending) : EMPTY;
    this.pending.length = 0;
    this.port.postMessage({
      type: 'scope',
      buckets,
      hz: SCOPE_HZ,
      sampleRate,
      // The context's own sample clock, so a channel's waveform and the tape's can be
      // placed on one timeline. writePos counts what THIS node has written, which is
      // not the same number and differs by however long the context ran before it.
      frame: currentFrame,
      writePos: this.writePos,
      readPos: this.readPos,
      latency: this.latency,
      mode: this.mode,
      lastRate: this.lastRate,
      loopEnabled: this.loopEnabled,
      loopArming: this.loopArming,
      loopSource: this.loopSource,
      loopSeconds: this.loopSeconds,
      loopStart: this.loopStart,
      loopEnd: this.loopEnd,
      len: this.len,
    }, buckets.byteLength ? [buckets.buffer] : []);
  }
}

const EMPTY = new Float32Array(0);

registerProcessor('tape', TapeProcessor);
