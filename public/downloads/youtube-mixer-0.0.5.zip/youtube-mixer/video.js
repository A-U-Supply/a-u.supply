// Video mode: the performance layout.
//
// Same channels, same tape, same MIDI bindings — only the presentation changes.
//
// Space finding that drives the tile: a 2x2 grid on a 16:9 screen gives cells that are
// 2:1, wider than the 16:9 video inside them. So side strips are nearly FREE — they do
// not shrink the picture — while the bottom strip is expensive, because every pixel of
// height costs the video both height and (through the aspect ratio) width. Hence:
// level and meter and buttons down the sides, and a thin bottom.
//
// The tape and MIDI panels are MOVED here rather than rebuilt, so there is exactly one
// of each and they cannot drift apart between the two modes.
//
// Depends on globals from panel.js (setGain, setMute, setSolo, setPan, dropChannel,
// toContent, dragging) and audio.js (Mixer). Classic scripts, shared scope, last.

// Red, yellow, blue, white — by channel POSITION, so the colour tells you which tile a
// control belongs to. Tuned for a dark background rather than pure primaries.
const CHANNEL_COLOURS = ['#e0524f', '#e2c240', '#4f86e0', '#eae6de'];
const colourFor = (i) => CHANNEL_COLOURS[i % CHANNEL_COLOURS.length];

const tiles = new Map(); // tabId -> { el, parts }
let videoOn = false;
let videoTimer = null;
const homes = new Map(); // element -> { parent, next } so panels can be put back

function stash(id) {
  const el = document.getElementById(id);
  if (el && !homes.has(el)) homes.set(el, { parent: el.parentNode, next: el.nextSibling });
  return el;
}
function restore(id) {
  const el = document.getElementById(id);
  const home = el && homes.get(el);
  if (home) home.parent.insertBefore(el, home.next);
}

// ---------------------------------------------------------------- tile

function buildTile(tabId) {
  const el = document.createElement('div');
  el.className = 'tile';
  el.innerHTML = `
    <div class="tile__left">
      <div class="vfader" data-help="Channel level. Drag anywhere up or down this fader.">
        <div class="vfader__fill"></div>
      </div>
    </div>

    <div class="tile__mid">
      <div class="tile__vidbox">
        <video class="tile__v" autoplay muted playsinline></video>
        <canvas class="tile__viz" width="480" height="120"></canvas>
      </div>
    </div>

    <div class="tile__right">
      <div class="vmeter" data-help="Live level of this channel."><div class="vmeter__fill"></div></div>
      <div class="tile__btns">
        <button class="tile__btn tile__m" data-help="Silence this channel without moving its fader.">M</button>
        <button class="tile__btn tile__s" data-help="Hear only this channel. Shift-click to solo several.">S</button>
        <button class="tile__btn tile__pitch" aria-pressed="true" data-help="On: speed changes without pitch. Off: pitch rides with speed, the way tape behaves.">&#9834;</button>
        <button class="tile__btn tile__x" data-help="Remove this tab from the mixer.">&times;</button>
      </div>
    </div>

    <div class="tile__bottom">
      <span class="tile__title"></span>
      <button class="tile__btn tile__play" data-help="Resume this video.">&#9654;</button>
      <button class="tile__btn tile__pause" data-help="Pause this video. It stays in the mixer.">&#10073;&#10073;</button>
      <span class="tile__rate" data-help="Playback speed. Drag left or right; double-click for 1.00.">1.00&times;</span>
      <span class="tile__panwrap" data-help="Stereo position. Drag left or right; double-click to centre.">
        <span class="hpan"><span class="hpan__dot"></span></span>
      </span>
    </div>`;

  const q = (s) => el.querySelector(s);
  const parts = {
    left: q('.tile__left'), fader: q('.vfader'), faderFill: q('.vfader__fill'),
    meter: q('.vmeter__fill'), vidbox: q('.tile__vidbox'),
    v: q('.tile__v'), viz: q('.tile__viz'), vizCtx: q('.tile__viz').getContext('2d'),
    m: q('.tile__m'), s: q('.tile__s'), pitch: q('.tile__pitch'), x: q('.tile__x'),
    title: q('.tile__title'), play: q('.tile__play'), pause: q('.tile__pause'),
    rate: q('.tile__rate'), pan: q('.hpan'), panDot: q('.hpan__dot'),
    crop: null, streamAttached: false, rateVal: 1, panVal: 0,
  };

  // Vertical fader: bottom is 0, top is 1.5. Pointer capture so a drag that leaves the
  // tile still tracks — tiles get small with four channels.
  const faderFrom = (e) => {
    const r = parts.fader.getBoundingClientRect();
    const frac = Math.max(0, Math.min(1, 1 - (e.clientY - r.top) / r.height));
    parts.faderFill.style.height = (frac * 100) + '%';
    setGain(tabId, frac * 1.5);
  };
  parts.fader.addEventListener('pointerdown', (e) => {
    parts.fader.setPointerCapture(e.pointerId);
    dragging = parts.fader;
    faderFrom(e);
  });
  parts.fader.addEventListener('pointermove', (e) => {
    if (dragging === parts.fader) faderFrom(e);
  });
  const relFader = () => { if (dragging === parts.fader) dragging = null; };
  parts.fader.addEventListener('pointerup', relFader);
  parts.fader.addEventListener('pointercancel', relFader);

  // Horizontal pan: left/right is what pan means, so it reads wrong as a vertical.
  const panFrom = (e) => {
    const r = parts.pan.getBoundingClientRect();
    const frac = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    const v = frac * 2 - 1;
    parts.panVal = v;
    parts.panDot.style.left = (frac * 100) + '%';
    setPan(tabId, v);
  };
  parts.pan.addEventListener('pointerdown', (e) => {
    parts.pan.setPointerCapture(e.pointerId);
    dragging = parts.pan;
    panFrom(e);
  });
  parts.pan.addEventListener('pointermove', (e) => { if (dragging === parts.pan) panFrom(e); });
  const relPan = () => { if (dragging === parts.pan) dragging = null; };
  parts.pan.addEventListener('pointerup', relPan);
  parts.pan.addEventListener('pointercancel', relPan);
  parts.pan.addEventListener('dblclick', () => {
    parts.panVal = 0; parts.panDot.style.left = '50%'; setPan(tabId, 0);
  });

  // Rate: drag horizontally. Compact, and rate is a value rather than a position, so a
  // slider would cost width the picture wants.
  let rateAnchor = null;
  parts.rate.addEventListener('pointerdown', (e) => {
    parts.rate.setPointerCapture(e.pointerId);
    dragging = parts.rate;
    rateAnchor = { x: e.clientX, v: parts.rateVal };
  });
  parts.rate.addEventListener('pointermove', (e) => {
    if (dragging !== parts.rate || !rateAnchor) return;
    const v = Math.max(0.25, Math.min(2.5, rateAnchor.v + (e.clientX - rateAnchor.x) * 0.005));
    parts.rateVal = v;
    parts.rate.textContent = v.toFixed(2) + '×';
    toContent(tabId, {
      type: 'SET_RATE', rate: v,
      preservesPitch: parts.pitch.getAttribute('aria-pressed') === 'true',
    });
  });
  const relRate = () => { if (dragging === parts.rate) { dragging = null; rateAnchor = null; } };
  parts.rate.addEventListener('pointerup', relRate);
  parts.rate.addEventListener('pointercancel', relRate);
  parts.rate.addEventListener('dblclick', () => {
    parts.rateVal = 1;
    parts.rate.textContent = '1.00×';
    toContent(tabId, { type: 'SET_RATE', rate: 1,
      preservesPitch: parts.pitch.getAttribute('aria-pressed') === 'true' });
  });

  parts.m.addEventListener('click', () => setMute(tabId));
  parts.s.addEventListener('click', (e) => setSolo(tabId, undefined, !e.shiftKey));
  parts.x.addEventListener('click', () => { dropChannel(tabId); renderVideo(); });
  parts.play.addEventListener('click', () => toContent(tabId, { type: 'PLAY' }));
  parts.pause.addEventListener('click', () => toContent(tabId, { type: 'PAUSE' }));
  parts.pitch.addEventListener('click', () => {
    const on = parts.pitch.getAttribute('aria-pressed') !== 'true';
    parts.pitch.setAttribute('aria-pressed', String(on));
    toContent(tabId, { type: 'SET_RATE', rate: parts.rateVal, preservesPitch: on });
  });

  tiles.set(tabId, { el, parts });
  document.getElementById('video-grid').appendChild(el);
  return tiles.get(tabId);
}

// Crop the captured tab down to the player: blow the picture up by 1/w and slide it so
// the player's top-left lands at the box's.
function applyCrop(parts, crop) {
  const v = parts.v;
  if (!crop || crop.w <= 0.05 || crop.h <= 0.05) {
    v.style.width = '100%'; v.style.height = '100%';
    v.style.left = '0'; v.style.top = '0';
    return;
  }
  v.style.width = (100 / crop.w) + '%';
  v.style.height = (100 / crop.h) + '%';
  v.style.left = -(crop.x * 100 / crop.w) + '%';
  v.style.top = -(crop.y * 100 / crop.h) + '%';
}

function drawViz(parts, points) {
  const g = parts.vizCtx;
  const { width: w, height: h } = parts.viz;
  g.clearRect(0, 0, w, h);
  if (!points || !points.length) return;
  g.fillStyle = parts.colour || '#c9a227';
  const bw = w / points.length;
  for (let i = 0; i < points.length; i++) {
    const bh = Math.max(1, points[i] * h);
    g.fillRect(i * bw, (h - bh) / 2, Math.max(1, bw - 1), bh);
  }
}

async function renderVideo() {
  if (!videoOn) return;
  const st = Mixer.state();
  const channels = (st && st.channels) || [];
  const lv = Mixer.levels();
  const levelBy = new Map(((lv && lv.channels) || []).map((c) => [c.tabId, c.db]));

  for (const [tabId, t] of tiles) {
    if (!channels.some((c) => c.tabId === tabId)) { t.el.remove(); tiles.delete(tabId); }
  }

  const grid = document.getElementById('video-grid');
  grid.dataset.count = String(Math.min(channels.length, 6));

  for (const [i, ch] of channels.entries()) {
    const t = tiles.get(ch.tabId) || buildTile(ch.tabId);
    const p = t.parts;

    // Colour follows POSITION, so removing a channel re-colours the rest — the same
    // rule MIDI bindings use, so fader 1 and the red tile stay the same channel.
    const colour = colourFor(i);
    p.colour = colour;
    t.el.style.setProperty('--ch', colour);

    p.title.textContent = ch.title || 'tab ' + ch.tabId;

    // Attach the stream once; re-attaching restarts decoding and flickers.
    const stream = Mixer.getStream(ch.tabId);
    const hasVideo = !!(stream && stream.getVideoTracks && stream.getVideoTracks().length);
    if (hasVideo && !p.streamAttached) {
      p.v.srcObject = stream;
      p.v.play().catch(() => {});
      p.streamAttached = true;
    }
    t.el.classList.toggle('tile--audio', !hasVideo);

    if (dragging !== p.fader) p.faderFill.style.height = ((ch.level / 1.5) * 100) + '%';
    if (dragging !== p.pan) {
      p.panVal = ch.pan;
      p.panDot.style.left = (((ch.pan + 1) / 2) * 100) + '%';
    }

    const db = levelBy.get(ch.tabId);
    const meterFrac = db === null || db === undefined ? 0 : Math.max(0, Math.min(1, (db + 60) / 60));
    p.meter.style.height = (meterFrac * 100) + '%';

    p.m.setAttribute('aria-pressed', String(!!ch.muted));
    p.s.setAttribute('aria-pressed', String(!!ch.soloed));

    if (hasVideo) {
      const info = await toContent(ch.tabId, { type: 'INFO' });
      if (info && info.ok) {
        if (dragging !== p.rate) {
          p.rateVal = info.playbackRate;
          p.rate.textContent = Number(info.playbackRate).toFixed(2) + '×';
        }
        p.pitch.setAttribute('aria-pressed', String(!!info.preservesPitch));
        if (info.crop) { p.crop = info.crop; applyCrop(p, info.crop); }
      }
    } else {
      drawViz(p, Mixer.waveform(ch.tabId, 96));
    }
  }

  document.getElementById('video-empty').style.display = channels.length ? 'none' : '';
}

// ---------------------------------------------------------------- mode

function setVideoMode(on) {
  videoOn = !!on;
  localStorage.setItem('ym-video', videoOn ? '1' : '0');
  document.body.classList.toggle('video-mode', videoOn);
  document.getElementById('video-switch').setAttribute('aria-pressed', String(videoOn));

  // Move the tape and MIDI panels rather than rebuilding them: one of each, no chance
  // of the two modes drifting apart, and every handler stays bound.
  stash('tape'); stash('midi');
  if (videoOn) {
    document.getElementById('video-tape').appendChild(document.getElementById('tape'));
    document.getElementById('video-midi-body').appendChild(document.getElementById('midi'));
  } else {
    restore('tape'); restore('midi');
  }

  // Frames are only delivered while wanted, so audio mode costs nothing extra.
  Mixer.setVideoEnabled(videoOn);

  if (videoOn) {
    renderVideo();
    if (!videoTimer) videoTimer = setInterval(renderVideo, 250);
  } else {
    clearInterval(videoTimer);
    videoTimer = null;
    for (const [, t] of tiles) { t.parts.v.srcObject = null; t.parts.streamAttached = false; }
  }
}

function initVideo() {
  document.getElementById('video-switch')
    .addEventListener('click', () => setVideoMode(!videoOn));

  document.getElementById('video-full').addEventListener('click', () => {
    const el = document.getElementById('video');
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen().catch(() => {});
  });

  const clean = document.getElementById('video-clean');
  clean.addEventListener('click', () => {
    const on = clean.getAttribute('aria-pressed') !== 'true';
    clean.setAttribute('aria-pressed', String(on));
    document.body.classList.toggle('video-clean', on);
  });

  const midiBtn = document.getElementById('video-midi-btn');
  const midiPanel = document.getElementById('video-midi');
  midiBtn.addEventListener('click', () => {
    const on = midiBtn.getAttribute('aria-pressed') !== 'true';
    midiBtn.setAttribute('aria-pressed', String(on));
    midiPanel.style.display = on ? 'block' : 'none';
  });

  setVideoMode(localStorage.getItem('ym-video') === '1');
}

initVideo();

Object.assign(window, {
  videoMode: setVideoMode,
  videoTiles: () => tiles.size,
  videoIsOn: () => videoOn,
  videoColourOf: (tabId) => {
    const t = tiles.get(tabId);
    return t ? t.el.style.getPropertyValue('--ch') : null;
  },
  videoBoxRatio: (tabId) => {
    const t = tiles.get(tabId);
    if (!t) return null;
    const r = t.parts.vidbox.getBoundingClientRect();
    return r.height ? r.width / r.height : null;
  },
  videoReady: true,
});
