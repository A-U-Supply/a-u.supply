// Web MIDI: bind hardware controls to the mixer.
//
// Two things shape this file:
//
// 1. Since Chrome 124 ALL Web MIDI access prompts for permission, not just SysEx.
//    So access cannot be requested on load — it needs a click. We ask without
//    sysex; the prompt already warns about firmware risk and we have no use for it.
//
// 2. Mappings bind to deck POSITION ("deck:0:level"), never to a tab id. Tab ids are
//    regenerated every session, so an id-based mapping would be dead by morning.
//
// Depends on panel.js for midiApply() / midiTargetLabel() / MIDI_TARGETS — classic
// scripts share a global scope and this loads second.

const MIDI_STORE = 'midiMappings';

let midiAccess = null;
let mappings = {}; // "device|channel|cc" -> targetId
let learnTarget = null; // targetId waiting for a control to be moved
let learnMode = false;
const lastValue = new Map(); // binding key -> last raw value, for press edge detection

// A fader sweep can emit hundreds of messages a second. Coalesce to one apply per
// frame per target so we aren't flooding the offscreen document with messages.
const pending = new Map();
let flushQueued = false;
function queueApply(targetId, v01) {
  pending.set(targetId, v01);
  if (flushQueued) return;
  flushQueued = true;
  requestAnimationFrame(() => {
    flushQueued = false;
    for (const [t, v] of pending) midiApply(t, v, false);
    pending.clear();
  });
}

const bindingKey = (input, channel, cc) => `${input.name}|${channel}|${cc}`;

async function loadMappings() {
  const got = await chrome.storage.local.get(MIDI_STORE);
  mappings = got[MIDI_STORE] || {};
}
const saveMappings = () => chrome.storage.local.set({ [MIDI_STORE]: mappings });

function onMidiMessage(input, e) {
  const [status, d1, d2] = e.data;
  const kind = status & 0xf0;
  const channel = (status & 0x0f) + 1;

  let cc, raw, isPress;
  if (kind === 0xb0) {
    cc = d1; raw = d2; isPress = d2 >= 64;
  } else if (kind === 0x90 || kind === 0x80) {
    // Treat notes as buttons: note-on with velocity is a press.
    cc = 'n' + d1; raw = kind === 0x90 && d2 > 0 ? 127 : 0; isPress = raw > 0;
  } else {
    return; // clock, pitch bend, aftertouch — nothing bound to these yet
  }

  const key = bindingKey(input, channel, cc);

  if (learnTarget) {
    // Bind whatever just moved, and drop any previous binding to the same target so
    // one control never ends up driven by two.
    for (const k of Object.keys(mappings)) {
      if (mappings[k] === learnTarget) delete mappings[k];
    }
    mappings[key] = learnTarget;
    learnTarget = null;
    saveMappings();
    render();
    return;
  }

  const target = mappings[key];
  if (!target) return;

  const prev = lastValue.get(key);
  lastValue.set(key, raw);

  const bits = target.split(':');
  const spec = bits[0] === 'tape'
    ? MIDI_TARGETS['tape:' + bits[1]]
    : MIDI_TARGETS['deck:' + bits[2]];
  if (!spec) return;

  if (spec.type === 'press') {
    // Rising edge only, so holding a pad doesn't retrigger every message.
    if (isPress && !(prev >= 64)) midiApply(target, 1, true);
    return;
  }
  queueApply(target, raw / 127);
}

function attach(input) {
  input.onmidimessage = (e) => onMidiMessage(input, e);
}

async function enable() {
  try {
    midiAccess = await navigator.requestMIDIAccess({ sysex: false });
  } catch (e) {
    document.getElementById('midi-status').textContent =
      'MIDI refused: ' + (e && e.message ? e.message : e) +
      ' — Chrome asks permission for all MIDI access since v124.';
    return;
  }
  for (const input of midiAccess.inputs.values()) attach(input);
  // Devices plugged in later should just work.
  midiAccess.onstatechange = () => {
    for (const input of midiAccess.inputs.values()) attach(input);
    render();
  };
  render();
}

function render() {
  const status = document.getElementById('midi-status');
  const list = document.getElementById('midi-list');
  const enableBtn = document.getElementById('midi-enable');
  const learnBtn = document.getElementById('midi-learn');
  if (!status) return;

  const entries = Object.entries(mappings);

  // Saved mappings are listed even before access is granted. They are real and they
  // will work the moment MIDI is enabled — showing an empty list here would read as
  // though restarting Chrome had lost them.
  if (!midiAccess) {
    status.textContent = entries.length
      ? `MIDI not enabled — ${entries.length} saved mapping${entries.length > 1 ? 's' : ''} will take effect once you enable it.`
      : 'MIDI not enabled. Chrome will ask permission once.';
    learnBtn.disabled = true;
  } else {
    enableBtn.disabled = true;
    enableBtn.textContent = 'enabled';
    learnBtn.disabled = false;

    const names = [...midiAccess.inputs.values()].map((i) => i.name);
    status.textContent = names.length
      ? `${names.length} input${names.length > 1 ? 's' : ''}: ${names.join(', ')}`
      : 'No MIDI inputs found. Plug something in — it will be picked up automatically.';
  }
  list.innerHTML = entries.length
    ? entries
        .map(([key, target]) => {
          const [dev, ch, cc] = key.split('|');
          const what = String(cc).startsWith('n') ? 'note ' + String(cc).slice(1) : 'CC ' + cc;
          return `<div class="midi-map">
            <span class="midi-map__src">${dev} · ch${ch} · ${what}</span>
            <span class="midi-map__arrow">&rarr;</span>
            <span class="midi-map__dst">${midiTargetLabel(target)}</span>
            <button class="midi-map__x" data-unbind="${key}" title="Forget this mapping">&times;</button>
          </div>`;
        })
        .join('')
    : '<p class="hint">No mappings yet. Turn on learn, click a slider, then move a control on your device.</p>';

  if (learnTarget) {
    status.textContent = `Learning ${midiTargetLabel(learnTarget)} — move a control on your device.`;
  } else if (learnMode) {
    status.textContent = 'Learn is on. Click any slider, mute or solo to arm it.';
  }
}

function initMidi() {
  document.getElementById('midi-enable').addEventListener('click', enable);

  const learnBtn = document.getElementById('midi-learn');
  learnBtn.addEventListener('click', () => {
    learnMode = !learnMode;
    learnTarget = null;
    learnBtn.setAttribute('aria-pressed', String(learnMode));
    document.body.classList.toggle('midi-learn', learnMode);
    render();
  });

  document.getElementById('midi-forget').addEventListener('click', () => {
    mappings = {};
    saveMappings();
    render();
  });

  document.getElementById('midi-list').addEventListener('click', (e) => {
    const key = e.target && e.target.getAttribute && e.target.getAttribute('data-unbind');
    if (!key) return;
    delete mappings[key];
    saveMappings();
    render();
  });

  // In learn mode a click ARMS a control instead of operating it. Capture phase and
  // preventDefault, or dragging a slider to arm it would also move it.
  document.addEventListener(
    'pointerdown',
    (e) => {
      if (!learnMode) return;
      const el = e.target && e.target.closest && e.target.closest('[data-midi]');
      if (!el) return;
      e.preventDefault();
      e.stopPropagation();
      learnTarget = el.dataset.midi;
      render();
    },
    true,
  );

  loadMappings().then(render);
}

initMidi();

Object.assign(window, {
  midiEnable: enable,
  midiMappings: () => mappings,
  midiArm: (targetId) => { learnTarget = targetId; render(); },
  midiSimulate: (name, channel, cc, value) =>
    onMidiMessage({ name }, { data: [0xb0 | (channel - 1), cc, value] }),
  midiSimulateNote: (name, channel, note, on) =>
    onMidiMessage({ name }, { data: [(on ? 0x90 : 0x80) | (channel - 1), note, on ? 100 : 0] }),
  midiReady: true,
});
